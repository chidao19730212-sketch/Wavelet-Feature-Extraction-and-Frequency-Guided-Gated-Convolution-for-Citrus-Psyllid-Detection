import argparse
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class EvalGroup:
    key: str
    name: str
    train_dir: Path
    has_lightwavelet: bool
    has_fg_gdpr_p5: bool


def _groups(repo_root: Path) -> list[EvalGroup]:
    base = repo_root / "runs" / "ablation"
    return [
        EvalGroup("A", "A_base", base / "A_base", False, False),
        EvalGroup("B", "B_wavelet", base / "B_wavelet", True, False),
        EvalGroup("C", "C_fg", base / "C_fg", False, True),
        EvalGroup("D", "D_full", base / "D_full", True, True),
    ]


def _run_infer(
    repo_root: Path,
    weights: Path,
    save_dir: Path,
    dataset_root: Path,
    split: str,
    slice_size: int,
    overlap: float,
    scales: list[int],
    conf: float,
    wbf_iou: float,
    min_conf: float,
    vis_count: int,
    overwrite: bool,
) -> dict:
    summary_path = save_dir / "original_image_eval_summary.json"
    if summary_path.exists() and not overwrite:
        return json.loads(summary_path.read_text(encoding="utf-8"))

    if save_dir.exists():
        if not overwrite:
            return {"status": "skipped", "reason": "save_dir exists", "save_dir": str(save_dir)}
        raise SystemExit(f"SAVE_DIR_EXISTS\t{save_dir}")

    infer_py = repo_root / "tools" / "infer_sahi_tta.py"
    if not infer_py.exists():
        raise FileNotFoundError(str(infer_py))

    cmd = [
        sys.executable,
        str(infer_py),
        "--weights",
        str(weights),
        "--model_type",
        "ultralytics",
        "--dataset_root",
        str(dataset_root),
        "--splits",
        split,
        "--save_dir",
        str(save_dir),
        "--slice_size",
        str(slice_size),
        "--overlap_ratio",
        str(overlap),
        "--tta",
        "--fusion",
        "wbf",
        "--mode",
        "single",
        "--conf",
        str(conf),
        "--min_conf",
        str(min_conf),
        "--wbf_iou",
        str(wbf_iou),
        "--wbf_conf_type",
        "avg",
        "--vis_count",
        str(vis_count),
        "--skip_compare_inference_record",
    ]

    subprocess.run(cmd, cwd=str(repo_root), check=True)

    if summary_path.exists():
        return json.loads(summary_path.read_text(encoding="utf-8"))
    return {"status": "failed", "reason": "summary not found", "expected": str(summary_path)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights_type", type=str, default="best", choices=["best", "last"])
    parser.add_argument("--dataset_root", type=str, default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_split")
    parser.add_argument("--split", type=str, default="test")
    parser.add_argument("--slice_size", type=int, default=640)
    parser.add_argument("--overlap", type=float, default=0.25)
    parser.add_argument("--scales", type=str, default="640,768,960")
    parser.add_argument("--conf", type=float, default=0.35)
    parser.add_argument("--wbf_iou", type=float, default=0.30)
    parser.add_argument("--min_conf", type=float, default=0.15)
    parser.add_argument("--vis_count", type=int, default=8)
    parser.add_argument("--overwrite", action="store_true", default=False)
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parent
    dataset_root = Path(args.dataset_root)
    scales = [int(x.strip()) for x in str(args.scales).split(",") if x.strip()]

    out_records = []
    for g in _groups(repo_root):
        weights = g.train_dir / "weights" / f"{args.weights_type}.pt"
        if not weights.exists():
            out_records.append(
                {
                    "group": g.key,
                    "train_dir": str(g.train_dir),
                    "weights": str(weights),
                    "status": "not_found",
                }
            )
            continue

        save_dir = g.train_dir / f"original_image_eval_{args.weights_type}"
        summary = _run_infer(
            repo_root=repo_root,
            weights=weights,
            save_dir=save_dir,
            dataset_root=dataset_root,
            split=str(args.split),
            slice_size=int(args.slice_size),
            overlap=float(args.overlap),
            scales=scales,
            conf=float(args.conf),
            wbf_iou=float(args.wbf_iou),
            min_conf=float(args.min_conf),
            vis_count=int(args.vis_count),
            overwrite=bool(args.overwrite),
        )

        out_records.append(
            {
                "group": g.key,
                "lightwavelet": bool(g.has_lightwavelet),
                "fg_gdpr_p5": bool(g.has_fg_gdpr_p5),
                "train_dir": str(g.train_dir),
                "weights": str(weights),
                "eval_dir": str(save_dir),
                "summary_path": str(save_dir / "original_image_eval_summary.json"),
                "status": summary.get("status", "ok"),
            }
        )

    out_path = repo_root / "runs" / "ablation" / f"eval_run_{args.weights_type}.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out_records, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
