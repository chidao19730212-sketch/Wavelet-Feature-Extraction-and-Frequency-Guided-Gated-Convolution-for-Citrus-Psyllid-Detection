# LWG-Det: Lightweight Wavelet-Gated Detector for Citrus Psyllid Detection

<p align="left">
  <a href="https://pytorch.org/"><img src="https://img.shields.io/badge/PyTorch-2.0%2B-EE4C2C?logo=pytorch&logoColor=white"/></a>
  <a href="https://github.com/ultralytics/ultralytics"><img src="https://img.shields.io/badge/Ultralytics-8.0%2B-0044FF"/></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-green"/></a>
</p>

Implementation of the lightweight detection backbone used in the paper
*Lightweight Wavelet-Gated Detector for Edge-Level Citrus Psyllid Monitoring*.
The model couples a learnable wavelet front-end with a frequency-gated
state-space feature mixer (FG-GDPR-P5), delivering competitive mAP under a
~2.6 M parameter budget.  Inference with SAHI slicing, TTA multi-scale
augmentation and WBF post-processing is supported out of the box.

---

## Highlights

| Feature | Description |
| :-- | :-- |
| **LightWavelet front-end** | Learnable 2-D wavelet decomposition replaces the stem conv, halving the early-stage compute |
| **FG-GDPR-P5 mixer** | Frequency-gated state-space block on the P5 level, mixes long-range context without the quadratic cost of self-attention |
| **LightC2f neck** | Depthwise-separable C2f variant keeps the PAN neck slim |
| **Full image evaluation** | SAHI slice inference + TTA scales + Weighted Box Fusion on 105 original-sized test images |
| **Ablation suite** | Four-group ablation (base → wavelet → FG → full) under the same data split and training recipe |

---

## Installation

### Prerequisites

* Python ≥ 3.9
* PyTorch ≥ 2.0 with matching CUDA (recommended ≥ 11.8)
* `git-lfs` if you want to download pre-trained weights from the release page

### Install

```bash
git clone <this-repo>
cd Tpsyllid2

# (optional) create a fresh venv / conda env
python -m venv .venv && .venv\Scripts\activate        # Windows
# source .venv/bin/activate                            # Linux / macOS

pip install --upgrade pip
pip install -r requirements.txt
```

`requirements.txt` pins the versions of `ultralytics`, `thop`, `sahi`, `pybboxes`
and `weighted-boxes-fusion` that produced the paper metrics.

---

## Dataset

The paper uses a field-collected citrus psyllid dataset split into

* **Slice-level** — 640×640 balanced patches for training/validation:
  `configs/psyllid_slice640_balanced.yaml`
* **Full-image** — 105 original-sized images for test-time evaluation
  (SAHI + TTA + WBF pipeline).

The YAMLs in `configs/` reference absolute paths on the original workstation.
To reproduce, place the image/label folders on your machine and edit the
`train`, `val`, `test` entries in the dataset YAML accordingly.

Expected folder layout (YAML paths can be arbitrary, they just need to
point at these roots):

```
<dataset_root>/
├── images/
│   ├── train/
│   ├── val/
│   └── test/
└── labels/
    ├── train/
    ├── val/
    └── test/
```

---

## Reproducing the Paper Results

### 1 — Training

**Ablation study (four groups):**

```bash
python run_ablation_4groups.py
```

This trains the four configurations listed in Table 3 of the paper
(A: base, B: +LightWavelet, C: +FG-GDPR-P5, D: full LWG-Det) for 100
epochs each with `seed=42` and logs to `runs/ablation/<group>`.

**Full LWG-Det (comparative experiment, Table 4/5):**

```bash
python trainers/train_horizontal_compare.py
```

Trains the final LWG-Det model independently with `seed=0` and logs to
`runs_lightweight/lwsdet_b1_fg_lssm_p5`.  Paper 3.4 explicitly documents
that ablation and comparative runs are separate training sessions.

### 2 — Structure & Complexity Check

The ablation pipeline automatically writes a per-group
`structure_check/structure_check.json` (unfused params/MACs) after YAML
initialization.  For the fused figures reported in the comparative
tables (Conv-BN folded for a fair apples-to-apples comparison with
YOLOv11n / RT-DETR-L checkpoints):

```bash
python trainers/official_reval_fg_lssm.py
```

### 3 — Full-Image Test (SAHI + TTA + WBF)

```bash
# Ablation Group D (Table 3 row D best.pt)
python evaluate_ablation_full_image.py

# Final LWG-Det last.pt (Table 4 / Table 5)
python tools/infer_sahi_tta.py \
    --weights  runs_lightweight/lwsdet_b1_fg_lssm_p5/weights/last.pt \
    --cfg      configs/lwsdet_b1_fg_lssm_p5.yaml \
    --data     configs/psyllid_slice640_balanced.yaml \
    --out_dir  runs_lightweight/paper2_original_image_eval/lwsdet_b1_fg_lssm_p5_last
```

Common inference defaults (matches the paper):

| Parameter | Value |
| :-- | :-- |
| SAHI slice size | 640 |
| SAHI overlap ratio | 0.25 |
| TTA scales | `[640, 768, 960]` |
| TTA horizontal flip | enabled |
| WBF input conf | 0.35 |
| WBF IoU threshold | 0.30 |

---

## Project Structure

```
Tpsyllid2/
├── configs/                                # model & dataset YAMLs
│   ├── lwgdet_ablation_[A-D]_*.yaml        # Table 3 ablation configs
│   ├── lwsdet_b1_fg_lssm_p5.yaml           # Table 4/5 final config
│   ├── psyllid_slice640_balanced.yaml      # dataset definition
│   └── teacher_wavelet_ssm.yaml
├── datasets/                               # custom dataset wrappers
├── docs/                                   # design notes
├── models/
│   ├── modules/lws_modules.py              # LightWavelet, FG-LSSM, LightC2f, LightSPPF
│   └── lwsdet_registry.py                  # registers custom ops with Ultralytics
├── results/                                # Figure 7 qualitative PDFs / PNGs
├── runs/ablation/                          # Table 3 training logs + evals
├── runs_lightweight/                       # Table 4/5 training logs + evals
├── trainers/                               # training / re-validation entry points
├── tools/infer_sahi_tta.py                 # SAHI + TTA + WBF inference
├── evaluate_ablation_full_image.py         # Table 3 eval orchestrator
├── run_ablation_4groups.py                 # Table 3 train orchestrator
├── generate_qualitative_figure.py          # Figure 7 generation
├── requirements.txt
├── CITATION.cff
├── LICENSE
└── README.md
```

---

## Models

### Configs

| Config | Description |
| :-- | :-- |
| `lwgdet_ablation_A_base.yaml` | YOLOv11n-style base, no wavelet, no FG block |
| `lwgdet_ablation_B_wavelet.yaml` | + LightWavelet stem |
| `lwgdet_ablation_C_fg.yaml` | + FG-GDPR-P5 (no wavelet stem) |
| `lwgdet_ablation_D_full.yaml` | **complete LWG-Det** (Table 3 row D) |
| `lwsdet_b1_fg_lssm_p5.yaml` | identical to `_D_full.yaml`, used for the independent comparative run (Table 4/5) |

### Pre-trained Weights

The `best.pt` / `last.pt` checkpoints that produced the paper figures are
located under:

* `runs/ablation/D_full/weights/` (ablation, seed=42)
* `runs_lightweight/lwsdet_b1_fg_lssm_p5/weights/` (comparative, seed=0)

If you clone without `git-lfs` the `.pt` files will be LFS pointers.
Run `git lfs pull` to materialize them.

---

## Citation

If this repository is useful in your work, please cite the corresponding
paper (BibTeX TBD upon acceptance).  A machine-readable citation entry is
also available in [CITATION.cff](CITATION.cff).

```bibtex
@article{lwgdet2026,
  title   = {Lightweight Wavelet-Gated Detector for Edge-Level
             Citrus Psyllid Monitoring},
  author  = {TBD},
  journal = {TBD},
  year    = {2026},
}
```

---

## License

Code is released under the MIT license.  See [LICENSE](LICENSE).
