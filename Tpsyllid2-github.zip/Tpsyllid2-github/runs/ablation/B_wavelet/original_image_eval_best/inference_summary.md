# Inference Summary

- experiment_name: original_image_eval_best
- base_model: B_wavelet
- model_type: ultralytics
- dataset_version: slice640_balanced_rebuild_v1
- eval_level: original_full_image
- inference_pipeline: SAHI_TTA_WBF
- conf: 0.35
- iou_merge: 0.3
- pretrained: 
- weight_path: C:\Users\admim\Desktop\Tpsyllid2\runs\ablation\B_wavelet\weights\best.pt

## test

- Precision: 0.5126
- Recall: 0.8579
- F1: 0.6417
- mAP50: 0.7118
- mAP50-95: 0.2677
- TP/FP/FN/GT: 163/155/27/190
- Time(s)/FPS/avg(s/img): 378.749/0.2772/3.6071333333333335
