# Inference Summary

- experiment_name: original_image_eval_best
- base_model: A_base
- model_type: ultralytics
- dataset_version: slice640_balanced_rebuild_v1
- eval_level: original_full_image
- inference_pipeline: SAHI_TTA_WBF
- conf: 0.35
- iou_merge: 0.3
- pretrained: 
- weight_path: C:\Users\admim\Desktop\Tpsyllid2\runs\ablation\A_base\weights\best.pt

## test

- Precision: 0.5076
- Recall: 0.8789
- F1: 0.6435
- mAP50: 0.7358
- mAP50-95: 0.2744
- TP/FP/FN/GT: 167/162/23/190
- Time(s)/FPS/avg(s/img): 370.994/0.283/3.5332761904761907
