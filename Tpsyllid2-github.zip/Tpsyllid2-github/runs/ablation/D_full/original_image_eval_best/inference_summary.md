# Inference Summary

- experiment_name: original_image_eval_best
- base_model: D_full
- model_type: ultralytics
- dataset_version: slice640_balanced_rebuild_v1
- eval_level: original_full_image
- inference_pipeline: SAHI_TTA_WBF
- conf: 0.35
- iou_merge: 0.3
- pretrained: 
- weight_path: C:\Users\admim\Desktop\Tpsyllid2\runs\ablation\D_full\weights\best.pt

## test

- Precision: 0.5331
- Recall: 0.8895
- F1: 0.6667
- mAP50: 0.7182
- mAP50-95: 0.2587
- TP/FP/FN/GT: 169/148/21/190
- Time(s)/FPS/avg(s/img): 390.118/0.2691/3.715409523809524
