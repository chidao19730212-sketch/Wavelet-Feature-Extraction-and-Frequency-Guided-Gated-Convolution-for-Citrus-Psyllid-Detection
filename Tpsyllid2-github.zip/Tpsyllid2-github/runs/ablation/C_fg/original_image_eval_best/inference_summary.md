# Inference Summary

- experiment_name: original_image_eval_best
- base_model: C_fg
- model_type: ultralytics
- dataset_version: slice640_balanced_rebuild_v1
- eval_level: original_full_image
- inference_pipeline: SAHI_TTA_WBF
- conf: 0.35
- iou_merge: 0.3
- pretrained: 
- weight_path: C:\Users\admim\Desktop\Tpsyllid2\runs\ablation\C_fg\weights\best.pt

## test

- Precision: 0.5395
- Recall: 0.8632
- F1: 0.664
- mAP50: 0.7236
- mAP50-95: 0.2725
- TP/FP/FN/GT: 164/140/26/190
- Time(s)/FPS/avg(s/img): 379.826/0.2764/3.6173904761904763
