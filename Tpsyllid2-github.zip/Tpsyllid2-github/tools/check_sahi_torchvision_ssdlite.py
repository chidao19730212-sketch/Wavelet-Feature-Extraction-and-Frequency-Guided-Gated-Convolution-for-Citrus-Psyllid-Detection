from __future__ import annotations

import argparse
import importlib.util
import json
import os
import site
import sys
import time
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[1]


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _json_dump(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _md_dump(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _find_one_test_image(test_dir: Path) -> Path:
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
    for p in sorted(test_dir.iterdir(), key=lambda x: x.name):
        if p.is_file() and p.suffix.lower() in exts:
            return p
    raise FileNotFoundError(f"no test image found under {test_dir}")


def _object_to_dict(obj) -> dict:
    bbox = obj.bbox
    category = obj.category
    score = obj.score
    return {
        "bbox": [
            float(bbox.minx),
            float(bbox.miny),
            float(bbox.maxx),
            float(bbox.maxy),
        ],
        "score": float(score.value),
        "category_id": int(category.id),
        "category_name": str(category.name),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--weights",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/ssdlite_mobilenetv3/best.pth",
    )
    parser.add_argument(
        "--torchvision_config",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/ssdlite_mobilenetv3/ssdlite_torchvision_config.json",
    )
    parser.add_argument(
        "--image_dir",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_split\test\images",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/ssdlite_mobilenetv3/sahi_smoke_test",
    )
    args = parser.parse_args()

    out_dir = (ROOT / args.output_dir) if not Path(args.output_dir).is_absolute() else Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    weights_path = (ROOT / args.weights) if not Path(args.weights).is_absolute() else Path(args.weights)
    config_path = (ROOT / args.torchvision_config) if not Path(args.torchvision_config).is_absolute() else Path(args.torchvision_config)
    image_dir = Path(args.image_dir)

    env_payload = {
        "timestamp": _now(),
        "python_executable": sys.executable,
        "python_version": sys.version.split()[0],
        "torch_version": torch.__version__,
        "torchvision_spec_found": bool(importlib.util.find_spec("torchvision") is not None),
        "cuda_available": bool(torch.cuda.is_available()),
        "cuda_runtime": getattr(torch.version, "cuda", None),
        "cuda_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "site_enable_user_site": bool(site.ENABLE_USER_SITE),
        "pythonnousersite_env": os.environ.get("PYTHONNOUSERSITE"),
        "requirements_declares_sahi": False,
        "requirements_path": str(ROOT / "requirements.txt"),
        "sahi_import_success": False,
        "sahi_version": None,
        "autodetectionmodel_import_success": False,
        "errors": [],
    }

    req_path = ROOT / "requirements.txt"
    if req_path.exists():
        req_text = req_path.read_text(encoding="utf-8", errors="ignore").lower()
        env_payload["requirements_declares_sahi"] = "sahi" in req_text

    try:
        import sahi

        env_payload["sahi_import_success"] = True
        env_payload["sahi_version"] = getattr(sahi, "__version__", None)
    except Exception as e:
        env_payload["errors"].append(f"sahi import failed: {type(e).__name__}: {e}")

    try:
        from sahi import AutoDetectionModel

        env_payload["autodetectionmodel_import_success"] = True
    except Exception as e:
        env_payload["errors"].append(f"AutoDetectionModel import failed: {type(e).__name__}: {e}")
        AutoDetectionModel = None

    env_json = out_dir / "sahi_env_check.json"
    env_md = out_dir / "sahi_env_check.md"
    _json_dump(env_json, env_payload)
    env_md_lines = [
        "# SAHI Environment Check",
        "",
        f"- python_executable: {env_payload['python_executable']}",
        f"- python_version: {env_payload['python_version']}",
        f"- torch_version: {env_payload['torch_version']}",
        f"- cuda_available: {env_payload['cuda_available']}",
        f"- cuda_name: {env_payload['cuda_name']}",
        f"- site.ENABLE_USER_SITE: {env_payload['site_enable_user_site']}",
        f"- PYTHONNOUSERSITE: {env_payload['pythonnousersite_env']}",
        f"- requirements declares sahi: {env_payload['requirements_declares_sahi']}",
        f"- sahi import success: {env_payload['sahi_import_success']}",
        f"- sahi version: {env_payload['sahi_version']}",
        f"- AutoDetectionModel import success: {env_payload['autodetectionmodel_import_success']}",
        "",
        "## Errors",
        "",
    ]
    env_md_lines.extend([f"- {msg}" for msg in env_payload["errors"]] or ["- none"])
    _md_dump(env_md, "\n".join(env_md_lines))

    if AutoDetectionModel is None:
        raise SystemExit("SAHI_IMPORT_FAILED")

    config_payload = _load_json(config_path)
    loader_payload = {
        "timestamp": _now(),
        "weights_path": str(weights_path),
        "config_path": str(config_path),
        "config_payload": config_payload,
        "model_type": "torchvision",
        "device": "cuda:0" if torch.cuda.is_available() else "cpu",
        "confidence_threshold": 0.35,
        "category_mapping_attempted": {"0": "background", "1": "psyllid"},
        "category_mapping_passed_ok": False,
        "category_mapping_error": None,
        "fallback_to_default_mapping": False,
        "model_load_success": False,
        "model_load_error": None,
        "resolved_category_mapping": None,
        "notes": [
            "This check only validates SAHI torchvision loading and one-image sliced inference.",
            "This is not full original-image SAHI+TTA+WBF evaluation.",
        ],
    }

    try:
        detection_model = AutoDetectionModel.from_pretrained(
            model_type="torchvision",
            model_path=str(weights_path),
            config_path=str(config_path),
            confidence_threshold=0.35,
            device=loader_payload["device"],
            category_mapping=loader_payload["category_mapping_attempted"],
        )
        loader_payload["category_mapping_passed_ok"] = True
        loader_payload["model_load_success"] = True
    except TypeError as e:
        loader_payload["category_mapping_error"] = f"{type(e).__name__}: {e}"
        loader_payload["fallback_to_default_mapping"] = True
        try:
            detection_model = AutoDetectionModel.from_pretrained(
                model_type="torchvision",
                model_path=str(weights_path),
                config_path=str(config_path),
                confidence_threshold=0.35,
                device=loader_payload["device"],
            )
            loader_payload["model_load_success"] = True
        except Exception as inner:
            loader_payload["model_load_error"] = f"{type(inner).__name__}: {inner}"
            detection_model = None
    except Exception as e:
        loader_payload["model_load_error"] = f"{type(e).__name__}: {e}"
        detection_model = None

    if detection_model is not None:
        loader_payload["resolved_category_mapping"] = getattr(detection_model, "category_mapping", None)

    loader_json = out_dir / "sahi_torchvision_loader_check.json"
    loader_md = out_dir / "sahi_torchvision_loader_check.md"
    _json_dump(loader_json, loader_payload)
    _md_dump(
        loader_md,
        "\n".join(
            [
                "# SAHI Torchvision Loader Check",
                "",
                f"- weights_path: {loader_payload['weights_path']}",
                f"- config_path: {loader_payload['config_path']}",
                f"- model_type: {loader_payload['model_type']}",
                f"- device: {loader_payload['device']}",
                f"- confidence_threshold: {loader_payload['confidence_threshold']}",
                f"- model load success: {loader_payload['model_load_success']}",
                f"- category_mapping passed ok: {loader_payload['category_mapping_passed_ok']}",
                f"- fallback_to_default_mapping: {loader_payload['fallback_to_default_mapping']}",
                f"- category_mapping_error: {loader_payload['category_mapping_error']}",
                f"- resolved_category_mapping: {loader_payload['resolved_category_mapping']}",
                f"- model_load_error: {loader_payload['model_load_error']}",
            ]
        ),
    )

    if detection_model is None:
        raise SystemExit("SAHI_TORCHVISION_LOAD_FAILED")

    from sahi.predict import get_sliced_prediction

    image_path = _find_one_test_image(image_dir)
    smoke_payload = {
        "timestamp": _now(),
        "image_path": str(image_path),
        "slice_size": 640,
        "overlap_ratio": 0.25,
        "multi_scale_tta": False,
        "horizontal_flip": False,
        "wbf_enabled": False,
        "prediction_success": False,
        "prediction_error": None,
        "num_predictions": 0,
        "max_score": None,
        "top5_predictions": [],
        "label_summary": [],
        "result_object_type": None,
        "recommendation": None,
    }

    try:
        result = get_sliced_prediction(
            str(image_path),
            detection_model,
            slice_height=640,
            slice_width=640,
            overlap_height_ratio=0.25,
            overlap_width_ratio=0.25,
            perform_standard_pred=False,
        )
        objs = result.object_prediction_list
        preds = [_object_to_dict(obj) for obj in objs]
        smoke_payload["prediction_success"] = True
        smoke_payload["num_predictions"] = len(preds)
        smoke_payload["max_score"] = max((p["score"] for p in preds), default=None)
        smoke_payload["top5_predictions"] = preds[:5]
        smoke_payload["label_summary"] = sorted(
            {f"{p['category_id']}:{p['category_name']}" for p in preds}
        )
        smoke_payload["result_object_type"] = type(result).__name__
        smoke_payload["recommendation"] = (
            "Ready for full original-image SAHI+TTA+WBF protocol after keeping the same weights/config and re-enabling the full evaluation path."
        )
    except Exception as e:
        smoke_payload["prediction_error"] = f"{type(e).__name__}: {e}"
        smoke_payload["recommendation"] = "Not ready for full protocol until the sliced smoke test error is resolved."

    smoke_json = out_dir / "one_image_smoke_result.json"
    smoke_md = out_dir / "one_image_smoke_result.md"
    _json_dump(smoke_json, smoke_payload)
    smoke_md_lines = [
        "# One Image Smoke Result",
        "",
        f"- image_path: {smoke_payload['image_path']}",
        f"- slice_size: {smoke_payload['slice_size']}",
        f"- overlap_ratio: {smoke_payload['overlap_ratio']}",
        f"- multi_scale_tta: {smoke_payload['multi_scale_tta']}",
        f"- horizontal_flip: {smoke_payload['horizontal_flip']}",
        f"- wbf_enabled: {smoke_payload['wbf_enabled']}",
        f"- prediction_success: {smoke_payload['prediction_success']}",
        f"- num_predictions: {smoke_payload['num_predictions']}",
        f"- max_score: {smoke_payload['max_score']}",
        f"- label_summary: {smoke_payload['label_summary']}",
        f"- prediction_error: {smoke_payload['prediction_error']}",
        "",
        "## Top 5 Predictions",
        "",
    ]
    smoke_md_lines.extend(
        [f"- {json.dumps(item, ensure_ascii=False)}" for item in smoke_payload["top5_predictions"]] or ["- none"]
    )
    _md_dump(smoke_md, "\n".join(smoke_md_lines))


if __name__ == "__main__":
    main()
