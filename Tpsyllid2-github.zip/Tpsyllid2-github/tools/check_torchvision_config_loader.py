from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path

import torch
from PIL import Image
from torchvision.transforms.functional import to_tensor


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _read_config(path: Path) -> dict:
    suffix = path.suffix.lower()
    if suffix == ".json":
        return json.loads(path.read_text(encoding="utf-8"))
    if suffix in {".yaml", ".yml"}:
        import yaml

        return yaml.safe_load(path.read_text(encoding="utf-8"))
    raise ValueError(f"unsupported config suffix: {suffix}")


def _env_info() -> dict:
    info = {
        "python": sys.version.split()[0],
        "torch": torch.__version__,
        "cuda_available": bool(torch.cuda.is_available()),
        "cuda_runtime": getattr(torch.version, "cuda", None),
        "sahi_importable": bool(importlib.util.find_spec("sahi") is not None),
    }
    try:
        import torchvision

        info["torchvision"] = torchvision.__version__
    except Exception as e:
        info["torchvision_error"] = f"{type(e).__name__}: {e}"
    if torch.cuda.is_available():
        info["cuda_name"] = torch.cuda.get_device_name(0)
    return info


def _build_model_from_training_recipe(num_classes: int):
    from torchvision.models.mobilenetv3 import MobileNet_V3_Large_Weights
    from torchvision.models.detection import ssdlite320_mobilenet_v3_large

    model = ssdlite320_mobilenet_v3_large(
        weights=None,
        weights_backbone=MobileNet_V3_Large_Weights.IMAGENET1K_V1,
        num_classes=int(num_classes),
    )
    return model


def _find_real_slice_with_label() -> tuple[Path | None, Path | None]:
    candidates = [
        ROOT / "runs_lightweight" / "lightweight_baselines" / "ssdlite_mobilenetv3" / "best.pth",
    ]
    _ = candidates
    roots = [
        Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\val"),
        Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\train"),
        Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\test"),
    ]
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
    for split_root in roots:
        img_dir = split_root / "images"
        lbl_dir = split_root / "labels"
        if not img_dir.exists() or not lbl_dir.exists():
            continue
        for img_path in sorted(img_dir.iterdir(), key=lambda p: p.name):
            if not img_path.is_file() or img_path.suffix.lower() not in exts:
                continue
            label_path = lbl_dir / f"{img_path.stem}.txt"
            if not label_path.exists():
                continue
            txt = label_path.read_text(encoding="utf-8", errors="ignore").strip()
            if txt:
                return img_path, label_path
    return None, None


def _summarize_prediction(output: dict) -> dict:
    boxes = output.get("boxes", torch.zeros((0, 4)))
    scores = output.get("scores", torch.zeros((0,)))
    labels = output.get("labels", torch.zeros((0,), dtype=torch.int64))

    boxes_cpu = boxes.detach().cpu()
    scores_cpu = scores.detach().cpu()
    labels_cpu = labels.detach().cpu()

    xyxy_ok = True
    if boxes_cpu.numel() > 0:
        xyxy_ok = bool(
            torch.all(boxes_cpu[:, 0] <= boxes_cpu[:, 2]).item() and torch.all(boxes_cpu[:, 1] <= boxes_cpu[:, 3]).item()
        )

    unique_labels = sorted({int(v) for v in labels_cpu.tolist()})
    non_background_only = all(v == 1 for v in unique_labels) if unique_labels else None
    background_present = any(v == 0 for v in unique_labels)

    return {
        "keys": sorted(list(output.keys())),
        "num_boxes": int(boxes_cpu.shape[0]),
        "boxes_shape": list(boxes_cpu.shape),
        "scores_shape": list(scores_cpu.shape),
        "labels_shape": list(labels_cpu.shape),
        "xyxy_shape_ok": bool(boxes_cpu.ndim == 2 and boxes_cpu.shape[1] == 4) if boxes_cpu.ndim == 2 else False,
        "xyxy_order_ok": bool(xyxy_ok),
        "scores_in_0_1": bool(torch.all((scores_cpu >= 0) & (scores_cpu <= 1)).item()) if scores_cpu.numel() > 0 else True,
        "unique_labels": unique_labels,
        "labels_all_equal_1": non_background_only,
        "background_label_present": background_present,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/ssdlite_mobilenetv3/ssdlite_torchvision_config.yaml",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/ssdlite_mobilenetv3",
    )
    args = parser.parse_args()

    config_path = ROOT / Path(args.config)
    if not config_path.exists():
        config_path = Path(args.config)
    if not config_path.exists():
        raise SystemExit(f"CONFIG_NOT_FOUND\t{args.config}")

    out_dir = ROOT / Path(args.output_dir)
    if not out_dir.exists():
        out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    env = _env_info()
    config = _read_config(config_path)
    checkpoint_path = ROOT / Path(str(config.get("checkpoint_path", "")))
    if not checkpoint_path.exists():
        checkpoint_path = Path(str(config.get("checkpoint_path", "")))
    if not checkpoint_path.exists():
        raise SystemExit(f"CHECKPOINT_NOT_FOUND\t{checkpoint_path}")

    model_name = str(config.get("model_name", ""))
    num_classes = int(config.get("num_classes", 2))
    device_str = str(config.get("device", "cuda:0" if torch.cuda.is_available() else "cpu"))
    device = torch.device(device_str if torch.cuda.is_available() and device_str.startswith("cuda") else "cpu")

    if model_name != "ssdlite320_mobilenet_v3_large":
        raise SystemExit(f"UNSUPPORTED_MODEL_NAME\t{model_name}")

    t0 = time.perf_counter()
    model = _build_model_from_training_recipe(num_classes=num_classes)
    sd = torch.load(str(checkpoint_path), map_location="cpu")
    model.load_state_dict(sd, strict=True)
    model.eval()
    model.to(device)
    t1 = time.perf_counter()

    with torch.no_grad():
        random_input = torch.rand(3, int(config.get("input_size", 320)), int(config.get("input_size", 320)), device=device)
        random_output = model([random_input])[0]
    random_summary = _summarize_prediction(random_output)

    real_img_path, real_lbl_path = _find_real_slice_with_label()
    real_summary = {
        "image_path": str(real_img_path) if real_img_path else "",
        "label_path": str(real_lbl_path) if real_lbl_path else "",
        "forward_ok": False,
    }
    if real_img_path is not None:
        with Image.open(real_img_path) as im:
            im = im.convert("RGB")
            img_tensor = to_tensor(im).to(device)
        with torch.no_grad():
            real_output = model([img_tensor])[0]
        real_summary.update({"forward_ok": True, **_summarize_prediction(real_output)})

    infer_requirements = {
        "model_type_branch": "infer_sahi_tta.py passes model_type='torchvision' into AutoDetectionModel.from_pretrained",
        "script_consumes_directly": ["--weights", "--torchvision_config", "--min_conf", "--model_type=torchvision"],
        "script_parses_config_fields_itself": False,
        "upstream_sahi_torchvision_required_fields": ["model_name", "num_classes"],
        "checkpoint_loading_path": "checkpoint path is passed by infer_sahi_tta.py via --weights/model_path, not read from config by the local script branch",
        "score_threshold_source": "infer_sahi_tta.py uses CLI confidence_threshold args (min_conf/conf), not config score_threshold",
    }

    compatibility = {
        "native_torchvision_output_has_keys": random_summary["keys"],
        "infer_sahi_tta_expected_sahi_object_fields": ["bbox.minx/miny/maxx/maxy", "score.value"],
        "can_sahi_wrapper_convert_native_output": True,
        "native_output_contains_labels": "labels" in random_summary["keys"],
        "native_output_contains_boxes_scores": all(k in random_summary["keys"] for k in ["boxes", "scores"]),
        "label_offset_issue_detected": False,
        "background_class_returned_as_detection": bool(real_summary.get("background_label_present") or random_summary.get("background_label_present")),
        "notes": [
            "For single-class training, expected foreground label is 1.",
            "Torchvision native outputs do not usually expose background detections.",
            "infer_sahi_tta.py currently ignores labels in its own post-fusion dict and consumes bbox/score from SAHI predictions.",
            "Upstream SAHI default category_mapping is COCO-based; if category names matter later, a custom mapping step may be needed."
        ],
    }

    result = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "env": env,
        "config_path": str(config_path),
        "checkpoint_path": str(checkpoint_path),
        "config_payload": config,
        "infer_sahi_tta_torchvision_requirements": infer_requirements,
        "model_load": {
            "success": True,
            "model_name": model_name,
            "num_classes": num_classes,
            "device": str(device),
            "load_time_s": round(float(t1 - t0), 4),
        },
        "random_tensor_forward": {
            "success": True,
            **random_summary,
        },
        "real_slice_forward": real_summary,
        "compatibility_assessment": compatibility,
        "recommendation": {
            "suggest_next_step": "prepare/fix SAHI environment and then run original-image SAHI+TTA+WBF with --weights best.pth --torchvision_config ...",
            "still_cannot_run_original_image_sahi_tta_wbf_now": True,
            "reason": [
                "this step intentionally does not run SAHI",
                "current environment cannot import sahi",
            ],
        },
    }

    json_path = out_dir / "torchvision_config_loader_check.json"
    md_path = out_dir / "torchvision_config_loader_check.md"
    json_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    md_lines = [
        "# Torchvision Config Loader Check",
        "",
        "## Paths",
        "",
        f"- config_path: {config_path}",
        f"- checkpoint_path: {checkpoint_path}",
        "",
        "## infer_sahi_tta.py Torchvision Branch",
        "",
        "- model_type=torchvision 时，脚本只检查 `--torchvision_config` 非空，并将其原样作为 `config_path` 传入 `AutoDetectionModel.from_pretrained(...)`",
        "- 当前脚本本身不解析 torchvision_config 内部字段",
        "- 按上游 SAHI torchvision wrapper，真正必需字段是 `model_name` 与 `num_classes`",
        "- checkpoint 由 `--weights` 传入，不由 config 内 `checkpoint_path` 决定",
        "- score threshold 在当前项目链路里来自 CLI 参数 `--min_conf/--conf`，不是 config 内部字段",
        "",
        "## Load Check",
        "",
        f"- model load success: {result['model_load']['success']}",
        f"- random tensor forward success: {result['random_tensor_forward']['success']}",
        f"- real slice forward success: {bool(result['real_slice_forward'].get('forward_ok', False))}",
        "",
        "## Output Format Check",
        "",
        f"- random output keys: {result['random_tensor_forward']['keys']}",
        f"- random xyxy shape ok: {result['random_tensor_forward']['xyxy_shape_ok']}",
        f"- random xyxy order ok: {result['random_tensor_forward']['xyxy_order_ok']}",
        f"- real unique labels: {result['real_slice_forward'].get('unique_labels')}",
        f"- real labels all equal 1: {result['real_slice_forward'].get('labels_all_equal_1')}",
        f"- background label present: {result['compatibility_assessment']['background_class_returned_as_detection']}",
        "",
        "## Label / Category Notes",
        "",
        "- 训练期标签口径是 `background=0, psyllid=1`",
        "- 本次原生 forward 核验用于检查 native torchvision 输出是否为 `boxes/scores/labels`，以及 labels 是否落在单类口径上",
        "- 当前 infer_sahi_tta.py 在自身后处理字典里只消费 bbox 和 score，不直接消费 label/name",
        "- 但上游 SAHI torchvision wrapper 默认 category_mapping 为 COCO 类名；若后续需要严格的类别名语义，仍建议显式补上自定义映射",
        "",
        "## Conclusion",
        "",
        f"- best.pth loaded successfully: {result['model_load']['success']}",
        f"- output format compatible with native torchvision expectations: {result['compatibility_assessment']['native_output_contains_boxes_scores']}",
        "- still cannot run original-image SAHI+TTA+WBF now: True",
        "- main blocker: `sahi` is not importable in the current environment",
        "",
    ]
    md_path.write_text("\n".join(md_lines), encoding="utf-8")


if __name__ == "__main__":
    main()
