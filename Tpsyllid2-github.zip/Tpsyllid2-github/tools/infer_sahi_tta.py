import ast
import contextlib
import json
import math
import os
import shutil
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from PIL import Image
from tqdm import tqdm
from ultralytics import YOLO
from ultralytics.nn.modules import C2f as OriginalC2f, Conv

from sahi import AutoDetectionModel
from sahi.predict import get_sliced_prediction
from sahi.utils.cv import read_image


def dwt_haar(x):
    x00 = x[:, :, 0::2, 0::2]
    x10 = x[:, :, 1::2, 0::2]
    x01 = x[:, :, 0::2, 1::2]
    x11 = x[:, :, 1::2, 1::2]
    ll = (x00 + x10 + x01 + x11) / 4.0
    lh = (x00 - x10 + x01 - x11) / 4.0
    hl = (x00 + x10 - x01 - x11) / 4.0
    hh = (x00 - x10 - x01 + x11) / 4.0
    return torch.cat([ll, lh, hl, hh], dim=1)


class WaveletBlock(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.cv_ll = Conv(c1, c2, 3, 1)
        self.cv_high = Conv(c1 * 3, c2, 1, 1)
        self.fusion = Conv(c2 * 2, c2, 1, 1)
        self.noise_suppression = nn.Parameter(torch.ones(1) * 0.5)

    def forward(self, x):
        dwt_feat = dwt_haar(x)
        c = dwt_feat.shape[1] // 4
        ll = dwt_feat[:, :c, :, :]
        high_freq = dwt_feat[:, c:, :, :]
        feat_ll = self.cv_ll(ll)
        feat_high = self.cv_high(high_freq * self.noise_suppression)
        return self.fusion(torch.cat([feat_ll, feat_high], dim=1))


class MambaBlock(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.conv = nn.Conv2d(c, c, 3, padding=1, groups=c)
        self.proj = nn.Conv2d(c, c, 1)
        self.act = nn.SiLU()

    def forward(self, x):
        res = x
        x = self.conv(x)
        x = self.act(x)
        x = self.proj(x)
        return x + res


class PatchedC2f(OriginalC2f):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, is_mamba=False):
        super().__init__(c1, c2, n, shortcut, g, e)
        if is_mamba:
            self.m = nn.ModuleList(MambaBlock(self.c) for _ in range(n))


import ultralytics.nn.modules
import ultralytics.nn.tasks as tasks
from ultralytics.nn.modules import (
    AIFI, A2C2f, ADown, AConv, Bottleneck, BottleneckCSP, C1, C2, C2f, C2fAttn, C2fCIB,
    C2fPSA, C2PSA, C3, C3Ghost, C3TR, C3k2, C3x, CBLinear, CBFuse, Classify, Concat, Conv2,
    ConvTranspose, Detect, DWConv, DWConvTranspose2d, ELAN1, Focus, GhostBottleneck, GhostConv,
    HGBlock, HGStem, ImagePoolingAttn, Index, LRPCHead, OBB, Pose, PSA, RepC3, RepConv,
    RepNCSPELAN4, RepVGGDW, ResNetLayer, RTDETRDecoder, SCDown, Segment, SPP, SPPELAN, SPPF,
    TorchVision, WorldDetect, YOLOEDetect, YOLOESegment, v10Detect,
)
from ultralytics.utils.ops import make_divisible


def patched_parse_model(d, ch, verbose=True):
    depth, width, max_channels = 1.0, 1.0, float("inf")
    scales = d.get("scales")
    scale = d.get("scale")
    if scales and scale:
        depth, width, max_channels = scales[scale]
    nc = d.get("nc")
    ch = [ch]
    layers, save, c2 = [], [], ch[-1]
    base_modules = {
        Classify, Conv, ConvTranspose, GhostConv, Bottleneck, GhostBottleneck,
        SPP, SPPF, C2fPSA, C2PSA, DWConv, Focus, BottleneckCSP, C1, C2, C2f,
        C3k2, RepNCSPELAN4, ELAN1, ADown, AConv, SPPELAN, C2fAttn, C3, C3TR,
        C3Ghost, torch.nn.ConvTranspose2d, DWConvTranspose2d, C3x, RepC3, PSA,
        SCDown, C2fCIB, A2C2f, WaveletBlock, PatchedC2f,
    }
    repeat_modules = {
        BottleneckCSP, C1, C2, C2f, C3k2, C2fAttn, C3, C3TR, C3Ghost, C3x,
        RepC3, C2fPSA, C2fCIB, C2PSA, A2C2f, PatchedC2f,
    }
    for i, (f, n, m_name, args) in enumerate(d["backbone"] + d["head"]):
        if m_name == "WaveletBlock":
            m = WaveletBlock
        elif m_name == "C2f":
            m = PatchedC2f
        else:
            m = getattr(torch.nn, m_name[3:]) if "nn." in m_name else globals().get(m_name)
            if m is None:
                m = getattr(tasks, m_name)
        for j, a in enumerate(args):
            if isinstance(a, str):
                if a == "nc":
                    args[j] = nc
                else:
                    with contextlib.suppress(ValueError):
                        args[j] = ast.literal_eval(a)
        n = n_ = max(round(n * depth), 1) if n > 1 else n
        if m in base_modules:
            c1, c2 = ch[f], args[0]
            if c2 != nc:
                c2 = make_divisible(min(c2, max_channels) * width, 8)
            args = [c1, c2, *args[1:]]
            if m in repeat_modules:
                args.insert(2, n)
                n = 1
        elif m is Concat:
            c2 = sum(ch[x] for x in f)
        elif m in {Detect, Segment, Pose, OBB}:
            args.append([ch[x] for x in f])
        else:
            c2 = ch[f]
        m_ = nn.Sequential(*(m(*args) for _ in range(n))) if n > 1 else m(*args)
        t = str(m)[8:-2].replace("__main__.", "")
        m_.i, m_.f, m_.type, m_.np = i, f, t, sum(x.numel() for x in m_.parameters())
        save.extend(x % i for x in ([f] if isinstance(f, int) else f) if x != -1)
        layers.append(m_)
        if i == 0:
            ch = []
        ch.append(c2)
    return nn.Sequential(*layers), sorted(save)


tasks.parse_model = patched_parse_model
setattr(ultralytics.nn.modules, "WaveletBlock", WaveletBlock)
setattr(ultralytics.nn.tasks, "WaveletBlock", WaveletBlock)
ultralytics.nn.tasks.C2f = PatchedC2f


def _register_lwsdet_modules_if_available():
    """Register LWS-Det modules only when custom lightweight weights need them."""
    root = Path(__file__).resolve().parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from models import register_lwsdet_modules

    register_lwsdet_modules()


def _load_torchvision_category_mapping(config_path: str) -> dict[str, str] | None:
    cfg_path = Path(config_path)
    if not cfg_path.exists():
        return None
    suffix = cfg_path.suffix.lower()
    try:
        if suffix == ".json":
            payload = json.loads(cfg_path.read_text(encoding="utf-8"))
        elif suffix in {".yaml", ".yml"}:
            import yaml

            payload = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
        else:
            return None
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None

    existing = payload.get("category_mapping")
    if isinstance(existing, dict) and existing:
        return {str(k): str(v) for k, v in existing.items()}

    class_names = payload.get("class_names")
    if isinstance(class_names, list) and class_names:
        return {str(i): str(name) for i, name in enumerate(class_names)}

    return None


def _build_auto_detection_model(args, device):
    if args.model_type == "mmdet":
        if not args.mmdet_config:
            raise ValueError("--mmdet_config is required when --model_type=mmdet")
        return AutoDetectionModel.from_pretrained(
            model_type="mmdet",
            model_path=args.weights,
            config_path=args.mmdet_config,
            confidence_threshold=float(args.min_conf),
            device=device,
        )
    if args.model_type == "torchvision":
        if not args.torchvision_config:
            raise ValueError("--torchvision_config is required when --model_type=torchvision")
        kwargs = dict(
            model_type="torchvision",
            model_path=args.weights,
            config_path=args.torchvision_config,
            confidence_threshold=float(args.min_conf),
            device=device,
        )
        category_mapping = _load_torchvision_category_mapping(args.torchvision_config)
        if category_mapping:
            kwargs["category_mapping"] = category_mapping
        return AutoDetectionModel.from_pretrained(**kwargs)
    return AutoDetectionModel.from_pretrained(
        model_type="ultralytics",
        model_path=args.weights,
        confidence_threshold=float(args.min_conf),
        device=device,
    )


def _load_auto_detection_model_with_retry(args, device):
    try:
        return _build_auto_detection_model(args, device), False
    except Exception as first_error:
        try:
            _register_lwsdet_modules_if_available()
            return _build_auto_detection_model(args, device), True
        except Exception:
            raise first_error


def _load_yolo_model_with_retry(weight_path):
    try:
        return YOLO(weight_path), False
    except Exception as first_error:
        try:
            _register_lwsdet_modules_if_available()
            return YOLO(weight_path), True
        except Exception:
            raise first_error

def _xyxy_iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    iw = max(0.0, ix2 - ix1)
    ih = max(0.0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return float(inter / union) if union > 0 else 0.0


def _match_detections(preds, gts, iou_thr=0.5):
    """
    preds: list of dict {box:[x1,y1,x2,y2], score:float}
    gts:   list of [x1,y1,x2,y2]
    Returns: (tp_flags, fp_flags, matched_gt_mask)
    """
    if not preds:
        return [], [], [False] * len(gts)
    preds_sorted = sorted(preds, key=lambda d: d["score"], reverse=True)
    matched = [False] * len(gts)
    tp, fp = [], []
    for det in preds_sorted:
        best_iou = 0.0
        best_j = -1
        for j, gt in enumerate(gts):
            if matched[j]:
                continue
            iou = _xyxy_iou(det["box"], gt)
            if iou > best_iou:
                best_iou, best_j = iou, j
        if best_iou >= iou_thr and best_j >= 0:
            matched[best_j] = True
            tp.append(1)
            fp.append(0)
        else:
            tp.append(0)
            fp.append(1)
    return tp, fp, matched


def _ap_from_pr(recalls, precisions):
    """
    COCO-style AP integration with precision envelope.
    """
    if len(recalls) == 0:
        return 0.0
    mrec = np.concatenate(([0.0], recalls, [1.0]))
    mpre = np.concatenate(([0.0], precisions, [0.0]))
    for i in range(mpre.size - 1, 0, -1):
        mpre[i - 1] = max(mpre[i - 1], mpre[i])
    idx = np.where(mrec[1:] != mrec[:-1])[0]
    ap = float(np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1]))
    return ap


def _evaluate_dataset(all_image_dets, all_image_gts, iou_thr=0.5):
    """
    all_image_dets: dict[img_id] -> list of det dicts {box, score}
    all_image_gts:  dict[img_id] -> list of gt boxes
    """
    all_scores = []
    all_tp = []
    all_fp = []
    total_gts = 0
    total_fp = 0
    total_tp = 0

    for img_id, gts in all_image_gts.items():
        total_gts += len(gts)
        dets = all_image_dets.get(img_id, [])
        tp, fp, _ = _match_detections(dets, gts, iou_thr=iou_thr)
        dets_sorted = sorted(dets, key=lambda d: d["score"], reverse=True)
        for d, t, f in zip(dets_sorted, tp, fp):
            all_scores.append(d["score"])
            all_tp.append(t)
            all_fp.append(f)
        total_fp += int(sum(fp))
        total_tp += int(sum(tp))

    if total_gts == 0:
        precision = 1.0 if total_fp == 0 else 0.0
        recall = 0.0
        f1 = 0.0
        ap50 = 0.0
        return {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "mAP50": ap50,
            "fp": total_fp,
            "tp": total_tp,
            "gt": total_gts,
        }

    if len(all_scores) == 0:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0, "mAP50": 0.0, "fp": 0, "tp": 0, "gt": total_gts}

    order = np.argsort(-np.array(all_scores))
    tp_cum = np.cumsum(np.array(all_tp)[order])
    fp_cum = np.cumsum(np.array(all_fp)[order])
    recalls = tp_cum / (total_gts + 1e-16)
    precisions = tp_cum / (tp_cum + fp_cum + 1e-16)
    ap50 = _ap_from_pr(recalls, precisions)

    precision = float(precisions[-1])
    recall = float(recalls[-1])
    f1 = float((2 * precision * recall) / (precision + recall + 1e-16))
    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "mAP50": float(ap50),
        "fp": int(total_fp),
        "tp": int(total_tp),
        "gt": int(total_gts),
        "pr_curve": {"recall": recalls.tolist(), "precision": precisions.tolist()},
    }


def _evaluate_map50_95(all_image_dets, all_image_gts):
    ious = [round(x, 2) for x in np.arange(0.5, 0.96, 0.05).tolist()]
    aps = []
    for thr in ious:
        m = _evaluate_dataset(all_image_dets, all_image_gts, iou_thr=float(thr))
        aps.append(float(m.get("mAP50", 0.0)))
    return float(sum(aps) / len(aps)) if aps else 0.0


def hard_nms(dets, iou_thr=0.45, topk=300):
    if not dets:
        return []
    import torchvision

    boxes = torch.tensor([d["box"] for d in dets], dtype=torch.float32)
    scores = torch.tensor([d["score"] for d in dets], dtype=torch.float32)
    keep = torchvision.ops.nms(boxes, scores, float(iou_thr))
    keep = keep[:topk].tolist()
    return [dets[i] for i in keep]


def soft_nms(dets, iou_thr=0.45, sigma=0.5, method="linear", score_thr=0.001, topk=300):
    """
    dets: list of dict {box, score}
    """
    if not dets:
        return []
    dets = [{"box": d["box"][:], "score": float(d["score"])} for d in dets]
    dets.sort(key=lambda d: d["score"], reverse=True)
    kept = []
    while dets and len(kept) < topk:
        best = dets.pop(0)
        kept.append(best)
        new_dets = []
        for d in dets:
            iou = _xyxy_iou(best["box"], d["box"])
            if method == "linear":
                if iou > iou_thr:
                    d["score"] *= (1.0 - iou)
            elif method == "gaussian":
                d["score"] *= math.exp(-(iou * iou) / (sigma + 1e-16))
            else:
                raise ValueError(f"Unknown Soft-NMS method: {method}")
            if d["score"] >= score_thr:
                new_dets.append(d)
        dets = sorted(new_dets, key=lambda d: d["score"], reverse=True)
    return kept


def weighted_box_fusion(pred_sets, iou_thr=0.55, conf_type="avg", weights=None, topk=300):
    """
    pred_sets: list of list[det], det={box, score}
    """
    if not pred_sets:
        return []
    if weights is None:
        weights = [1.0] * len(pred_sets)

    candidates = []
    for w, dets in zip(weights, pred_sets):
        for d in dets:
            candidates.append({"box": d["box"], "score": float(d["score"]), "w": float(w)})
    candidates.sort(key=lambda d: d["score"], reverse=True)

    fused = []
    used = [False] * len(candidates)
    for i, d in enumerate(candidates):
        if used[i]:
            continue
        cluster = [d]
        used[i] = True
        for j in range(i + 1, len(candidates)):
            if used[j]:
                continue
            if _xyxy_iou(d["box"], candidates[j]["box"]) >= iou_thr:
                used[j] = True
                cluster.append(candidates[j])

        ws = np.array([c["w"] for c in cluster], dtype=np.float32)
        ss = np.array([c["score"] for c in cluster], dtype=np.float32)
        weight_scores = ws * ss
        denom = float(weight_scores.sum() + 1e-16)
        coords = np.array([c["box"] for c in cluster], dtype=np.float32)
        fused_box = (coords * weight_scores[:, None]).sum(axis=0) / denom

        if conf_type == "avg":
            fused_score = float((ss * ws).sum() / (ws.sum() + 1e-16))
        elif conf_type == "max":
            fused_score = float(ss.max())
        elif conf_type == "sum":
            fused_score = float(min(1.0, (ss * ws).sum() / (ws.sum() + 1e-16) * len(cluster)))
        else:
            raise ValueError(f"Unknown conf_type: {conf_type}")

        fused.append({"box": fused_box.tolist(), "score": fused_score})
        if len(fused) >= topk:
            break
    fused.sort(key=lambda d: d["score"], reverse=True)
    return fused[:topk]


def _load_yolo_gts(label_path, img_w, img_h):
    gts = []
    if not label_path.exists():
        return gts
    with open(label_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) != 5:
                continue
            _, x, y, nw, nh = map(float, parts)
            x1 = (x - nw / 2) * img_w
            y1 = (y - nh / 2) * img_h
            x2 = (x + nw / 2) * img_w
            y2 = (y + nh / 2) * img_h
            gts.append([x1, y1, x2, y2])
    return gts


def _ensure_unique_dir(base_dir: Path):
    if not base_dir.exists():
        base_dir.mkdir(parents=True, exist_ok=False)
        return base_dir
    suffix = time.strftime("%Y%m%d_%H%M%S")
    new_dir = base_dir.parent / f"{base_dir.name}_{suffix}"
    new_dir.mkdir(parents=True, exist_ok=False)
    return new_dir


def _append_master_record(csv_path: Path, record: dict):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    if csv_path.exists():
        df = pd.read_csv(csv_path)
        for k in record.keys():
            if k not in df.columns:
                df[k] = None
        for k in df.columns:
            if k not in record:
                record[k] = None
        df_new = pd.DataFrame([record])[df.columns]
        df = pd.concat([df, df_new], ignore_index=True)
        df.to_csv(csv_path, index=False)
    else:
        df = pd.DataFrame([record])
        df.to_csv(csv_path, index=False)

def _upsert_compare_inference_record(csv_path: Path, key_field: str, key_value: str, row: dict):
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    if csv_path.exists():
        df = pd.read_csv(csv_path, encoding="utf-8-sig")
    else:
        df = pd.DataFrame()

    if key_field not in df.columns:
        df[key_field] = ""

    for k in row.keys():
        if k not in df.columns:
            df[k] = ""

    mask = (df[key_field].astype(str).str.strip() == str(key_value)).values
    if mask.any():
        idx = int(np.where(mask)[0][0])
        for k, v in row.items():
            df.at[idx, k] = v
    else:
        new_row = {c: "" for c in df.columns.tolist()}
        for k, v in row.items():
            new_row[k] = v
        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    df.to_csv(csv_path, index=False, encoding="utf-8-sig")


def _plot_curve(x, y, out_path: Path, x_label: str, y_label: str, title: str):
    w, h = 900, 600
    pad_l, pad_r, pad_t, pad_b = 90, 30, 50, 70
    img = np.full((h, w, 3), 255, dtype=np.uint8)

    def to_px(xv, yv):
        xi = pad_l + int(xv * (w - pad_l - pad_r))
        yi = h - pad_b - int(yv * (h - pad_t - pad_b))
        return xi, yi

    cv2.rectangle(img, (pad_l, pad_t), (w - pad_r, h - pad_b), (0, 0, 0), 1)
    cv2.putText(img, title, (pad_l, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
    cv2.putText(img, x_label, (w // 2 - 40, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
    cv2.putText(img, y_label, (10, h // 2), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)

    if len(x) >= 2:
        pts = [to_px(float(xi), float(yi)) for xi, yi in zip(x, y)]
        for i in range(1, len(pts)):
            cv2.line(img, pts[i - 1], pts[i], (255, 0, 0), 2)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), img)


def _per_image_fp_fn(all_image_dets, all_image_gts, iou_thr=0.5):
    per_image = {}
    for img_id, gts in all_image_gts.items():
        dets = all_image_dets.get(img_id, [])
        tp, fp, matched = _match_detections(dets, gts, iou_thr=iou_thr)
        fp_n = int(sum(fp))
        tp_n = int(sum(tp))
        fn_n = int(len(gts) - int(sum(matched)))
        per_image[img_id] = {"tp": tp_n, "fp": fp_n, "fn": fn_n, "gt": int(len(gts))}
    return per_image


def _draw_boxes(img_bgr, dets, gts, out_path):
    vis = img_bgr.copy()
    for d in dets:
        x1, y1, x2, y2 = map(int, d["box"])
        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(vis, f"{d['score']:.2f}", (x1, max(0, y1 - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    for gt in gts:
        x1, y1, x2, y2 = map(int, gt)
        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 0, 255), 1)
    cv2.imwrite(str(out_path), vis)

# --- Main Inference Script ---

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--weights",
        type=str,
        default="runs/detect/workspace/outputs/runs/detect/psyllid_ssm_wavelet_v1/weights/best.pt",
    )
    parser.add_argument("--source", type=str, default="workspace/data/yolo_split/val/images")
    parser.add_argument("--labels", type=str, default="workspace/data/yolo_split/val/labels")
    parser.add_argument("--save_dir", type=str, default="workspace/outputs/runs/detect/psyllid_inference_calibration_v1")
    parser.add_argument("--dataset_root", type=str, default="")
    parser.add_argument("--splits", type=str, default="")
    parser.add_argument("--master_csv", type=str, default="workspace/experiments/compare_master_record.csv")
    parser.add_argument("--model_type", type=str, default="ultralytics", choices=["ultralytics", "mmdet", "torchvision"])
    parser.add_argument("--mmdet_config", type=str, default="")
    parser.add_argument("--torchvision_config", type=str, default="")
    parser.add_argument("--slice_size", type=int, default=640)
    parser.add_argument("--overlap_ratio", type=float, default=0.25)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--tta", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--direct_full_image", action="store_true", default=False)
    parser.add_argument("--no_load_weights", action="store_true", default=False)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--mode", type=str, default="calibrate", choices=["single", "calibrate"])
    parser.add_argument("--fusion", type=str, default="nms", choices=["nms", "soft_linear", "soft_gaussian", "wbf"])
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--min_conf", type=float, default=0.15)
    parser.add_argument("--nms_iou", type=float, default=0.45)
    parser.add_argument("--soft_sigma", type=float, default=0.5)
    parser.add_argument("--wbf_iou", type=float, default=0.55)
    parser.add_argument("--wbf_conf_type", type=str, default="avg", choices=["avg", "max", "sum"])
    parser.add_argument("--save_visualizations", action="store_true", default=True)
    parser.add_argument("--vis_count", type=int, default=20)
    parser.add_argument("--compare_inference_csv", type=str, default="workspace/experiments/compare_inference_record.csv")
    parser.add_argument("--skip_compare_inference_record", action="store_true", default=False)
    parser.add_argument("--dataset_version", type=str, default="slice640_balanced_rebuild_v1")
    parser.add_argument("--eval_level", type=str, default="original_full_image")
    parser.add_argument("--model_type_label", type=str, default="")
    parser.add_argument("--pretrained", type=str, default="")
    parser.add_argument("--base_model", type=str, default="")
    args = parser.parse_args()

    ws_candidates = [Path("runs/detect/workspace"), Path("workspace")]
    ws_root = None
    for c in ws_candidates:
        if c.exists():
            ws_root = c
            break
    if ws_root is None:
        ws_root = Path("workspace")

    def _rebase_workspace_path(p: Path) -> Path:
        if p.is_absolute() or p.exists():
            return p
        parts = list(p.parts)
        if parts and parts[0].lower() == "workspace":
            return ws_root.joinpath(*parts[1:])
        return p

    if args.dataset_root:
        args.dataset_root = str(_rebase_workspace_path(Path(args.dataset_root)))
    else:
        args.source = str(_rebase_workspace_path(Path(args.source)))
        args.labels = str(_rebase_workspace_path(Path(args.labels)))

    args.save_dir = str(_rebase_workspace_path(Path(args.save_dir)))
    args.master_csv = str(_rebase_workspace_path(Path(args.master_csv)))
    args.compare_inference_csv = str(_rebase_workspace_path(Path(args.compare_inference_csv)))

    save_dir = Path(args.save_dir)
    if save_dir.exists():
        raise SystemExit(f"OUTPUT_DIR_EXISTS\t{save_dir}")
    save_dir.mkdir(parents=True, exist_ok=False)

    if bool(args.no_load_weights):
        raise SystemExit("NO_LOAD_WEIGHTS: this script loads model weights for inference; aborting per current constraints.")

    # Load Model
    print(f"Loading model from {args.weights}...")
    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    detection_model = None
    lwsdet_registry_loaded = False
    if not bool(args.direct_full_image):
        detection_model, lwsdet_registry_loaded = _load_auto_detection_model_with_retry(args, device)


    dataset_root = Path(args.dataset_root) if args.dataset_root else None
    split_list = [s.strip() for s in args.splits.split(",") if s.strip()] if args.splits else []
    if split_list and dataset_root is None:
        dataset_root = Path("workspace/data/yolo_split")

    splits_to_run = []
    if split_list:
        for s in split_list:
            splits_to_run.append(
                {
                    "split": s,
                    "source": dataset_root / s / "images",
                    "labels": dataset_root / s / "labels",
                }
            )
    else:
        splits_to_run.append({"split": "custom", "source": Path(args.source), "labels": Path(args.labels)})

    scales = [640, 768, 960] if args.tta else [args.slice_size]

    def run_one_split(split_name: str, source_dir: Path, labels_dir: Path, out_dir: Path):
        (out_dir / "visualizations").mkdir(parents=True, exist_ok=True)
        (out_dir / "predictions").mkdir(parents=True, exist_ok=True)
        (out_dir / "analysis").mkdir(parents=True, exist_ok=True)

        image_paths = list(source_dir.glob("*.jpg"))
        if args.limit > 0:
            image_paths = image_paths[:args.limit]

        raw_cache_path = out_dir / "predictions" / "raw_predictions.json"
        raw = {}
        raw_gts = {}
        split_registry_loaded = bool(lwsdet_registry_loaded)

        direct_model = None
        if bool(args.direct_full_image):
            if args.model_type != "ultralytics":
                raise ValueError("--direct_full_image only supports --model_type=ultralytics")
            direct_model, split_registry_loaded = _load_yolo_model_with_retry(args.weights)

        t_forward0 = time.perf_counter()
        bar_desc = f"Direct forward [{split_name}]" if bool(args.direct_full_image) else f"SAHI+TTA forward [{split_name}]"
        for img_path in tqdm(image_paths, desc=bar_desc):
            img_id = img_path.stem
            img = read_image(str(img_path))
            h, w = img.shape[:2]

            gt_path = labels_dir / (img_id + ".txt")
            raw_gts[img_id] = _load_yolo_gts(gt_path, w, h)

            pred_sets = []
            if bool(args.direct_full_image):
                if direct_model is None:
                    raise RuntimeError("direct_model is None")
                results = direct_model.predict(
                    source=str(img_path),
                    imgsz=int(args.imgsz),
                    conf=float(args.min_conf),
                    iou=1.0,
                    augment=False,
                    verbose=False,
                )
                dets = []
                if results and results[0].boxes is not None and results[0].boxes.xyxy is not None:
                    xyxy = results[0].boxes.xyxy.detach().cpu().numpy()
                    confs = results[0].boxes.conf.detach().cpu().numpy() if results[0].boxes.conf is not None else np.ones((xyxy.shape[0],), dtype=np.float32)
                    for bb, sc in zip(xyxy.tolist(), confs.tolist()):
                        dets.append({"box": [float(bb[0]), float(bb[1]), float(bb[2]), float(bb[3])], "score": float(sc)})
                pred_sets.append(dets)
            else:
                for scale in scales:
                    result = get_sliced_prediction(
                        str(img_path),
                        detection_model,
                        slice_height=int(scale),
                        slice_width=int(scale),
                        overlap_height_ratio=float(args.overlap_ratio),
                        overlap_width_ratio=float(args.overlap_ratio),
                        perform_standard_pred=False,
                        verbose=0,
                    )
                    dets = []
                    for obj in result.object_prediction_list:
                        dets.append(
                            {
                                "box": [float(obj.bbox.minx), float(obj.bbox.miny), float(obj.bbox.maxx), float(obj.bbox.maxy)],
                                "score": float(obj.score.value),
                            }
                        )
                    pred_sets.append(dets)

                    if args.tta:
                        img_flipped = img[:, ::-1, :].copy()
                        result_flipped = get_sliced_prediction(
                            img_flipped,
                            detection_model,
                            slice_height=int(scale),
                            slice_width=int(scale),
                            overlap_height_ratio=float(args.overlap_ratio),
                            overlap_width_ratio=float(args.overlap_ratio),
                            perform_standard_pred=False,
                            verbose=0,
                        )
                        dets_flip = []
                        for obj in result_flipped.object_prediction_list:
                            x1, y1, x2, y2 = float(obj.bbox.minx), float(obj.bbox.miny), float(obj.bbox.maxx), float(obj.bbox.maxy)
                            dets_flip.append({"box": [w - x2, y1, w - x1, y2], "score": float(obj.score.value)})
                        pred_sets.append(dets_flip)

            raw[img_id] = {"w": int(w), "h": int(h), "pred_sets": pred_sets}
        t_forward1 = time.perf_counter()
        forward_time_s = float(t_forward1 - t_forward0)
        forward_fps = float(len(image_paths) / max(1e-9, forward_time_s))

        with open(raw_cache_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "weights": args.weights,
                    "scales": scales,
                    "slice_size": args.slice_size,
                    "overlap_ratio": args.overlap_ratio,
                    "min_conf": args.min_conf,
                    "tta": bool(args.tta),
                    "direct_full_image": bool(args.direct_full_image),
                    "imgsz": int(args.imgsz),
                    "raw": raw,
                    "gts": raw_gts,
                },
                f,
                ensure_ascii=False,
            )

        def run_config(method, conf_thr, iou_thr, extra=None):
            all_dets = {}
            for img_id, payload in raw.items():
                pred_sets = payload["pred_sets"]
                filtered_sets = []
                for dets in pred_sets:
                    filtered_sets.append([d for d in dets if d["score"] >= conf_thr])

                if method == "nms":
                    merged = [d for dets in filtered_sets for d in dets]
                    fused = hard_nms(merged, iou_thr=iou_thr)
                elif method == "soft_linear":
                    merged = [d for dets in filtered_sets for d in dets]
                    fused = soft_nms(merged, iou_thr=iou_thr, sigma=args.soft_sigma, method="linear", score_thr=conf_thr)
                    fused = [d for d in fused if d["score"] >= conf_thr]
                elif method == "soft_gaussian":
                    merged = [d for dets in filtered_sets for d in dets]
                    fused = soft_nms(merged, iou_thr=iou_thr, sigma=args.soft_sigma, method="gaussian", score_thr=conf_thr)
                    fused = [d for d in fused if d["score"] >= conf_thr]
                elif method == "wbf":
                    conf_type = (extra or {}).get("conf_type", "avg")
                    fused = weighted_box_fusion(filtered_sets, iou_thr=iou_thr, conf_type=conf_type)
                    fused = [d for d in fused if d["score"] >= conf_thr]
                else:
                    raise ValueError(method)

                all_dets[img_id] = fused

            metrics = _evaluate_dataset(all_dets, raw_gts, iou_thr=0.5)
            metrics["mAP50_95"] = _evaluate_map50_95(all_dets, raw_gts)
            return metrics, all_dets

        if args.mode == "single":
            method = args.fusion
            iou_thr = args.wbf_iou if method == "wbf" else args.nms_iou
            extra = {"conf_type": args.wbf_conf_type} if method == "wbf" else None
            metrics, dets = run_config(method, float(args.conf), float(iou_thr), extra=extra)
            rows = [
                {
                    "method": method,
                    "conf": float(args.conf),
                    "iou": float(iou_thr),
                    "precision": metrics["precision"],
                    "recall": metrics["recall"],
                    "f1": metrics["f1"],
                    "mAP50": metrics["mAP50"],
                    "mAP50_95": metrics["mAP50_95"],
                    "fp": metrics["fp"],
                    "tp": metrics["tp"],
                    "gt": metrics["gt"],
                }
            ]
            best = rows[0]
            best_metrics = metrics
            best_dets = dets
            pd.DataFrame(rows).to_csv(out_dir / "calibration_grid.csv", index=False)
        else:
            conf_grid = [0.15, 0.25, 0.35, 0.45, 0.55]
            nms_grid = [0.3, 0.45, 0.6]
            wbf_grid = [0.3, 0.45, 0.6]
            rows = []
            best = None
            best_payload = None
            methods = [
                ("nms", nms_grid, None),
                ("soft_linear", nms_grid, None),
                ("soft_gaussian", nms_grid, None),
                ("wbf", wbf_grid, {"conf_type": args.wbf_conf_type}),
            ]
            for method, iou_list, extra in methods:
                for conf_thr in conf_grid:
                    for iou_thr in iou_list:
                        metrics, _ = run_config(method, conf_thr, iou_thr, extra=extra)
                        rows.append(
                            {
                                "method": method,
                                "conf": conf_thr,
                                "iou": iou_thr,
                                "precision": metrics["precision"],
                                "recall": metrics["recall"],
                                "f1": metrics["f1"],
                                "mAP50": metrics["mAP50"],
                                "mAP50_95": metrics["mAP50_95"],
                                "fp": metrics["fp"],
                                "tp": metrics["tp"],
                                "gt": metrics["gt"],
                            }
                        )
                        if best is None or metrics["f1"] > best["f1"]:
                            best = {**rows[-1]}
                            best_payload = {"extra": extra, "pr_curve": metrics.get("pr_curve")}
            pd.DataFrame(rows).to_csv(out_dir / "calibration_grid.csv", index=False)
            best_metrics, best_dets = run_config(best["method"], best["conf"], best["iou"], extra=best_payload["extra"])

        fn = int(best_metrics["gt"] - best_metrics["tp"])
        pr_curve = best_metrics.get("pr_curve", {"recall": [], "precision": []})
        recalls = pr_curve.get("recall", [])
        precisions = pr_curve.get("precision", [])
        f1s = []
        for p, r in zip(precisions, recalls):
            f1s.append(float((2 * float(p) * float(r)) / (float(p) + float(r) + 1e-16)))

        if recalls and precisions:
            _plot_curve(recalls, precisions, out_dir / "PR_curve.png", "Recall", "Precision", f"PR Curve ({split_name})")
            _plot_curve(recalls, f1s, out_dir / "F1_curve.png", "Recall", "F1", f"F1 Curve ({split_name})")

        per_image = _per_image_fp_fn(best_dets, raw_gts, iou_thr=0.5)
        per_image_rows = [{"img_id": k, **v} for k, v in per_image.items()]
        pd.DataFrame(per_image_rows).to_csv(out_dir / "analysis" / "per_image_fp_fn.csv", index=False)

        if args.save_visualizations:
            vis_dir = out_dir / "visualizations" / "best"
            vis_dir.mkdir(parents=True, exist_ok=True)
            for img_path in image_paths[: args.vis_count]:
                img_id = img_path.stem
                img = read_image(str(img_path))
                gts = raw_gts.get(img_id, [])
                dets = best_dets.get(img_id, [])
                out_path = vis_dir / f"{img_path.name}"
                _draw_boxes(img, dets, gts, out_path)

            fp_dir = out_dir / "analysis" / "fp_examples"
            fn_dir = out_dir / "analysis" / "fn_examples"
            fp_dir.mkdir(parents=True, exist_ok=True)
            fn_dir.mkdir(parents=True, exist_ok=True)

            top_fp = sorted(per_image_rows, key=lambda x: x["fp"], reverse=True)[: min(20, len(per_image_rows))]
            top_fn = sorted(per_image_rows, key=lambda x: x["fn"], reverse=True)[: min(20, len(per_image_rows))]

            for row in top_fp:
                img_id = row["img_id"]
                img_path = source_dir / f"{img_id}.jpg"
                if not img_path.exists():
                    continue
                img = read_image(str(img_path))
                gts = raw_gts.get(img_id, [])
                dets = best_dets.get(img_id, [])
                _draw_boxes(img, dets, gts, fp_dir / f"{img_id}.jpg")

            for row in top_fn:
                img_id = row["img_id"]
                img_path = source_dir / f"{img_id}.jpg"
                if not img_path.exists():
                    continue
                img = read_image(str(img_path))
                gts = raw_gts.get(img_id, [])
                dets = best_dets.get(img_id, [])
                _draw_boxes(img, dets, gts, fn_dir / f"{img_id}.jpg")

        with open(out_dir / "predictions" / "fused_predictions.json", "w", encoding="utf-8") as f:
            json.dump({"split": split_name, "best_setting": best, "detections": best_dets}, f, ensure_ascii=False)

        model_name = Path(args.weights).parent.parent.name
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        exp_name = f"{save_dir.name}_{split_name}" if split_name != "custom" else save_dir.name

        avg_s_per_img = float(forward_time_s / max(1, len(image_paths)))
        exp_summary = {
            "exp_name": exp_name,
            "model": model_name,
            "split": split_name,
            "pipeline": "SAHI slicing + TTA multi-scale+flip + fusion + calibration",
            "sahi": {"slice_size": args.slice_size, "overlap_ratio": args.overlap_ratio},
            "tta": {"enabled": bool(args.tta), "scales": scales, "flip": "lr" if args.tta else "none"},
            "best_setting": best,
            "best_metrics": {
                "precision": round(best_metrics["precision"], 4),
                "recall": round(best_metrics["recall"], 4),
                "f1": round(best_metrics["f1"], 4),
                "mAP50": round(best_metrics["mAP50"], 4),
                "mAP50_95": round(best_metrics.get("mAP50_95", 0.0), 4),
                "fp": int(best_metrics["fp"]),
                "fn": int(fn),
                "tp": int(best_metrics["tp"]),
                "gt": int(best_metrics["gt"]),
            },
            "timing": {
                "images": int(len(image_paths)),
                "forward_time_s": round(forward_time_s, 3),
                "forward_fps": round(forward_fps, 4),
                "avg_time_per_image_s": round(avg_s_per_img, 6),
            },
            "custom_registry": {
                "lwsdet_registry_loaded": bool(split_registry_loaded),
            },
            "timestamp": timestamp,
        }

        with open(out_dir / "exp_summary.json", "w", encoding="utf-8") as f:
            json.dump(exp_summary, f, indent=4, ensure_ascii=False)

        calibration_report = {
            "exp_name": exp_name,
            "split": split_name,
            "best_setting": best,
            "best_metrics": exp_summary["best_metrics"],
            "timing": exp_summary["timing"],
            "notes": {
                "iou_eval": 0.5,
                "metric_definition": "Precision/Recall/F1 from global matching at IoU>=0.5; AP50 from global PR integration",
            },
            "curves": {
                "pr_curve": pr_curve,
            },
        }
        with open(out_dir / "calibration_report.json", "w", encoding="utf-8") as f:
            json.dump(calibration_report, f, indent=4, ensure_ascii=False)

        master_csv = Path(args.master_csv)
        record = {
            "exp_name": exp_name,
            "model": args.weights,
            "data_yaml": None,
            "imgsz": None,
            "epochs": 0,
            "batch": 1,
            "device": "0",
            "params": None,
            "gflops": None,
            "fps": None,
            "train_time_s": None,
            "train_wall_time_s": None,
            "best_epoch": None,
            "precision": None,
            "recall": None,
            "mAP50": None,
            "mAP50_95": None,
            "best_weight_path": args.weights,
            "last_weight_path": None,
            "results_csv_path": None,
            "save_dir": str(out_dir),
            "exp_summary_path": str(out_dir / "exp_summary.json"),
            "timestamp": timestamp,
            "infer_split": split_name,
            "infer_precision": round(best_metrics["precision"], 6),
            "infer_recall": round(best_metrics["recall"], 6),
            "infer_f1": round(best_metrics["f1"], 6),
            "infer_mAP50": round(best_metrics["mAP50"], 6),
            "infer_fp": int(best_metrics["fp"]),
            "infer_fn": int(fn),
            "infer_time_s": round(forward_time_s, 6),
            "infer_fps": round(forward_fps, 6),
            "infer_conf": float(best["conf"]),
            "infer_fusion": str(best["method"]),
            "infer_iou": float(best["iou"]),
            "infer_slice_size": int(args.slice_size),
            "infer_overlap": float(args.overlap_ratio),
            "infer_scales": ",".join(map(str, scales)),
        }
        _append_master_record(master_csv, record)

        return exp_summary

    split_summaries = []
    for item in splits_to_run:
        split_name = item["split"]
        out_dir = save_dir / split_name if split_name != "custom" else save_dir
        split_summaries.append(run_one_split(split_name, item["source"], item["labels"], out_dir))

    with open(save_dir / "exp_summary.json", "w", encoding="utf-8") as f:
        json.dump({"root": save_dir.name, "runs": split_summaries}, f, indent=4, ensure_ascii=False)

    base_model = str(args.base_model).strip()
    if not base_model:
        try:
            base_model = Path(args.weights).parent.parent.name
        except Exception:
            base_model = ""

    model_type_label = str(args.model_type_label).strip() or str(args.model_type)
    pretrained = str(args.pretrained).strip()

    summary_lines = [
        "# Inference Summary",
        "",
        f"- experiment_name: {save_dir.name}",
        f"- base_model: {base_model}",
        f"- model_type: {model_type_label}",
        f"- dataset_version: {args.dataset_version}",
        f"- eval_level: {args.eval_level}",
        "- inference_pipeline: SAHI_TTA_WBF",
        f"- conf: {float(args.conf)}",
        f"- iou_merge: {float(args.wbf_iou)}",
        f"- pretrained: {pretrained}",
        f"- weight_path: {args.weights}",
        "",
    ]

    per_split_metrics: dict[str, dict] = {}
    for split_name in [s.get("split") for s in split_summaries if isinstance(s, dict) and s.get("split")]:
        split_dir = save_dir / split_name
        fused_path = split_dir / "predictions" / "fused_predictions.json"
        split_exp_summary_path = split_dir / "exp_summary.json"
        if fused_path.exists():
            payload = json.loads(fused_path.read_text(encoding="utf-8"))
            (save_dir / f"{split_name}_predictions.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        if split_exp_summary_path.exists():
            split_exp = json.loads(split_exp_summary_path.read_text(encoding="utf-8"))
            best_metrics = split_exp.get("best_metrics", {}) or {}
            timing = split_exp.get("timing", {}) or {}
            settings = split_exp.get("best_setting", {}) or {}
            per_split_metrics[split_name] = {"best_metrics": best_metrics, "timing": timing, "settings": settings, "timestamp": split_exp.get("timestamp", "")}

            imgs = max(1, int(timing.get("images", 1) or 1))
            avg_s = float(timing.get("forward_time_s", 0.0)) / float(max(1, imgs))
            out_metrics = {
                "experiment_name": save_dir.name,
                "split": split_name,
                "best_metrics": best_metrics,
                "timing": {
                    **timing,
                    "total_inference_time_s": timing.get("forward_time_s"),
                    "fps": timing.get("forward_fps"),
                    "avg_time_per_image_s": avg_s,
                },
                "settings": settings,
                "timestamp": split_exp.get("timestamp", ""),
            }
            (save_dir / f"{split_name}_metrics.json").write_text(json.dumps(out_metrics, indent=2, ensure_ascii=False), encoding="utf-8")

            err_root = save_dir / f"{split_name}_error_cases"
            (err_root / "fp_examples").mkdir(parents=True, exist_ok=True)
            (err_root / "fn_examples").mkdir(parents=True, exist_ok=True)
            src_fp = split_dir / "analysis" / "fp_examples"
            src_fn = split_dir / "analysis" / "fn_examples"
            if src_fp.exists():
                for p in src_fp.glob("*.jpg"):
                    shutil.copy2(p, err_root / "fp_examples" / p.name)
            if src_fn.exists():
                for p in src_fn.glob("*.jpg"):
                    shutil.copy2(p, err_root / "fn_examples" / p.name)

            summary_lines.extend([f"## {split_name}", ""])
            summary_lines.append(f"- Precision: {best_metrics.get('precision')}")
            summary_lines.append(f"- Recall: {best_metrics.get('recall')}")
            summary_lines.append(f"- F1: {best_metrics.get('f1')}")
            summary_lines.append(f"- mAP50: {best_metrics.get('mAP50')}")
            summary_lines.append(f"- mAP50-95: {best_metrics.get('mAP50_95')}")
            if all(k in best_metrics for k in ["tp", "fp", "gt"]):
                fn = int(best_metrics.get("gt", 0) - best_metrics.get("tp", 0))
                summary_lines.append(f"- TP/FP/FN/GT: {best_metrics.get('tp')}/{best_metrics.get('fp')}/{fn}/{best_metrics.get('gt')}")
            if all(k in timing for k in ["forward_time_s", "forward_fps", "images"]):
                imgs = max(1, int(timing.get("images", 1)))
                avg_s = float(timing.get("forward_time_s", 0.0)) / float(imgs)
                summary_lines.append(f"- Time(s)/FPS/avg(s/img): {timing.get('forward_time_s')}/{timing.get('forward_fps')}/{avg_s}")
            summary_lines.append("")

    (save_dir / "inference_summary.md").write_text("\n".join(summary_lines), encoding="utf-8")

    valm = per_split_metrics.get("val", {})
    testm = per_split_metrics.get("test", {})

    def _pack_split(m: dict):
        best = (m.get("best_metrics") or {}).copy()
        timing = (m.get("timing") or {}).copy()
        tp = int(best.get("tp", 0))
        fp = int(best.get("fp", 0))
        gt = int(best.get("gt", 0))
        fn = int(gt - tp)
        time_s = float(timing.get("forward_time_s", 0.0))
        fps = float(timing.get("forward_fps", 0.0))
        images = int(timing.get("images", 0))
        avg_s = float(time_s / max(1, images)) if images else ""
        return {
            "precision": best.get("precision", ""),
            "recall": best.get("recall", ""),
            "f1": best.get("f1", ""),
            "mAP50": best.get("mAP50", ""),
            "mAP50_95": best.get("mAP50_95", ""),
            "tp": tp,
            "fp": fp,
            "fn": fn,
            "gt": gt,
            "time_s": time_s,
            "fps": fps,
            "avg_s_per_img": avg_s,
        }

    val_pack = _pack_split(valm) if valm else {}
    test_pack = _pack_split(testm) if testm else {}

    compare_row = {
        "experiment_name": save_dir.name,
        "dataset_version": str(args.dataset_version),
        "inference_pipeline": "SAHI_TTA_WBF",
        "conf": float(args.conf),
        "iou_merge": float(args.wbf_iou),
        "weights": str(args.weights),
        "output_dir": str(save_dir),
        "val_precision": val_pack.get("precision", ""),
        "val_recall": val_pack.get("recall", ""),
        "val_f1": val_pack.get("f1", ""),
        "val_mAP50": val_pack.get("mAP50", ""),
        "val_mAP50_95": val_pack.get("mAP50_95", ""),
        "val_tp": val_pack.get("tp", ""),
        "val_fp": val_pack.get("fp", ""),
        "val_fn": val_pack.get("fn", ""),
        "val_gt": val_pack.get("gt", ""),
        "val_time_s": val_pack.get("time_s", ""),
        "val_fps": val_pack.get("fps", ""),
        "val_avg_s_per_img": val_pack.get("avg_s_per_img", ""),
        "test_precision": test_pack.get("precision", ""),
        "test_recall": test_pack.get("recall", ""),
        "test_f1": test_pack.get("f1", ""),
        "test_mAP50": test_pack.get("mAP50", ""),
        "test_mAP50_95": test_pack.get("mAP50_95", ""),
        "test_tp": test_pack.get("tp", ""),
        "test_fp": test_pack.get("fp", ""),
        "test_fn": test_pack.get("fn", ""),
        "test_gt": test_pack.get("gt", ""),
        "test_time_s": test_pack.get("time_s", ""),
        "test_fps": test_pack.get("fps", ""),
        "test_avg_s_per_img": test_pack.get("avg_s_per_img", ""),
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "base_model": base_model,
        "eval_level": str(args.eval_level),
        "model_type": model_type_label,
        "source_train_dir": str(Path(args.weights).parent.parent) if Path(args.weights).exists() else "",
        "weight_path": str(args.weights),
        "pretrained": pretrained,
    }
    if not bool(args.skip_compare_inference_record):
        _upsert_compare_inference_record(Path(args.compare_inference_csv), "experiment_name", save_dir.name, compare_row)
if __name__ == "__main__":
    main()
