import json
import math
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd


@dataclass(frozen=True)
class ModelSpec:
    key: str
    model_type: str
    train_dir: Path
    inference_dir: Path
    framework: str


def _read_json(p: Path) -> dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def _safe_float(v: Any) -> float | None:
    try:
        if v is None:
            return None
        if isinstance(v, float) and math.isnan(v):
            return None
        return float(v)
    except Exception:
        return None


def _best_from_ultra_results(results_csv: Path) -> dict[str, Any] | None:
    df = pd.read_csv(results_csv)
    df.columns = [c.strip() for c in df.columns]

    col_epoch = "epoch"
    col_time = "time" if "time" in df.columns else None
    col_p = "metrics/precision(B)"
    col_r = "metrics/recall(B)"
    col_m50 = "metrics/mAP50(B)"
    col_m95 = "metrics/mAP50-95(B)"

    if col_m50 not in df.columns or col_m95 not in df.columns or col_epoch not in df.columns:
        return None

    best_idx_m50 = int(df[col_m50].astype(float).idxmax())
    best_idx_m95 = int(df[col_m95].astype(float).idxmax())

    best_m50 = df.loc[best_idx_m50]
    best_m95 = df.loc[best_idx_m95]
    last = df.iloc[-1]

    train_time_s = _safe_float(last.get(col_time)) if col_time else None
    train_time_hours = None if train_time_s is None else float(train_time_s) / 3600.0

    return {
        "epochs": int(last.get(col_epoch, len(df))),
        "train_time_hours": train_time_hours,
        "best_epoch_by_mAP50": int(best_m50.get(col_epoch)),
        "best_precision_by_mAP50": _safe_float(best_m50.get(col_p)),
        "best_recall_by_mAP50": _safe_float(best_m50.get(col_r)),
        "best_mAP50": _safe_float(best_m50.get(col_m50)),
        "corresponding_mAP50_95": _safe_float(best_m50.get(col_m95)),
        "best_epoch_by_mAP50_95": int(best_m95.get(col_epoch)),
        "precision_at_best_mAP50_95": _safe_float(best_m95.get(col_p)),
        "recall_at_best_mAP50_95": _safe_float(best_m95.get(col_r)),
        "mAP50_at_best_mAP50_95": _safe_float(best_m95.get(col_m50)),
        "best_mAP50_95": _safe_float(best_m95.get(col_m95)),
        "last_epoch_precision": _safe_float(last.get(col_p)),
        "last_epoch_recall": _safe_float(last.get(col_r)),
        "last_epoch_mAP50": _safe_float(last.get(col_m50)),
        "last_epoch_mAP50_95": _safe_float(last.get(col_m95)),
    }


def _infer_metrics(infer_dir: Path) -> dict[str, Any]:
    out: dict[str, Any] = {
        "eval_level": "original_full_image",
        "inference_pipeline": "SAHI_TTA_WBF",
        "val_total_inference_time_s": None,
        "val_fps": None,
        "val_avg_time_per_image_s": None,
        "test_total_inference_time_s": None,
        "test_fps": None,
        "test_avg_time_per_image_s": None,
        "speed_source": "unavailable",
        "val_precision": None,
        "val_recall": None,
        "val_f1": None,
        "val_mAP50": None,
        "val_mAP50_95": None,
        "val_FP": None,
        "val_FN": None,
        "test_precision": None,
        "test_recall": None,
        "test_f1": None,
        "test_mAP50": None,
        "test_mAP50_95": None,
        "test_FP": None,
        "test_FN": None,
    }

    def _fill_from_payload(payload: dict[str, Any], split_prefix: str) -> None:
        if "best_metrics" in payload:
            m = payload.get("best_metrics", {}) or {}
            t = payload.get("timing", {}) or {}
            total_time = _safe_float(t.get("forward_time_s"))
            fps = _safe_float(t.get("forward_fps"))
            images = int(t.get("images", 0) or 0)
            avg = (total_time / images) if (total_time is not None and images > 0) else None
        else:
            m = payload.get("metrics", {}) or {}
            t = payload.get("timing", {}) or {}
            total_time = _safe_float(t.get("total_time_s"))
            fps = _safe_float(t.get("fps"))
            avg = _safe_float(t.get("avg_time_per_image_s"))

        out[f"{split_prefix}_total_inference_time_s"] = total_time
        out[f"{split_prefix}_fps"] = fps
        out[f"{split_prefix}_avg_time_per_image_s"] = avg

        out[f"{split_prefix}_precision"] = _safe_float(m.get("precision"))
        out[f"{split_prefix}_recall"] = _safe_float(m.get("recall"))
        out[f"{split_prefix}_f1"] = _safe_float(m.get("f1"))
        out[f"{split_prefix}_mAP50"] = _safe_float(m.get("mAP50"))
        out[f"{split_prefix}_mAP50_95"] = _safe_float(m.get("mAP50_95"))
        out[f"{split_prefix}_FP"] = int(m.get("fp", 0) or 0)
        out[f"{split_prefix}_FN"] = int(m.get("fn", 0) or 0)

    valm = infer_dir / "val_metrics.json"
    testm = infer_dir / "test_metrics.json"
    if valm.exists() and testm.exists():
        out["speed_source"] = "metrics_json"
        _fill_from_payload(_read_json(valm), "val")
        _fill_from_payload(_read_json(testm), "test")
        return out

    md = infer_dir / "inference_summary.md"
    if md.exists():
        out["speed_source"] = "inference_summary"
    return out


def _classify_pretrained(model_type: str, pretrained_str: str | None) -> str:
    s = (pretrained_str or "").lower()
    if "imagenet" in s:
        return "ImageNet backbone only"
    if "coco" in s:
        return "COCO-pretrained"
    mt = model_type.lower()
    if mt.startswith("yolo"):
        return "COCO-pretrained"
    if mt.startswith("rt-detr") or mt.startswith("rtdetr"):
        return "COCO-pretrained"
    return "custom / other"


def _ultralytics_params_flops(best_weight: Path, model_type: str, is_rtdetr: bool) -> tuple[float | None, float | None, str, str]:
    params_m = None
    flops_g = None
    flops_source = "unavailable"
    note = ""

    try:
        if model_type == "Wavelet+SSM":
            import importlib.util
            import sys

            infer_path = Path(__file__).resolve().parent / "infer_sahi_tta.py"
            spec = importlib.util.spec_from_file_location("infer_sahi_tta_patch", infer_path)
            if spec is None or spec.loader is None:
                raise RuntimeError("cannot import infer_sahi_tta.py for Wavelet+SSM patching")
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            main_mod = sys.modules.get("__main__")
            if main_mod is not None:
                for name in ["WaveletBlock", "MambaBlock", "PatchedC2f", "dwt_haar"]:
                    if hasattr(mod, name):
                        setattr(main_mod, name, getattr(mod, name))

        import torch
        from thop import profile

        if is_rtdetr:
            from ultralytics import RTDETR

            u = RTDETR(str(best_weight))
        else:
            from ultralytics import YOLO

            u = YOLO(str(best_weight))

        m = u.model
        m.eval()
        params_m = sum(p.numel() for p in m.parameters()) / 1e6

        dummy = torch.zeros((1, 3, 640, 640), dtype=torch.float32)
        macs, _ = profile(m, inputs=(dummy,), verbose=False)
        flops_g = float(macs) * 2.0 / 1e9
        flops_source = "thop"
        note = "FLOPs estimated as 2*MACs via thop on 1x3x640x640"
    except Exception as e:
        note = f"complexity extraction failed: {type(e).__name__}: {e}"

    return params_m, flops_g, flops_source, note


def _torchvision_params_flops(model_name: str, weight_path: Path) -> tuple[float | None, float | None, str, str]:
    params_m = None
    flops_g = None
    flops_source = "unavailable"
    note = ""

    try:
        import torch
        from thop import profile
        from torchvision.models.detection import fasterrcnn_resnet50_fpn, retinanet_resnet50_fpn

        if model_name == "retinanet_resnet50_fpn":
            model = retinanet_resnet50_fpn(weights=None, weights_backbone=None, num_classes=2)
        elif model_name == "fasterrcnn_resnet50_fpn":
            model = fasterrcnn_resnet50_fpn(weights=None, weights_backbone=None, num_classes=2)
        else:
            return None, None, "unavailable", f"unsupported torchvision model_name: {model_name}"

        sd = torch.load(str(weight_path), map_location="cpu")
        model.load_state_dict(sd, strict=True)
        model.eval()

        params_m = sum(p.numel() for p in model.parameters()) / 1e6

        class Wrap(torch.nn.Module):
            def __init__(self, m):
                super().__init__()
                self.m = m

            def forward(self, x):
                return self.m([x])

        w = Wrap(model)
        dummy = torch.zeros((3, 640, 640), dtype=torch.float32)
        macs, _ = profile(w, inputs=(dummy,), verbose=False)
        flops_g = float(macs) * 2.0 / 1e9
        flops_source = "thop"
        note = "FLOPs estimated as 2*MACs via thop wrapper(model([x])) with x=3x640x640"

    except Exception as e:
        note = f"complexity extraction failed: {type(e).__name__}: {e}"

    return params_m, flops_g, flops_source, note


def _get_ultra_train_metrics(train_dir: Path, model_type: str) -> dict[str, Any] | None:
    exp_summary = train_dir / "exp_summary.json"
    if exp_summary.exists():
        s = _read_json(exp_summary)
        out: dict[str, Any] = {
            "model_name": s.get("model_name") or model_type,
            "dataset_version": s.get("dataset_version") or s.get("data_version"),
            "train_status": s.get("train_status") or "completed",
            "epochs": int(s.get("epochs", 0) or 0),
            "train_time_hours": _safe_float(s.get("train_time_hours")),
            "best_epoch_by_mAP50": s.get("best_epoch_by_mAP50"),
            "best_precision_by_mAP50": _safe_float(s.get("best_precision_by_mAP50")),
            "best_recall_by_mAP50": _safe_float(s.get("best_recall_by_mAP50")),
            "best_mAP50": _safe_float(s.get("best_mAP50")),
            "corresponding_mAP50_95": _safe_float(s.get("corresponding_mAP50_95")),
            "best_epoch_by_mAP50_95": s.get("best_epoch_by_mAP50_95"),
            "best_mAP50_95": _safe_float(s.get("best_mAP50_95")),
            "last_epoch_precision": _safe_float(s.get("last_epoch_precision")),
            "last_epoch_recall": _safe_float(s.get("last_epoch_recall")),
            "last_epoch_mAP50": _safe_float(s.get("last_epoch_mAP50")),
            "last_epoch_mAP50_95": _safe_float(s.get("last_epoch_mAP50_95")),
            "pretrained": s.get("pretrained", ""),
        }
        if out["train_time_hours"] is None and s.get("train_time") is not None:
            try:
                out["train_time_hours"] = float(s.get("train_time")) / 3600.0
            except Exception:
                pass
        return out

    results_csv = train_dir / "results.csv"
    if not results_csv.exists():
        return None
    m = _best_from_ultra_results(results_csv)
    if not m:
        return None

    args_yaml = train_dir / "args.yaml"
    pretrained_str = ""
    model_name = model_type
    dataset_version = "slice640_balanced_rebuild_v1"
    if args_yaml.exists():
        txt = args_yaml.read_text(encoding="utf-8", errors="ignore")
        mm = re.search(r"^model:\s*(.+)$", txt, flags=re.M)
        if mm:
            model_name = mm.group(1).strip()
        pp = re.search(r"^pretrained:\s*(.+)$", txt, flags=re.M)
        if pp:
            pretrained_str = str(pp.group(1)).strip()

    return {
        "model_name": model_name,
        "dataset_version": dataset_version,
        "train_status": "completed",
        **m,
        "pretrained": pretrained_str,
    }


def _get_torchvision_train_metrics(train_dir: Path) -> dict[str, Any]:
    s = _read_json(train_dir / "exp_summary.json")
    return {
        "model_name": s.get("model_name"),
        "dataset_version": s.get("dataset_version"),
        "train_status": s.get("train_status"),
        "epochs": int(s.get("epochs", 0) or 0),
        "train_time_hours": _safe_float(s.get("train_time_hours")),
        "best_epoch_by_mAP50": s.get("best_epoch_by_mAP50"),
        "best_precision_by_mAP50": _safe_float(s.get("best_precision_by_mAP50")),
        "best_recall_by_mAP50": _safe_float(s.get("best_recall_by_mAP50")),
        "best_mAP50": _safe_float(s.get("best_mAP50")),
        "corresponding_mAP50_95": _safe_float(s.get("corresponding_mAP50_95")),
        "best_epoch_by_mAP50_95": s.get("best_epoch_by_mAP50_95"),
        "best_mAP50_95": _safe_float(s.get("best_mAP50_95")),
        "pretrained": s.get("pretrained", ""),
    }


def _upsert_csv(csv_path: Path, key_field: str, key_value: str, row: dict[str, Any]) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    if csv_path.exists():
        df = pd.read_csv(csv_path, encoding="utf-8-sig")
    else:
        df = pd.DataFrame(columns=[key_field])

    if key_field not in df.columns:
        df[key_field] = ""
    for k in row.keys():
        if k not in df.columns:
            df[k] = ""

    mask = df[key_field].astype(str).str.strip() == str(key_value).strip()
    if mask.any():
        idx = int(df[mask].index[0])
        for k, v in row.items():
            df.at[idx, k] = v
    else:
        new = {c: "" for c in df.columns}
        for k, v in row.items():
            if k in new:
                new[k] = v
        df = pd.concat([df, pd.DataFrame([new])], ignore_index=True)

    df.to_csv(csv_path, index=False, encoding="utf-8-sig")


def main():
    root = Path(r"C:\Users\admim\Desktop\Tpsyllid")

    out_csv = root / "workspace" / "experiments" / "model_complexity_speed_summary.csv"
    out_xlsx = root / "workspace" / "experiments" / "model_complexity_speed_summary.xlsx"
    out_md = root / "workspace" / "experiments" / "model_complexity_speed_summary.md"
    report_md = root / "workspace" / "recovered_records" / "complexity_speed_extraction_report.md"
    failed_csv = root / "workspace" / "experiments" / "failed_experiments_record.csv"

    models = [
        ModelSpec(
            key="wssm_wavelet_rebuild_v1",
            model_type="Wavelet+SSM",
            train_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\runs\detect\wssm_wavelet_rebuild_v1"),
            inference_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\wssm_wavelet_rebuild_v1_fullimage_sahi_tta_wbf"),
            framework="ultralytics",
        ),
        ModelSpec(
            key="yolov8s_baseline_slice640_v8s_base",
            model_type="YOLOv8s baseline",
            train_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\runs\detect\runs\psyllid_train\slice640_v8s_base"),
            inference_dir=Path(
                r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\yolov8s_baseline_slice640_v8s_base_fullimage_sahi_tta_wbf"
            ),
            framework="ultralytics",
        ),
        ModelSpec(
            key="yolov11n_rebuild_v1",
            model_type="YOLOv11n",
            train_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\runs\detect\yolov11n_rebuild_v1"),
            inference_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\yolov11n_rebuild_v1_fullimage_sahi_tta_wbf"),
            framework="ultralytics",
        ),
        ModelSpec(
            key="yolov11s_rebuild_v1",
            model_type="YOLOv11s",
            train_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\runs\detect\yolov11s_rebuild_v1"),
            inference_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\yolov11s_rebuild_v1_fullimage_sahi_tta_wbf"),
            framework="ultralytics",
        ),
        ModelSpec(
            key="retinanet_resnet50_fpn_rebuild_v1",
            model_type="RetinaNet ResNet50-FPN",
            train_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\torchvision_detectors\retinanet_resnet50_fpn_rebuild_v1"),
            inference_dir=Path(
                r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\retinanet_resnet50_fpn_rebuild_v1_fullimage_sahi_tta_wbf"
            ),
            framework="torchvision",
        ),
        ModelSpec(
            key="fasterrcnn_resnet50_fpn_rebuild_v1",
            model_type="Faster R-CNN ResNet50-FPN",
            train_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\torchvision_detectors\fasterrcnn_resnet50_fpn_rebuild_v1"),
            inference_dir=Path(
                r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\fasterrcnn_resnet50_fpn_rebuild_v1_fullimage_sahi_tta_wbf"
            ),
            framework="torchvision",
        ),
        ModelSpec(
            key="rtdetr_l_rebuild_v1",
            model_type="RT-DETR-L",
            train_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\runs\detect\rtdetr_l_rebuild_v1"),
            inference_dir=Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\rtdetr_l_rebuild_v1_fullimage_sahi_tta_wbf"),
            framework="ultralytics_rtdetr",
        ),
    ]

    failed = {
        "experiment_name": "ssdlite320_mobilenetv3_rebuild_v1",
        "model_type": "SSDLite320 MobileNetV3",
        "train_dir": str(root / "workspace" / "outputs" / "torchvision_detectors" / "ssdlite320_mobilenetv3_rebuild_v1"),
        "status": "failed",
        "reason": "training aborted before first epoch completed (no weights written)",
        "detected_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    _upsert_csv(failed_csv, "experiment_name", str(failed["experiment_name"]), failed)

    successes: list[str] = []
    flops_missing: list[str] = []
    speed_missing: list[str] = []
    load_fail: list[str] = []
    rows: list[dict[str, Any]] = []

    for m in models:
        base: dict[str, Any] = {
            "model_name": None,
            "model_type": m.model_type,
            "train_dir": str(m.train_dir),
            "inference_dir": str(m.inference_dir),
            "weight_path": None,
            "pretrained_type": None,
            "dataset_version": None,
            "eval_level": "original_full_image",
            "inference_pipeline": "SAHI_TTA_WBF",
            "train_status": None,
            "train_time_hours": None,
            "best_epoch_by_mAP50": None,
            "best_precision_by_mAP50": None,
            "best_recall_by_mAP50": None,
            "best_mAP50": None,
            "corresponding_mAP50_95": None,
            "best_epoch_by_mAP50_95": None,
            "best_mAP50_95": None,
            "params_M": None,
            "FLOPs_G": None,
            "input_size_for_flops": "640x640",
            "flops_source": "unavailable",
            "complexity_note": "",
            "val_total_inference_time_s": None,
            "val_fps": None,
            "val_avg_time_per_image_s": None,
            "test_total_inference_time_s": None,
            "test_fps": None,
            "test_avg_time_per_image_s": None,
            "speed_source": "unavailable",
            "val_precision": None,
            "val_recall": None,
            "val_f1": None,
            "val_mAP50": None,
            "val_mAP50_95": None,
            "val_FP": None,
            "val_FN": None,
            "test_precision": None,
            "test_recall": None,
            "test_f1": None,
            "test_mAP50": None,
            "test_mAP50_95": None,
            "test_FP": None,
            "test_FN": None,
        }

        try:
            if m.framework in ("ultralytics", "ultralytics_rtdetr"):
                tm = _get_ultra_train_metrics(m.train_dir, m.model_type)
                if tm is None:
                    raise FileNotFoundError("missing train metrics (exp_summary.json/results.csv)")

                best_pt = m.train_dir / "weights" / "best.pt"
                base["weight_path"] = str(best_pt) if best_pt.exists() else None
                base["model_name"] = tm.get("model_name")
                base["dataset_version"] = tm.get("dataset_version")
                base["train_status"] = tm.get("train_status")
                base["train_time_hours"] = tm.get("train_time_hours")

                for k in [
                    "best_epoch_by_mAP50",
                    "best_precision_by_mAP50",
                    "best_recall_by_mAP50",
                    "best_mAP50",
                    "corresponding_mAP50_95",
                    "best_epoch_by_mAP50_95",
                    "best_mAP50_95",
                ]:
                    base[k] = tm.get(k)

                base["pretrained_type"] = _classify_pretrained(m.model_type, tm.get("pretrained"))

                if base["weight_path"]:
                    params_m, flops_g, flops_source, note = _ultralytics_params_flops(
                        Path(base["weight_path"]), m.model_type, is_rtdetr=(m.framework == "ultralytics_rtdetr")
                    )
                    base["params_M"] = None if params_m is None else round(params_m, 3)
                    base["FLOPs_G"] = None if flops_g is None else round(flops_g, 3)
                    base["flops_source"] = flops_source
                    base["complexity_note"] = note
                else:
                    base["complexity_note"] = "missing best.pt"

            elif m.framework == "torchvision":
                tm = _get_torchvision_train_metrics(m.train_dir)
                base["model_name"] = tm.get("model_name")
                base["dataset_version"] = tm.get("dataset_version")
                base["train_status"] = tm.get("train_status")
                base["train_time_hours"] = tm.get("train_time_hours")
                for k in [
                    "best_epoch_by_mAP50",
                    "best_precision_by_mAP50",
                    "best_recall_by_mAP50",
                    "best_mAP50",
                    "corresponding_mAP50_95",
                    "best_epoch_by_mAP50_95",
                    "best_mAP50_95",
                ]:
                    base[k] = tm.get(k)

                base["pretrained_type"] = _classify_pretrained(m.model_type, tm.get("pretrained"))

                es = _read_json(m.train_dir / "exp_summary.json")
                best_w = Path(str(es.get("best_weight_path") or ""))
                base["weight_path"] = str(best_w) if best_w.exists() else None

                tv_map = {
                    "RetinaNet ResNet50-FPN": "retinanet_resnet50_fpn",
                    "Faster R-CNN ResNet50-FPN": "fasterrcnn_resnet50_fpn",
                }
                tv_name = tv_map.get(m.model_type)
                if base["weight_path"] and tv_name:
                    params_m, flops_g, flops_source, note = _torchvision_params_flops(tv_name, Path(base["weight_path"]))
                    base["params_M"] = None if params_m is None else round(params_m, 3)
                    base["FLOPs_G"] = None if flops_g is None else round(flops_g, 3)
                    base["flops_source"] = flops_source
                    base["complexity_note"] = note
                else:
                    base["complexity_note"] = "missing best weight or unsupported model"

            else:
                raise ValueError("unsupported framework")

            im = _infer_metrics(m.inference_dir)
            base.update(im)

            if base["FLOPs_G"] is None:
                flops_missing.append(m.key)
            if base["val_fps"] is None or base["test_fps"] is None:
                speed_missing.append(m.key)

            successes.append(m.key)
            rows.append(base)
        except Exception as e:
            load_fail.append(f"{m.key}: {type(e).__name__}: {e}")

    df = pd.DataFrame(rows)

    ordered_cols = [
        "model_name",
        "model_type",
        "train_dir",
        "inference_dir",
        "weight_path",
        "pretrained_type",
        "dataset_version",
        "eval_level",
        "inference_pipeline",
        "train_status",
        "train_time_hours",
        "best_epoch_by_mAP50",
        "best_precision_by_mAP50",
        "best_recall_by_mAP50",
        "best_mAP50",
        "corresponding_mAP50_95",
        "best_epoch_by_mAP50_95",
        "best_mAP50_95",
        "params_M",
        "FLOPs_G",
        "input_size_for_flops",
        "flops_source",
        "complexity_note",
        "val_total_inference_time_s",
        "val_fps",
        "val_avg_time_per_image_s",
        "test_total_inference_time_s",
        "test_fps",
        "test_avg_time_per_image_s",
        "speed_source",
        "val_precision",
        "val_recall",
        "val_f1",
        "val_mAP50",
        "val_mAP50_95",
        "val_FP",
        "val_FN",
        "test_precision",
        "test_recall",
        "test_f1",
        "test_mAP50",
        "test_mAP50_95",
        "test_FP",
        "test_FN",
    ]
    for c in ordered_cols:
        if c not in df.columns:
            df[c] = ""
    df = df[ordered_cols]

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False, encoding="utf-8-sig")
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as w:
        df.to_excel(w, index=False, sheet_name="summary")

    def _fmt(v: Any) -> str:
        if v is None or (isinstance(v, float) and math.isnan(v)):
            return "missing"
        if isinstance(v, float):
            return f"{v:.4f}"
        return str(v)

    md_lines = [
        "# Model Complexity/Speed/Performance Summary",
        "",
        f"- generated_at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "| model_type | params_M | FLOPs_G | val_mAP50 | val_mAP50_95 | val_fps | test_mAP50 | test_mAP50_95 | test_fps |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for _, r in df.iterrows():
        md_lines.append(
            "| "
            + " | ".join(
                [
                    str(r["model_type"]),
                    _fmt(r["params_M"]),
                    _fmt(r["FLOPs_G"]),
                    _fmt(r["val_mAP50"]),
                    _fmt(r["val_mAP50_95"]),
                    _fmt(r["val_fps"]),
                    _fmt(r["test_mAP50"]),
                    _fmt(r["test_mAP50_95"]),
                    _fmt(r["test_fps"]),
                ]
            )
            + " |"
        )
    out_md.write_text("\n".join(md_lines), encoding="utf-8")

    report = [
        "# Complexity/Speed Extraction Report",
        "",
        f"- generated_at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"- models_requested: {len(models)}",
        f"- models_succeeded: {len(successes)}",
        "",
        "## Success",
        "",
    ]
    report += [f"- {x}" for x in successes] if successes else ["- (none)"]
    report += ["", "## Missing FLOPs", ""]
    report += [f"- {x}" for x in sorted(set(flops_missing))] if flops_missing else ["- (none)"]
    report += ["", "## Missing Speed Fields", ""]
    report += [f"- {x}" for x in sorted(set(speed_missing))] if speed_missing else ["- (none)"]
    report += ["", "## Weight/Load Failures", ""]
    report += [f"- {x}" for x in load_fail] if load_fail else ["- (none)"]
    report += [
        "",
        "## Failed Experiment Record",
        "",
        f"- recorded_failed: {failed['experiment_name']}",
        f"- failed_record_path: {failed_csv}",
        "",
        "## Data Provenance",
        "",
        "- sources_used: results.csv / exp_summary.json / args.yaml / val_metrics.json / test_metrics.json / best weights (read-only load for params/FLOPs)",
        "- training_ran: no",
        "- inference_ran: no",
        "- modified_existing_results: no",
    ]
    report_md.write_text("\n".join(report), encoding="utf-8")

    print("WROTE", str(out_csv))
    print("WROTE", str(out_xlsx))
    print("WROTE", str(out_md))
    print("WROTE", str(report_md))
    print("WROTE", str(failed_csv))


if __name__ == "__main__":
    main()
