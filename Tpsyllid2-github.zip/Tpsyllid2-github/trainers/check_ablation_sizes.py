
"""
Check model sizes before training (NO training, just model initialization)
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models import register_lwsdet_modules
register_lwsdet_modules()

from ultralytics import YOLO
import thop
import torch


def check_model(yaml_path, model_name):
    print(f"\n" + "=" * 80)
    print(f"Checking: {model_name}")
    print(f"Config: {yaml_path}")
    print(f"=" * 80)
    
    try:
        model = YOLO(str(yaml_path))
        dummy_input = torch.randn(1, 3, 640, 640)
        
        flops, params = thop.profile(model.model, inputs=(dummy_input,), verbose=False)
        
        print(f"Params: {params/1e6:.2f} M")
        print(f"FLOPs:  {flops/1e9:.2f} G")
        
        return params, flops
        
    except Exception as e:
        print(f"Error checking model: {e}")
        return None, None


def main():
    print(f"=" * 80)
    print(f"Checking ALL ablation model sizes (NO TRAINING)")
    print(f"=" * 80)
    
    models = [
        ('basic', 'configs/lwsdet_b0_basic.yaml'),
        ('no_wavelet', 'configs/lwsdet_b0_no_wavelet.yaml'),
        ('no_ssm', 'configs/lwsdet_b0_no_ssm.yaml'),
        ('LWS-Det-B0-full', 'configs/lwsdet_b0.yaml'),
    ]
    
    for name, path in models:
        params, flops = check_model(path, name)
    
    print("\n" + "=" * 80)
    print(f"ALL models checked successfully!")
    print(f"=" * 80)


if __name__ == "__main__":
    main()
