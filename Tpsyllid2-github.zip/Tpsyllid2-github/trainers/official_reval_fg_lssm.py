import json
import math
import sys
import time
from pathlib import Path
from typing import Any

import pandas as pd
import torch
from thop import profile
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from models import register_lwsdet_modules


def safe_float(v: Any) -> float | None:
    try:
        if v is None:
            return None
        x = float(v)
        if math.isnan(x):
            return None
        return x
    except Exception:
        return None


def round_or_none(v: float | None, ndigits: int = 4) -> float | None:
    return None if v is None else round(float(v), ndigits)


def benchmark_fps(core_model: torch.nn.Module, device: torch.device, batch: int, imgsz: int) -> float:
    core_model = core_model.to(device)
    core_model.eval()
    dummy = torch.zeros((batch, 3, imgsz, imgsz), device=device)
    warmup = 20
    runs = 50
    with torch.no_grad():
        for i in range(warmup + runs):
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            if i == warmup:
                t0 = time.time()
            _ = core_model(dummy)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
    elapsed = time.time() - t0
    return (batch * runs) / elapsed if elapsed > 0 else 0.0


def get_complexity(core_model: torch.nn.Module, device: torch.device, imgsz: int) -> tuple[float, float]:
    core_model = core_model.to(device)
    core_model.eval()
    dummy = torch.zeros((1, 3, imgsz, imgsz), device=device)
    macs, params = profile(core_model, inputs=(dummy,), verbose=False)
    flops_g = float(macs) * 2.0 / 1e9
    params_m = float(params) / 1e6
    return params_m, flops_g


def run_official_val(
    label: str,
    weights: Path,
    data_yaml: str,
    imgsz: int,
    batch: int,
    device_arg: str,
    save_dir: Path,
) -> dict[str, Any]:
    if not weights.exists():
        raise FileNotFoundError(f"weights not found: {weights}")

    model = YOLO(str(weights))
    metrics = model.val(
        data=data_yaml,
        imgsz=imgsz,
        batch=batch,
        device=device_arg,
        plots=False,
        save_json=False,
        verbose=False,
        project=str(save_dir),
        name=label,
        exist_ok=True,
    )
    box = metrics.box

    runtime_device = torch.device(f"cuda:{device_arg}" if torch.cuda.is_available() else "cpu")
    core_model = model.model
    params_m, flops_g = get_complexity(core_model, runtime_device, imgsz)
    fps = benchmark_fps(core_model, runtime_device, batch=batch, imgsz=imgsz)

    precision = safe_float(box.mp)
    recall = safe_float(box.mr)
    f1 = None
    if precision is not None and recall is not None and (precision + recall) > 0:
        f1 = 2.0 * precision * recall / (precision + recall)

    return {
        "model": label,
        "weights": str(weights).replace("\\", "/"),
        "data_yaml": data_yaml,
        "imgsz": imgsz,
        "batch": batch,
        "device": device_arg,
        "precision": round_or_none(precision, 6),
        "recall": round_or_none(recall, 6),
        "f1": round_or_none(f1, 6),
        "map50": round_or_none(safe_float(box.map50), 6),
        "map50_95": round_or_none(safe_float(box.map), 6),
        "params_m": round_or_none(params_m, 6),
        "flops_g": round_or_none(flops_g, 6),
        "fps": round_or_none(fps, 6),
    }


def build_diagnosis_tables(diag_json: Path, out_md: Path) -> None:
    report = json.loads(diag_json.read_text(encoding="utf-8"))
    best_last = report["best_last_eval"]
    sweep = report["conf_sweep_fg_best"]
    diff_sets = report["difference_sets"]

    def fmt(v: Any, ndigits: int = 4) -> str:
        if isinstance(v, (int, float)):
            return f"{float(v):.{ndigits}f}"
        return str(v)

    rows_best_last = [
        (
            "FG-LSSM-P5 best",
            best_last["fg_best"]["precision"],
            best_last["fg_best"]["recall"],
            best_last["fg_best"]["f1"],
            best_last["fg_best"]["map50"],
            best_last["fg_best"]["map50_95"],
            best_last["fg_best"]["fp"],
            best_last["fg_best"]["fn"],
        ),
        (
            "FG-LSSM-P5 last",
            best_last["fg_last"]["precision"],
            best_last["fg_last"]["recall"],
            best_last["fg_last"]["f1"],
            best_last["fg_last"]["map50"],
            best_last["fg_last"]["map50_95"],
            best_last["fg_last"]["fp"],
            best_last["fg_last"]["fn"],
        ),
    ]

    no_ssm_hits_fg_misses = diff_sets["no_ssm_hits_fg_misses"]
    fg_hits_no_ssm_misses = diff_sets["fg_hits_no_ssm_misses"]
    sample_a = ", ".join(Path(x["image"]).name for x in no_ssm_hits_fg_misses[:5]) or "-"
    sample_b = ", ".join(Path(x["image"]).name for x in fg_hits_no_ssm_misses[:5]) or "-"

    lines = [
        "# FG-LSSM-P5 Diagnosis Tables",
        "",
        "- Scope: threshold sensitivity and miss-difference diagnosis only.",
        "- Note: these tables come from `diagnosis_report.json` and must not be mixed with official validation metrics.",
        f"- Comparison confidence: {report['conf_eval_used_for_fpfn_and_comparison']}",
        f"- Match IoU: {report['match_iou_thr']}",
        f"- NMS IoU: {report['nms_iou']}",
        "",
        "## Best vs Last",
        "",
        "| Weights | Precision | Recall | F1 | mAP50 | mAP50-95 | FP | FN |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows_best_last:
        lines.append(
            f"| {row[0]} | {fmt(row[1])} | {fmt(row[2])} | {fmt(row[3])} | {fmt(row[4])} | {fmt(row[5])} | {row[6]} | {row[7]} |"
        )

    lines += [
        "",
        "## Confidence Threshold Sweep",
        "",
        "| Conf | Precision | Recall | F1 | mAP50 | FP | FN |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in sweep:
        lines.append(
            f"| {fmt(row['conf'], 2)} | {fmt(row['precision'])} | {fmt(row['recall'])} | {fmt(row['f1'])} | {fmt(row['map50'])} | {row['fp']} | {row['fn']} |"
        )

    lines += [
        "",
        "## no-ssm vs FG Difference Counts",
        "",
        "| Category | Count | Example Files |",
        "|---|---:|---|",
        f"| no-ssm detects but FG misses | {len(no_ssm_hits_fg_misses)} | {sample_a} |",
        f"| FG detects but no-ssm misses | {len(fg_hits_no_ssm_misses)} | {sample_b} |",
        "",
    ]

    out_md.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    register_lwsdet_modules()

    out_dir = ROOT / "runs_lightweight" / "official_reval_fg_lssm"
    out_dir.mkdir(parents=True, exist_ok=True)

    data_yaml = "configs/psyllid_slice640_balanced.yaml"
    imgsz = 640
    batch = 4
    device_arg = "0"

    specs = [
        ("b0_no_ssm_best", ROOT / "runs_lightweight" / "lwsdet_b0_no_ssm" / "weights" / "best.pt"),
        ("b1_fg_lssm_p5_best", ROOT / "runs_lightweight" / "lwsdet_b1_fg_lssm_p5" / "weights" / "best.pt"),
        ("b1_fg_lssm_p5_last", ROOT / "runs_lightweight" / "lwsdet_b1_fg_lssm_p5" / "weights" / "last.pt"),
    ]

    rows = []
    for label, weights in specs:
        print(f"Running official re-validation: {label}")
        row = run_official_val(
            label=label,
            weights=weights,
            data_yaml=data_yaml,
            imgsz=imgsz,
            batch=batch,
            device_arg=device_arg,
            save_dir=out_dir,
        )
        rows.append(row)

    df = pd.DataFrame(rows)
    csv_path = out_dir / "official_reval_summary.csv"
    json_path = out_dir / "official_reval_summary.json"
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    payload = {
        "meta": {
            "data_yaml": data_yaml,
            "imgsz": imgsz,
            "batch": batch,
            "device": device_arg,
            "tta": False,
            "sahi": False,
            "wbf": False,
            "training_rerun": False,
            "note": "Official validation metrics only. Diagnosis metrics are stored separately.",
            "fps_note": "FPS is measured as images/second with batch=4 on device=0 using direct forward on dummy inputs.",
            "flops_note": "FLOPs are estimated as 2*MACs via thop on 1x3x640x640.",
        },
        "results": rows,
    }
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    diag_json = ROOT / "runs_lightweight" / "lwsdet_b1_fg_lssm_p5_diagnosis" / "diagnosis_report.json"
    diag_md = ROOT / "runs_lightweight" / "lwsdet_b1_fg_lssm_p5_diagnosis" / "diagnosis_tables.md"
    build_diagnosis_tables(diag_json, diag_md)

    print(f"WROTE {csv_path}")
    print(f"WROTE {json_path}")
    print(f"WROTE {diag_md}")
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
