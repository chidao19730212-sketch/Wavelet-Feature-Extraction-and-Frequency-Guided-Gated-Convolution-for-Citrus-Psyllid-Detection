from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

import torch


def _env_info() -> dict:
    info = {"python": sys.version.split()[0]}
    try:
        import torchvision

        info["torchvision"] = torchvision.__version__
    except Exception as e:
        info["torchvision_error"] = repr(e)
    try:
        info["torch"] = torch.__version__
        info["cuda_available"] = bool(torch.cuda.is_available())
        info["cuda_runtime"] = getattr(torch.version, "cuda", None)
        info["cuda_device_count"] = int(torch.cuda.device_count())
        info["cuda_name"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception as e:
        info["torch_error"] = repr(e)
    try:
        import sahi  # noqa: F401

        info["sahi_importable"] = True
    except Exception:
        info["sahi_importable"] = False
    return info


def _mkdir_or_fail(path: Path) -> None:
    if path.exists():
        raise SystemExit(f"OUTPUT_DIR_EXISTS\t{path}")
    path.mkdir(parents=True, exist_ok=False)


def _to_device_targets(targets: list[dict], device: torch.device) -> list[dict]:
    moved: list[dict] = []
    for t in targets:
        moved.append(
            {
                "boxes": t["boxes"].to(device),
                "labels": t["labels"].to(device),
                "image_id": t["image_id"].to(device),
                "area": t["area"].to(device),
                "iscrowd": t["iscrowd"].to(device),
            }
        )
    return moved


def _build_model(num_classes: int, prefer_imagenet_backbone: bool) -> tuple[torch.nn.Module, dict]:
    meta: dict = {"model_name": "fasterrcnn_mobilenet_v3_large_320_fpn"}
    from torchvision.models.detection import fasterrcnn_mobilenet_v3_large_320_fpn
    from torchvision.models.mobilenetv3 import MobileNet_V3_Large_Weights

    if prefer_imagenet_backbone:
        try:
            m = fasterrcnn_mobilenet_v3_large_320_fpn(
                weights=None,
                weights_backbone=MobileNet_V3_Large_Weights.IMAGENET1K_V1,
                num_classes=int(num_classes),
            )
            meta["weights"] = None
            meta["weights_backbone"] = "MobileNet_V3_Large_Weights.IMAGENET1K_V1"
            meta["num_classes"] = int(num_classes)
            meta["model_build_path"] = "weights=None + ImageNet backbone weights"
            meta["input_size"] = 320
            return m, meta
        except Exception as e:
            meta["model_build_warning"] = f"preferred API path failed: {type(e).__name__}: {e}"

    m = fasterrcnn_mobilenet_v3_large_320_fpn(weights=None, weights_backbone=None, num_classes=int(num_classes))
    meta["weights"] = None
    meta["weights_backbone"] = None
    meta["num_classes"] = int(num_classes)
    meta["model_build_path"] = "weights=None + weights_backbone=None (fallback)"
    meta["input_size"] = 320
    return m, meta


def _run_epoch(
    model: torch.nn.Module,
    loader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
) -> dict:
    model.train()
    total_loss = 0.0
    total_batches = 0
    loss_sums: dict[str, float] = {}
    for images, targets in loader:
        images = [img.to(device) for img in images]
        targets = _to_device_targets(targets, device)
        loss_dict = model(images, targets)
        loss = sum(v for v in loss_dict.values())
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        total_loss += float(loss.detach().cpu().item())
        total_batches += 1
        for k, v in loss_dict.items():
            loss_sums[k] = loss_sums.get(k, 0.0) + float(v.detach().cpu().item())

    avg = {"train_loss": total_loss / max(1, total_batches), "train_batches": int(total_batches)}
    for k, v in loss_sums.items():
        avg[k] = v / max(1, total_batches)
    return avg


@torch.no_grad()
def _val_sanity(model: torch.nn.Module, loader, device: torch.device, max_batches: int = 3) -> dict:
    model.eval()
    images_seen = 0
    dets_count = 0
    top1_scores: list[float] = []
    label_values: list[int] = []
    for b_idx, (images, _) in enumerate(loader):
        if b_idx >= max_batches:
            break
        images = [img.to(device) for img in images]
        outputs = model(images)
        for out in outputs:
            images_seen += 1
            scores = out.get("scores", None)
            labels = out.get("labels", None)
            boxes = out.get("boxes", None)
            if scores is None:
                continue
            scores_cpu = scores.detach().cpu()
            dets_count += int(scores_cpu.numel())
            if scores_cpu.numel() > 0:
                top1_scores.append(float(scores_cpu.max().item()))
            if labels is not None and labels.numel() > 0:
                label_values.extend(int(v) for v in labels.detach().cpu().tolist())
            if boxes is not None and boxes.numel() > 0:
                boxes_cpu = boxes.detach().cpu()
                _ = bool(
                    torch.all(boxes_cpu[:, 0] <= boxes_cpu[:, 2]).item()
                    and torch.all(boxes_cpu[:, 1] <= boxes_cpu[:, 3]).item()
                )
    avg_dets = float(dets_count / max(1, images_seen))
    avg_top1 = float(sum(top1_scores) / max(1, len(top1_scores))) if top1_scores else 0.0
    unique_labels = sorted(set(label_values))
    return {
        "val_images_seen": int(images_seen),
        "avg_detections_per_image": avg_dets,
        "avg_top1_score": avg_top1,
        "unique_labels_seen": unique_labels,
    }


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    keys: list[str] = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--train_limit", type=int, default=300)
    parser.add_argument("--val_limit", type=int, default=100)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--train_images",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\train\images",
    )
    parser.add_argument(
        "--val_images",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\val\images",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/fasterrcnn_mobilenetv3_320_fpn_dryrun",
    )
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    _mkdir_or_fail(out_dir)

    torch.manual_seed(int(args.seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(args.seed))

    env = _env_info()
    device = torch.device(args.device if torch.cuda.is_available() and str(args.device).startswith("cuda") else "cpu")

    root = Path(__file__).resolve().parent.parent
    datasets_dir = root / "datasets"
    if str(datasets_dir) not in sys.path:
        sys.path.insert(0, str(datasets_dir))
    from torchvision_detection_dataset import TorchvisionYoloDetectionDataset, detection_collate_fn

    train_ds = TorchvisionYoloDetectionDataset(Path(args.train_images), limit=int(args.train_limit))
    val_ds = TorchvisionYoloDetectionDataset(Path(args.val_images), limit=int(args.val_limit))

    def make_loaders(batch_size: int):
        train_loader = torch.utils.data.DataLoader(
            train_ds,
            batch_size=int(batch_size),
            shuffle=True,
            num_workers=int(args.workers),
            collate_fn=detection_collate_fn,
            drop_last=True,
        )
        val_loader = torch.utils.data.DataLoader(
            val_ds,
            batch_size=int(batch_size),
            shuffle=False,
            num_workers=int(args.workers),
            collate_fn=detection_collate_fn,
        )
        return train_loader, val_loader

    num_classes = 2
    model, model_meta = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
    model.to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    optim_meta = {"optimizer": "AdamW", "lr": float(args.lr), "weight_decay": float(args.weight_decay)}

    used_batch = int(args.batch_size)
    try:
        train_loader, val_loader = make_loaders(used_batch)
        _ = next(iter(train_loader))
    except Exception as e:
        raise SystemExit(f"DATALOADER_INIT_FAILED\t{type(e).__name__}\t{e}")

    logs: list[dict] = []
    best_loss = None
    best_epoch = None
    t0 = time.perf_counter()
    completed_epochs = 0

    def run_with_current_batch_size() -> dict:
        nonlocal best_loss, best_epoch, completed_epochs
        for epoch in range(int(args.epochs)):
            ep0 = time.perf_counter()
            tr = _run_epoch(model, train_loader, optimizer, device)
            completed_epochs += 1
            train_loss = float(tr["train_loss"])
            if best_loss is None or train_loss < float(best_loss):
                best_loss = train_loss
                best_epoch = int(epoch + 1)
                torch.save(model.state_dict(), out_dir / "best.pth")
            torch.save(model.state_dict(), out_dir / "last.pth")
            val_sanity = _val_sanity(model, val_loader, device, max_batches=3)
            ep1 = time.perf_counter()
            row = {
                "epoch": int(epoch + 1),
                "train_loss": train_loss,
                "loss_classifier": float(tr.get("loss_classifier", 0.0)),
                "loss_box_reg": float(tr.get("loss_box_reg", 0.0)),
                "loss_objectness": float(tr.get("loss_objectness", 0.0)),
                "loss_rpn_box_reg": float(tr.get("loss_rpn_box_reg", 0.0)),
                "train_batches": int(tr["train_batches"]),
                "val_images_seen": int(val_sanity["val_images_seen"]),
                "avg_detections_per_image": float(val_sanity["avg_detections_per_image"]),
                "avg_top1_score": float(val_sanity["avg_top1_score"]),
                "unique_labels_seen": json.dumps(val_sanity["unique_labels_seen"], ensure_ascii=False),
                "epoch_time_s": round(float(ep1 - ep0), 4),
                "batch_size": int(used_batch),
                "device": str(device),
            }
            logs.append(row)
        return {"status": "ok"}

    try:
        train_loader, val_loader = make_loaders(used_batch)
        run_status = run_with_current_batch_size()
    except RuntimeError as e:
        msg = str(e).lower()
        if "out of memory" in msg and used_batch > 2 and torch.cuda.is_available():
            torch.cuda.empty_cache()
            used_batch = 2
            train_loader, val_loader = make_loaders(used_batch)
            logs = []
            best_loss = None
            best_epoch = None
            completed_epochs = 0
            model, model_meta = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
            model.to(device)
            optimizer = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
            run_status = run_with_current_batch_size()
            run_status["note"] = "OOM with batch_size=4; restarted with batch_size=2"
        else:
            raise

    t1 = time.perf_counter()
    _write_csv(out_dir / "training_log.csv", logs)

    ckpt_load_ok = {"best": False, "last": False}
    reload_sanity = {}
    for name in ["best", "last"]:
        p = out_dir / f"{name}.pth"
        if not p.exists():
            continue
        try:
            m2, _ = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
            sd = torch.load(str(p), map_location="cpu")
            m2.load_state_dict(sd, strict=True)
            m2.eval()
            ckpt_load_ok[name] = True
            images, _ = next(iter(make_loaders(batch_size=1)[1]))
            out = m2([images[0]])
            if isinstance(out, list) and out and isinstance(out[0], dict):
                reload_sanity[name] = {"output_keys": sorted(list(out[0].keys()))}
        except Exception as e:
            ckpt_load_ok[name] = False
            reload_sanity[name] = {"error": f"{type(e).__name__}: {e}"}

    summary = {
        "exp_name": out_dir.name,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "env": env,
        "data": {
            "train_images_dir": str(Path(args.train_images)),
            "val_images_dir": str(Path(args.val_images)),
            "train_subset": int(len(train_ds)),
            "val_subset": int(len(val_ds)),
            "supports_empty_labels": True,
        },
        "model": model_meta,
        "train": {
            "epochs_planned": int(args.epochs),
            "epochs_completed": int(completed_epochs),
            "batch_size": int(used_batch),
            "workers": int(args.workers),
            "device": str(device),
            "seed": int(args.seed),
            **optim_meta,
            "train_time_s": round(float(t1 - t0), 4),
            "best_epoch_by_train_loss": best_epoch,
            "best_train_loss": best_loss,
            "last_epoch_train_loss": float(logs[-1]["train_loss"]) if logs else None,
        },
        "val_sanity_last_epoch": {
            "val_images_seen": int(logs[-1]["val_images_seen"]) if logs else 0,
            "avg_detections_per_image": float(logs[-1]["avg_detections_per_image"]) if logs else 0.0,
            "avg_top1_score": float(logs[-1]["avg_top1_score"]) if logs else 0.0,
            "unique_labels_seen": json.loads(logs[-1]["unique_labels_seen"]) if logs else [],
        },
        "checkpoints": {
            "best_weight_path": str(out_dir / "best.pth"),
            "last_weight_path": str(out_dir / "last.pth"),
            "best_load_ok": bool(ckpt_load_ok["best"]),
            "last_load_ok": bool(ckpt_load_ok["last"]),
            "reload_sanity": reload_sanity,
        },
        "status": {"run_status": run_status},
        "constraints": {
            "no_sahi_tta_wbf_run": True,
            "current_sahi_smoke_test_ready": bool(env.get("sahi_importable", False)),
        },
    }
    (out_dir / "exp_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    final_loss = float(logs[-1]["train_loss"]) if logs else None
    report_lines = [
        "# Faster R-CNN MobileNetV3-Large-320-FPN Dry-run Report",
        "",
        "## Environment",
        "",
        f"- Python: {env.get('python')}",
        f"- torch: {env.get('torch')}",
        f"- torchvision: {env.get('torchvision')}",
        f"- CUDA available: {env.get('cuda_available')}",
        f"- CUDA runtime: {env.get('cuda_runtime')}",
        f"- GPU: {env.get('cuda_name')}",
        "",
        "## Model",
        "",
        "- model: torchvision.models.detection.fasterrcnn_mobilenet_v3_large_320_fpn",
        "- num_classes: 2 (background + psyllid)",
        f"- build path: {model_meta.get('model_build_path')}",
        f"- ImageNet backbone pretrained: {str(model_meta.get('weights_backbone') is not None)} ({model_meta.get('weights_backbone')})",
    ]
    if model_meta.get("model_build_warning"):
        report_lines.append(f"- build warning: {model_meta.get('model_build_warning')}")
    report_lines += [
        "",
        "## Data",
        "",
        f"- train subset: {len(train_ds)}",
        f"- val subset: {len(val_ds)}",
        "- empty labels supported: True",
        "",
        "## Training",
        "",
        f"- epochs: {int(args.epochs)} (completed: {int(completed_epochs)})",
        f"- input size: 320",
        f"- batch_size: {int(used_batch)}",
        f"- workers: {int(args.workers)}",
        f"- optimizer: {optim_meta.get('optimizer')} (lr={optim_meta.get('lr')}, wd={optim_meta.get('weight_decay')})",
        f"- final train loss: {final_loss}",
        "",
        "## Val sanity (not evaluation)",
        "",
        f"- val_images_seen (sampled): {int(logs[-1]['val_images_seen']) if logs else 0}",
        f"- avg_detections_per_image: {float(logs[-1]['avg_detections_per_image']) if logs else 0.0}",
        f"- avg_top1_score: {float(logs[-1]['avg_top1_score']) if logs else 0.0}",
        f"- unique_labels_seen: {logs[-1]['unique_labels_seen'] if logs else '[]'}",
        "",
        "## Checkpoints",
        "",
        f"- best.pth saved: {bool((out_dir / 'best.pth').exists())}, reload_ok: {bool(ckpt_load_ok['best'])}",
        f"- last.pth saved: {bool((out_dir / 'last.pth').exists())}, reload_ok: {bool(ckpt_load_ok['last'])}",
        "",
        "## Recommendation",
        "",
        "- Ready to enter 100-epoch formal training: "
        + ("YES (pipeline OK; proper original-image evaluation remains a later step)" if int(completed_epochs) == int(args.epochs) and all(ckpt_load_ok.values()) else "NO (fix blockers first)"),
        f"- Current SAHI smoke-test readiness: {bool(env.get('sahi_importable', False))}",
        "",
        "## Outputs",
        "",
        "- exp_summary.json",
        "- training_log.csv",
        "- dryrun_report.md",
        "- best.pth",
        "- last.pth",
        "",
    ]
    (out_dir / "dryrun_report.md").write_text("\n".join(report_lines), encoding="utf-8")


if __name__ == "__main__":
    os.environ.setdefault("CUDA_DEVICE_ORDER", "PCI_BUS_ID")
    main()
