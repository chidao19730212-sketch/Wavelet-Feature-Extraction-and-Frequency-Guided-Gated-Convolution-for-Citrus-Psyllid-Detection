import json
import sys
from pathlib import Path
from typing import Any

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from trainers.official_reval_fg_lssm import run_official_val


def choose_yolo11n_weight() -> tuple[Path, list[str]]:
    candidates = sorted((ROOT / "runs_lightweight").glob("yolo11n*/weights/best.pt"))
    if not candidates:
        raise FileNotFoundError("No YOLO11n best.pt candidates found under runs_lightweight/")

    def score(p: Path) -> tuple[int, int, str]:
        s = str(p).lower()
        is_baseline = 0 if "yolo11n_baseline" in s else 1
        is_dryrun = 1 if "dryrun" in s else 0
        return (is_baseline, is_dryrun, s)

    ordered = sorted(candidates, key=score)
    return ordered[0], [str(p).replace("\\", "/") for p in ordered]


def upsert_horizontal_summary(row: dict[str, Any], out_csv: Path, out_json: Path, meta: dict[str, Any]) -> None:
    columns = [
        "Model",
        "Category",
        "Precision",
        "Recall",
        "F1",
        "mAP50",
        "mAP50-95",
        "Params(M)",
        "FLOPs(G)",
        "FPS",
        "Model Size(MB)",
        "Weight Path",
        "Notes",
    ]

    new_df = pd.DataFrame([row], columns=columns)
    if out_csv.exists():
        df = pd.read_csv(out_csv, encoding="utf-8-sig")
        for c in columns:
            if c not in df.columns:
                df[c] = ""
        key = df["Model"].astype(str) == str(row["Model"])
        if key.any():
            df.loc[key, columns] = new_df.iloc[0].values
        else:
            df = pd.concat([df[columns], new_df], ignore_index=True)
    else:
        df = new_df
    df = df[columns]
    df.to_csv(out_csv, index=False, encoding="utf-8-sig")

    payload = {
        "meta": meta,
        "results": df.to_dict(orient="records"),
    }
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    data_yaml = "configs/psyllid_slice640_balanced.yaml"
    imgsz = 640
    batch = 4
    device_arg = "0"

    horizontal_root = ROOT / "runs_lightweight" / "horizontal_compare"
    out_dir = horizontal_root / "yolo11n_reval"
    out_dir.mkdir(parents=True, exist_ok=True)

    selected_weight, candidate_list = choose_yolo11n_weight()
    print("YOLO11n weight candidates:")
    for c in candidate_list:
        print(f"  - {c}")
    print(f"Selected: {selected_weight}")

    result = run_official_val(
        label="yolo11n_baseline_reval",
        weights=selected_weight,
        data_yaml=data_yaml,
        imgsz=imgsz,
        batch=batch,
        device_arg=device_arg,
        save_dir=out_dir,
    )

    model_size_mb = selected_weight.stat().st_size / (1024 * 1024)
    row = {
        "Model": "YOLO11n",
        "Category": "lightweight real-time YOLO baseline",
        "Precision": result["precision"],
        "Recall": result["recall"],
        "F1": result["f1"],
        "mAP50": result["map50"],
        "mAP50-95": result["map50_95"],
        "Params(M)": result["params_m"],
        "FLOPs(G)": result["flops_g"],
        "FPS": result["fps"],
        "Model Size(MB)": round(model_size_mb, 6),
        "Weight Path": str(selected_weight).replace("\\", "/"),
        "Notes": "Official re-validation from existing YOLO11n baseline best.pt; no retraining; SAHI/TTA/WBF disabled.",
    }

    yolo_csv = out_dir / "yolo11n_reval_summary.csv"
    yolo_json = out_dir / "yolo11n_reval_summary.json"
    yolo_df = pd.DataFrame([row])
    yolo_df.to_csv(yolo_csv, index=False, encoding="utf-8-sig")
    yolo_payload = {
        "meta": {
            "data_yaml": data_yaml,
            "imgsz": imgsz,
            "batch": batch,
            "device": device_arg,
            "tta": False,
            "sahi": False,
            "wbf": False,
            "training_rerun": False,
            "candidates": candidate_list,
            "selected_weight": str(selected_weight).replace("\\", "/"),
            "selection_rule": "Prefer complete baseline best.pt over dry-run best.pt.",
            "fps_note": "FPS is measured as images/second with batch=4 on device=0 using direct forward on dummy inputs.",
            "flops_note": "FLOPs are estimated as 2*MACs via thop on 1x3x640x640.",
        },
        "results": [row],
    }
    yolo_json.write_text(json.dumps(yolo_payload, indent=2, ensure_ascii=False), encoding="utf-8")

    horizontal_csv = horizontal_root / "horizontal_summary.csv"
    horizontal_json = horizontal_root / "horizontal_summary.json"
    upsert_horizontal_summary(
        row=row,
        out_csv=horizontal_csv,
        out_json=horizontal_json,
        meta={
            "data_yaml": data_yaml,
            "imgsz": imgsz,
            "batch": batch,
            "device": device_arg,
            "tta": False,
            "sahi": False,
            "wbf": False,
            "training_rerun": False,
            "stats_source": "official_reval_horizontal.py",
            "fps_note": "FPS is measured as images/second with batch=4 on device=0 using direct forward on dummy inputs.",
            "flops_note": "FLOPs are estimated as 2*MACs via thop on 1x3x640x640.",
        },
    )

    print(f"WROTE {yolo_csv}")
    print(f"WROTE {yolo_json}")
    print(f"WROTE {horizontal_csv}")
    print(f"WROTE {horizontal_json}")
    print(yolo_df.to_string(index=False))


if __name__ == "__main__":
    main()
