
"""
Error analysis for LWS-Det-B0
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models import register_lwsdet_modules
register_lwsdet_modules()

import argparse
import json
import matplotlib.pyplot as plt
import numpy as np
from ultralytics import YOLO
import torch
from PIL import Image
import cv2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str,
                        default='runs_lightweight/lwsdet_b0_baseline/weights/best.pt',
                        help='Path to model weights')
    args = parser.parse_args()

    save_dir = Path("runs_lightweight/lwsdet_b0_error_analysis")
    save_dir.mkdir(exist_ok=True)

    print(f"=" * 80)
    print(f"LWS-Det-B0 Error Analysis")
    print(f"=" * 80)

    model = YOLO(str(args.weights))
    data_config = "configs/psyllid_slice640_balanced.yaml"

    # Run validation and save metrics
    print(f"\n1. Running validation to get detailed metrics...")
    metrics = model.val(
        data=str(data_config),
        imgsz=640,
        device=0,
        verbose=True,
        plots=True,
        save_dir=str(save_dir)
    )

    # PR Curve and other plots are saved automatically by ultralytics
    print(f"   Curves saved to {save_dir}")

    # Try to get confusion matrix info
    print(f"\n2. Analyzing FP/FN...")
    cm_path = save_dir / "confusion_matrix.png"
    if cm_path.exists():
        print(f"   Confusion matrix available at {cm_path}")

    # Try to get predictions and do error visualization on a few samples
    print(f"\n3. Generating sample error visualizations...")
    sample_save = save_dir / "samples"
    sample_save.mkdir(exist_ok=True)

    # Get a few val samples for visualization
    results = model.predict(
        source=str(Path(__file__).parent.parent / "configs/psyllid_slice640_balanced.yaml").replace(".yaml", "") + "/val/images",
        imgsz=640,
        conf=0.25,
        iou=0.45,
        save=True,
        project=str(sample_save),
        name="preds"
    )

    print(f"\n4. Summary metrics:")
    try:
        p, r, map50, map = metrics.mp, metrics.mr, metrics.map50, metrics.map
        print(f"   Precision: {p:.4f}")
        print(f"   Recall:    {r:.4f}")
        print(f"   mAP50:     {map50:.4f}")
        print(f"   mAP50-95:  {map:.4f}")

        summary = {
            "precision": float(p),
            "recall": float(r),
            "map50": float(map50),
            "map50_95": float(map),
            "notes": "Error analysis complete"
        }
        with open(save_dir / "error_analysis_summary.json", "w") as f:
            json.dump(summary, f, indent=2)
    except Exception as e:
        print(f"   Could not extract metrics: {e}")

    print(f"\n=" * 80)
    print(f"Error analysis complete! Results at {save_dir}")
    print(f"=" * 80)


if __name__ == "__main__":
    main()
