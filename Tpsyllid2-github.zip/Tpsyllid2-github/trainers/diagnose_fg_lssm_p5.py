import argparse
import json
from dataclasses import dataclass
from pathlib import Path
import sys

import cv2
import numpy as np
import torch
from ultralytics import YOLO
try:
    from ultralytics.utils.yaml import yaml_load  # type: ignore
except Exception:  # noqa: BLE001
    yaml_load = None
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from models import register_lwsdet_modules


@dataclass
class MatchStats:
    tp: int
    fp: int
    fn: int

    @property
    def precision(self) -> float:
        d = self.tp + self.fp
        return float(self.tp / d) if d else 0.0

    @property
    def recall(self) -> float:
        d = self.tp + self.fn
        return float(self.tp / d) if d else 0.0

    @property
    def f1(self) -> float:
        p, r = self.precision, self.recall
        d = p + r
        return float(2 * p * r / d) if d else 0.0


def list_images(val_source: str) -> list[Path]:
    p = Path(val_source)
    if p.is_file():
        txt = p.read_text(encoding="utf-8").strip().splitlines()
        return [Path(x.strip()) for x in txt if x.strip()]
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
    return sorted([x for x in p.rglob("*") if x.suffix.lower() in exts])


def img_to_label_path(img_path: Path) -> Path:
    parts = list(img_path.parts)
    try:
        i = parts.index("images")
        parts[i] = "labels"
        label_dir = Path(*parts[:-1])
    except ValueError:
        label_dir = img_path.parent.parent / "labels" / img_path.parent.name
    return label_dir / (img_path.stem + ".txt")


def yolo_xywhn_to_xyxy(xywhn: np.ndarray, w: int, h: int) -> np.ndarray:
    x, y, bw, bh = xywhn.T
    x1 = (x - bw / 2) * w
    y1 = (y - bh / 2) * h
    x2 = (x + bw / 2) * w
    y2 = (y + bh / 2) * h
    return np.stack([x1, y1, x2, y2], axis=1)


def load_gt_xyxy_from_size(img_path: Path, w: int, h: int) -> np.ndarray:
    label_path = img_to_label_path(img_path)
    if not label_path.exists():
        return np.zeros((0, 4), dtype=np.float32)
    rows = []
    for line in label_path.read_text(encoding="utf-8").strip().splitlines():
        if not line.strip():
            continue
        parts = line.strip().split()
        if len(parts) < 5:
            continue
        xywhn = np.array([float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])], dtype=np.float32)
        rows.append(xywhn)
    if not rows:
        return np.zeros((0, 4), dtype=np.float32)
    xywhn = np.stack(rows, axis=0)
    return yolo_xywhn_to_xyxy(xywhn, w=w, h=h).astype(np.float32)


def box_iou_xyxy(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    if a.size == 0 or b.size == 0:
        return np.zeros((a.shape[0], b.shape[0]), dtype=np.float32)
    a = a[:, None, :]
    b = b[None, :, :]
    x1 = np.maximum(a[..., 0], b[..., 0])
    y1 = np.maximum(a[..., 1], b[..., 1])
    x2 = np.minimum(a[..., 2], b[..., 2])
    y2 = np.minimum(a[..., 3], b[..., 3])
    inter = np.maximum(0.0, x2 - x1) * np.maximum(0.0, y2 - y1)
    area_a = np.maximum(0.0, a[..., 2] - a[..., 0]) * np.maximum(0.0, a[..., 3] - a[..., 1])
    area_b = np.maximum(0.0, b[..., 2] - b[..., 0]) * np.maximum(0.0, b[..., 3] - b[..., 1])
    union = area_a + area_b - inter + 1e-9
    return (inter / union).astype(np.float32)


def match_tp_fp_fn(gt_xyxy: np.ndarray, pred_xyxy: np.ndarray, iou_thr: float = 0.5) -> tuple[MatchStats, set[int], set[int]]:
    if gt_xyxy.size == 0 and pred_xyxy.size == 0:
        return MatchStats(tp=0, fp=0, fn=0), set(), set()
    if gt_xyxy.size == 0:
        return MatchStats(tp=0, fp=int(pred_xyxy.shape[0]), fn=0), set(), set()
    if pred_xyxy.size == 0:
        missed = set(range(int(gt_xyxy.shape[0])))
        return MatchStats(tp=0, fp=0, fn=int(gt_xyxy.shape[0])), set(), missed

    ious = box_iou_xyxy(pred_xyxy, gt_xyxy)
    pred_used = set()
    gt_used = set()
    pairs = []
    for pi in range(ious.shape[0]):
        for gi in range(ious.shape[1]):
            if ious[pi, gi] >= iou_thr:
                pairs.append((float(ious[pi, gi]), pi, gi))
    pairs.sort(reverse=True)
    for _, pi, gi in pairs:
        if pi in pred_used or gi in gt_used:
            continue
        pred_used.add(pi)
        gt_used.add(gi)

    tp = len(gt_used)
    fp = int(pred_xyxy.shape[0]) - len(pred_used)
    fn = int(gt_xyxy.shape[0]) - len(gt_used)
    missed_gt = set(range(int(gt_xyxy.shape[0]))) - gt_used
    matched_gt = gt_used
    return MatchStats(tp=tp, fp=fp, fn=fn), matched_gt, missed_gt


def yolo_val_metrics(model: YOLO, data_yaml: str, imgsz: int, device: int, conf: float) -> dict:
    r = model.val(data=data_yaml, imgsz=imgsz, device=device, conf=conf, plots=False, save_json=False, verbose=False)
    box = r.box
    return {
        "precision": float(box.mp),
        "recall": float(box.mr),
        "f1": float(2 * box.mp * box.mr / (box.mp + box.mr + 1e-12)),
        "map50": float(box.map50),
        "map50_95": float(box.map),
    }


def predict_xyxy(
    model: YOLO,
    source: str,
    imgsz: int,
    device: int,
    conf: float,
    iou: float,
    batch: int = 8,
) -> dict[Path, np.ndarray]:
    out: dict[Path, np.ndarray] = {}
    results = model.predict(
        source=source,
        imgsz=imgsz,
        conf=conf,
        iou=iou,
        device=device,
        batch=batch,
        stream=True,
        verbose=False,
    )
    for r in results:
        p = Path(getattr(r, "path", ""))
        if not p:
            continue
        if r.boxes is None or r.boxes.xyxy is None:
            out[p] = np.zeros((0, 4), dtype=np.float32)
            continue
        out[p] = r.boxes.xyxy.detach().cpu().numpy().astype(np.float32)
    return out


def draw_boxes(img: np.ndarray, boxes: np.ndarray, color: tuple[int, int, int], thickness: int = 2) -> np.ndarray:
    x = img.copy()
    for b in boxes:
        x1, y1, x2, y2 = [int(round(v)) for v in b.tolist()]
        cv2.rectangle(x, (x1, y1), (x2, y2), color, thickness)
    return x


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fg_best", default="runs_lightweight/lwsdet_b1_fg_lssm_p5/weights/best.pt")
    parser.add_argument("--fg_last", default="runs_lightweight/lwsdet_b1_fg_lssm_p5/weights/last.pt")
    parser.add_argument("--no_ssm_best", default="runs_lightweight/lwsdet_b0_no_ssm/weights/best.pt")
    parser.add_argument("--data", default="configs/psyllid_slice640_balanced.yaml")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--conf_eval", type=float, default=0.25)
    parser.add_argument("--iou_nms", type=float, default=0.7)
    parser.add_argument("--iou_match", type=float, default=0.5)
    parser.add_argument("--limit_vis", type=int, default=60)
    args = parser.parse_args()

    register_lwsdet_modules()

    if yaml_load is not None:
        data_cfg = yaml_load(args.data)
    else:
        data_cfg = yaml.safe_load(Path(args.data).read_text(encoding="utf-8"))
    val_source = str(data_cfg.get("val"))
    val_images = list_images(val_source)

    print(f"Found {len(val_images)} validation images.")

    gt_cache: dict[Path, np.ndarray] = {}
    for p in val_images:
        img = cv2.imread(str(p))
        if img is None:
            raise FileNotFoundError(f"Failed to read image: {p}")
        h, w = img.shape[:2]
        gt_cache[p] = load_gt_xyxy_from_size(p, w=w, h=h)
    if not val_images:
        raise FileNotFoundError(f"No validation images found from: {val_source}")

    out_dir = Path("runs_lightweight/lwsdet_b1_fg_lssm_p5_diagnosis")
    out_dir.mkdir(parents=True, exist_ok=True)

    weights = {
        "fg_best": Path(args.fg_best),
        "fg_last": Path(args.fg_last),
    }

    best_last_report = {}
    preds_cache: dict[tuple[str, float], dict[Path, np.ndarray]] = {}
    for k, w in weights.items():
        model = YOLO(str(w))
        m = yolo_val_metrics(model, data_yaml=args.data, imgsz=args.imgsz, device=args.device, conf=args.conf_eval)
        preds = predict_xyxy(model, val_source, imgsz=args.imgsz, device=args.device, conf=args.conf_eval, iou=args.iou_nms)
        preds_cache[(k, float(args.conf_eval))] = preds
        total = MatchStats(tp=0, fp=0, fn=0)
        for p in val_images:
            pred = preds.get(p, np.zeros((0, 4), dtype=np.float32))
            st, _, _ = match_tp_fp_fn(gt_cache[p], pred, iou_thr=args.iou_match)
            total.tp += st.tp
            total.fp += st.fp
            total.fn += st.fn
        best_last_report[k] = {
            "weights": str(w).replace("\\", "/"),
            "conf": args.conf_eval,
            "precision": total.precision,
            "recall": total.recall,
            "f1": total.f1,
            "map50": m["map50"],
            "map50_95": m["map50_95"],
            "fp": total.fp,
            "fn": total.fn,
        }

    fg_best_model = YOLO(str(Path(args.fg_best)))
    sweep_confs = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30]
    sweep_rows = []
    for conf in sweep_confs:
        m = yolo_val_metrics(fg_best_model, data_yaml=args.data, imgsz=args.imgsz, device=args.device, conf=conf)
        preds = predict_xyxy(fg_best_model, val_source, imgsz=args.imgsz, device=args.device, conf=conf, iou=args.iou_nms)
        preds_cache[("fg_best", float(conf))] = preds
        total = MatchStats(tp=0, fp=0, fn=0)
        for p in val_images:
            pred = preds.get(p, np.zeros((0, 4), dtype=np.float32))
            st, _, _ = match_tp_fp_fn(gt_cache[p], pred, iou_thr=args.iou_match)
            total.tp += st.tp
            total.fp += st.fp
            total.fn += st.fn
        sweep_rows.append(
            {
                "conf": conf,
                "precision": total.precision,
                "recall": total.recall,
                "f1": total.f1,
                "map50": m["map50"],
                "fp": total.fp,
                "fn": total.fn,
            }
        )

    no_ssm_model = YOLO(str(Path(args.no_ssm_best)))
    fg_preds = preds_cache.get(("fg_best", float(args.conf_eval)))
    if fg_preds is None:
        fg_preds = predict_xyxy(fg_best_model, val_source, imgsz=args.imgsz, device=args.device, conf=args.conf_eval, iou=args.iou_nms)
    no_preds = predict_xyxy(no_ssm_model, val_source, imgsz=args.imgsz, device=args.device, conf=args.conf_eval, iou=args.iou_nms)

    fg_miss_but_no_hit = []
    no_miss_but_fg_hit = []
    vis_dir_a = out_dir / "no_ssm_hits_fg_misses"
    vis_dir_b = out_dir / "fg_hits_no_ssm_misses"
    vis_dir_a.mkdir(parents=True, exist_ok=True)
    vis_dir_b.mkdir(parents=True, exist_ok=True)

    for p in val_images:
        gt = gt_cache[p]
        no_pred = no_preds.get(p, np.zeros((0, 4), dtype=np.float32))
        fg_pred = fg_preds.get(p, np.zeros((0, 4), dtype=np.float32))
        _, _, no_missed = match_tp_fp_fn(gt, no_pred, iou_thr=args.iou_match)
        _, _, fg_missed = match_tp_fp_fn(gt, fg_pred, iou_thr=args.iou_match)

        a = fg_missed - no_missed
        b = no_missed - fg_missed

        if a:
            fg_miss_but_no_hit.append({"image": str(p), "missed_gt_indices": sorted(list(a))})
        if b:
            no_miss_but_fg_hit.append({"image": str(p), "missed_gt_indices": sorted(list(b))})

    def render_side_by_side(img_path: Path, save_to: Path):
        img = cv2.imread(str(img_path))
        if img is None:
            return
        gt = gt_cache[img_path]
        left = draw_boxes(img, gt, (0, 200, 0), 2)
        left = draw_boxes(left, no_preds.get(img_path, np.zeros((0, 4), dtype=np.float32)), (255, 0, 0), 2)
        right = draw_boxes(img, gt, (0, 200, 0), 2)
        right = draw_boxes(right, fg_preds.get(img_path, np.zeros((0, 4), dtype=np.float32)), (0, 0, 255), 2)
        h = max(left.shape[0], right.shape[0])
        if left.shape[0] != h:
            left = cv2.copyMakeBorder(left, 0, h - left.shape[0], 0, 0, cv2.BORDER_CONSTANT, value=(0, 0, 0))
        if right.shape[0] != h:
            right = cv2.copyMakeBorder(right, 0, h - right.shape[0], 0, 0, cv2.BORDER_CONSTANT, value=(0, 0, 0))
        out = np.concatenate([left, right], axis=1)
        cv2.imwrite(str(save_to), out)

    for group_name, items, out_subdir in [
        ("no_ssm_hits_fg_misses", fg_miss_but_no_hit, vis_dir_a),
        ("fg_hits_no_ssm_misses", no_miss_but_fg_hit, vis_dir_b),
    ]:
        for i, it in enumerate(items[: max(args.limit_vis, 0)]):
            img_path = Path(it["image"])
            save_to = out_subdir / f"{i:04d}_{img_path.stem}.jpg"
            render_side_by_side(img_path, save_to)

    report = {
        "best_last_eval": best_last_report,
        "conf_sweep_fg_best": sweep_rows,
        "conf_eval_used_for_fpfn_and_comparison": args.conf_eval,
        "match_iou_thr": args.iou_match,
        "nms_iou": args.iou_nms,
        "difference_sets": {
            "no_ssm_hits_fg_misses": fg_miss_but_no_hit,
            "fg_hits_no_ssm_misses": no_miss_but_fg_hit,
        },
    }

    (out_dir / "diagnosis_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    print("=" * 80)
    print("Best/Last evaluation (conf={:.2f})".format(args.conf_eval))
    print("=" * 80)
    for k, v in best_last_report.items():
        print(
            f"{k}: P={v['precision']:.4f} R={v['recall']:.4f} F1={v['f1']:.4f} "
            f"mAP50={v['map50']:.4f} mAP50-95={v['map50_95']:.4f} FP={v['fp']} FN={v['fn']}"
        )
    print("\n" + "=" * 80)
    print("Confidence sweep (FG best)")
    print("=" * 80)
    for r in sweep_rows:
        print(
            f"conf={r['conf']:.2f}: P={r['precision']:.4f} R={r['recall']:.4f} F1={r['f1']:.4f} "
            f"mAP50={r['map50']:.4f} FP={r['fp']} FN={r['fn']}"
        )
    print("\nSaved to:", str(out_dir))


if __name__ == "__main__":
    main()
