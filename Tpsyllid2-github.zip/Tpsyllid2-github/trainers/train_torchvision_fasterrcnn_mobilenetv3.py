from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import os
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch


def _seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _env_info() -> dict:
    info = {"python": sys.version.split()[0]}
    try:
        import torchvision

        info["torchvision"] = torchvision.__version__
    except Exception as e:
        info["torchvision_error"] = repr(e)
    try:
        info["torch"] = torch.__version__
        info["cuda_available"] = bool(torch.cuda.is_available())
        info["cuda_runtime"] = getattr(torch.version, "cuda", None)
        info["cuda_device_count"] = int(torch.cuda.device_count())
        info["cuda_name"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception as e:
        info["torch_error"] = repr(e)
    info["sahi_importable"] = bool(importlib.util.find_spec("sahi") is not None)
    return info


def _mkdir_or_fail(p: Path) -> None:
    if p.exists():
        raise SystemExit(f"OUTPUT_DIR_EXISTS\t{p}")
    p.mkdir(parents=True, exist_ok=False)


def _to_device_targets(targets: list[dict], device: torch.device) -> list[dict]:
    moved: list[dict] = []
    for t in targets:
        moved.append(
            {
                "boxes": t["boxes"].to(device),
                "labels": t["labels"].to(device),
                "image_id": t["image_id"].to(device),
                "area": t["area"].to(device),
                "iscrowd": t["iscrowd"].to(device),
            }
        )
    return moved


def _build_model(num_classes: int, prefer_imagenet_backbone: bool) -> tuple[torch.nn.Module, dict]:
    meta: dict = {"model_name": "fasterrcnn_mobilenet_v3_large_320_fpn"}
    from torchvision.models.detection import fasterrcnn_mobilenet_v3_large_320_fpn
    from torchvision.models.mobilenetv3 import MobileNet_V3_Large_Weights

    if prefer_imagenet_backbone:
        try:
            m = fasterrcnn_mobilenet_v3_large_320_fpn(
                weights=None,
                weights_backbone=MobileNet_V3_Large_Weights.IMAGENET1K_V1,
                num_classes=int(num_classes),
            )
            meta["weights"] = None
            meta["weights_backbone"] = "MobileNet_V3_Large_Weights.IMAGENET1K_V1"
            meta["num_classes"] = int(num_classes)
            meta["model_build_path"] = "weights=None + ImageNet backbone weights"
            meta["input_size"] = 320
            return m, meta
        except Exception as e:
            meta["model_build_warning"] = f"preferred API path failed: {type(e).__name__}: {e}"

    m = fasterrcnn_mobilenet_v3_large_320_fpn(weights=None, weights_backbone=None, num_classes=int(num_classes))
    meta["weights"] = None
    meta["weights_backbone"] = None
    meta["num_classes"] = int(num_classes)
    meta["model_build_path"] = "weights=None + weights_backbone=None (fallback)"
    meta["input_size"] = 320
    return m, meta


def _box_iou_xyxy(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    if a.numel() == 0 or b.numel() == 0:
        return torch.zeros((a.shape[0], b.shape[0]), dtype=torch.float32)
    lt = torch.max(a[:, None, :2], b[None, :, :2])
    rb = torch.min(a[:, None, 2:], b[None, :, 2:])
    wh = (rb - lt).clamp(min=0)
    inter = wh[:, :, 0] * wh[:, :, 1]
    area_a = (a[:, 2] - a[:, 0]).clamp(min=0) * (a[:, 3] - a[:, 1]).clamp(min=0)
    area_b = (b[:, 2] - b[:, 0]).clamp(min=0) * (b[:, 3] - b[:, 1]).clamp(min=0)
    union = area_a[:, None] + area_b[None, :] - inter
    return inter / (union + 1e-7)


def _ap_from_pr(rec: np.ndarray, prec: np.ndarray) -> float:
    if rec.size == 0 or prec.size == 0:
        return 0.0
    mrec = np.concatenate(([0.0], rec, [1.0]))
    mpre = np.concatenate(([0.0], prec, [0.0]))
    for i in range(mpre.size - 1, 0, -1):
        mpre[i - 1] = max(mpre[i - 1], mpre[i])
    idx = np.where(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1]))


@dataclass(frozen=True)
class EvalConfig:
    score_thr: float = 0.25
    max_dets_per_image: int = 300


@torch.no_grad()
def _evaluate_single_class(
    model: torch.nn.Module,
    loader,
    device: torch.device,
    cfg: EvalConfig,
) -> dict:
    model.eval()
    gts: list[torch.Tensor] = []
    preds: list[tuple[float, torch.Tensor, int]] = []
    total_gts = 0
    fp_at_05 = 0
    tp_at_05 = 0
    fn_at_05 = 0
    img_idx = 0

    for images, targets in loader:
        images = [img.to(device) for img in images]
        outputs = model(images)
        for out, t in zip(outputs, targets):
            gt_boxes = t["boxes"].detach().cpu().float()
            gts.append(gt_boxes)
            total_gts += int(gt_boxes.shape[0])

            boxes = out.get("boxes", torch.zeros((0, 4))).detach().cpu().float()
            scores = out.get("scores", torch.zeros((0,))).detach().cpu().float()
            labels = out.get("labels", torch.zeros((0,), dtype=torch.int64)).detach().cpu()

            if boxes.numel() > 0:
                keep = labels == 1
                boxes = boxes[keep]
                scores = scores[keep]

            if boxes.numel() > 0:
                order = torch.argsort(scores, descending=True)
                boxes = boxes[order]
                scores = scores[order]

            if cfg.max_dets_per_image > 0 and boxes.shape[0] > cfg.max_dets_per_image:
                boxes = boxes[: cfg.max_dets_per_image]
                scores = scores[: cfg.max_dets_per_image]

            for b, s in zip(boxes, scores):
                preds.append((float(s.item()), b, int(img_idx)))

            if boxes.numel() == 0:
                fn_at_05 += int(gt_boxes.shape[0])
                img_idx += 1
                continue

            keep_thr = scores >= float(cfg.score_thr)
            boxes_thr = boxes[keep_thr]
            if boxes_thr.numel() == 0:
                fn_at_05 += int(gt_boxes.shape[0])
                img_idx += 1
                continue

            if gt_boxes.numel() == 0:
                fp_at_05 += int(boxes_thr.shape[0])
                img_idx += 1
                continue

            ious = _box_iou_xyxy(boxes_thr, gt_boxes)
            matched_gt = torch.zeros((gt_boxes.shape[0],), dtype=torch.bool)
            for i in range(boxes_thr.shape[0]):
                best_iou, best_j = torch.max(ious[i], dim=0)
                if float(best_iou.item()) >= 0.5 and not bool(matched_gt[best_j].item()):
                    matched_gt[best_j] = True
                    tp_at_05 += 1
                else:
                    fp_at_05 += 1
            fn_at_05 += int((~matched_gt).sum().item())
            img_idx += 1

    if total_gts == 0:
        precision = 0.0
        recall = 0.0
        f1 = 0.0
    else:
        precision = float(tp_at_05 / max(1, (tp_at_05 + fp_at_05)))
        recall = float(tp_at_05 / max(1, (tp_at_05 + fn_at_05)))
        f1 = float((2 * precision * recall) / max(1e-12, (precision + recall)))

    ap50, ap50_95 = 0.0, 0.0
    if total_gts > 0 and preds:
        preds_sorted = sorted(preds, key=lambda x: x[0], reverse=True)
        iou_thrs = [float(t) for t in np.arange(0.5, 1.0, 0.05)]
        ap_list: list[float] = []
        for iou_thr in iou_thrs:
            tp = np.zeros((len(preds_sorted),), dtype=np.float32)
            fp = np.zeros((len(preds_sorted),), dtype=np.float32)
            matched = [torch.zeros((g.shape[0],), dtype=torch.bool) for g in gts]
            for i, (_, box, im) in enumerate(preds_sorted):
                gt_boxes = gts[int(im)]
                if gt_boxes.numel() == 0:
                    fp[i] = 1.0
                    continue
                ious = _box_iou_xyxy(box[None, :], gt_boxes).squeeze(0)
                best_iou, best_j = torch.max(ious, dim=0)
                if float(best_iou.item()) >= float(iou_thr) and not bool(matched[int(im)][best_j].item()):
                    matched[int(im)][best_j] = True
                    tp[i] = 1.0
                else:
                    fp[i] = 1.0
            tp_cum = np.cumsum(tp)
            fp_cum = np.cumsum(fp)
            rec = tp_cum / float(max(1, total_gts))
            prec = tp_cum / np.maximum(1.0, tp_cum + fp_cum)
            ap_list.append(_ap_from_pr(rec, prec))
        ap50 = float(ap_list[0]) if ap_list else 0.0
        ap50_95 = float(np.mean(ap_list)) if ap_list else 0.0

    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "mAP50": float(ap50),
        "mAP50_95": float(ap50_95),
        "fp": int(fp_at_05),
        "fn": int(fn_at_05),
        "tp": int(tp_at_05),
        "gt": int(total_gts),
        "score_thr": float(cfg.score_thr),
    }


def _append_row_csv(csv_path: Path, row: dict) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    file_exists = csv_path.exists()
    fieldnames = list(row.keys())
    if file_exists:
        with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            existing = reader.fieldnames or []
        for k in existing:
            if k not in fieldnames:
                fieldnames.insert(0, k)
        for k in row.keys():
            if k not in existing:
                existing.append(k)
        fieldnames = existing
    with csv_path.open("a", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


def _better_metric(a: dict | None, b: dict) -> bool:
    if a is None:
        return True
    for k in ["mAP50_95", "mAP50", "f1"]:
        av = float(a.get(k, 0.0) or 0.0)
        bv = float(b.get(k, 0.0) or 0.0)
        if bv > av + 1e-12:
            return True
        if av > bv + 1e-12:
            return False
    return False


@torch.no_grad()
def _reload_forward_sanity(ckpt_path: Path, num_classes: int) -> dict:
    ok = False
    err = ""
    keys: list[str] = []
    try:
        m, _ = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
        sd = torch.load(str(ckpt_path), map_location="cpu")
        m.load_state_dict(sd, strict=True)
        m.eval()
        x = torch.rand(3, 320, 320)
        out = m([x])
        if isinstance(out, list) and out and isinstance(out[0], dict):
            keys = sorted(list(out[0].keys()))
        ok = True
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
    return {"ok": bool(ok), "error": err, "output_keys": keys}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--clip_norm", type=float, default=10.0)
    parser.add_argument("--val_score_thr", type=float, default=0.25)
    parser.add_argument("--max_dets_per_image", type=int, default=300)
    parser.add_argument(
        "--train_images",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\train\images",
    )
    parser.add_argument(
        "--val_images",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\val\images",
    )
    parser.add_argument(
        "--test_images",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\test\images",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/fasterrcnn_mobilenetv3_320_fpn",
    )
    args = parser.parse_args()

    _seed_all(int(args.seed))
    torch.backends.cudnn.benchmark = True

    out_dir = Path(args.output_dir)
    _mkdir_or_fail(out_dir)

    env = _env_info()
    device = torch.device(args.device if torch.cuda.is_available() and str(args.device).startswith("cuda") else "cpu")
    print(f"[init] out_dir={out_dir}", flush=True)
    print(f"[init] device={device}", flush=True)
    print(f"[init] env={json.dumps(env, ensure_ascii=False)}", flush=True)

    root = Path(__file__).resolve().parent.parent
    datasets_dir = root / "datasets"
    if str(datasets_dir) not in sys.path:
        sys.path.insert(0, str(datasets_dir))
    from torchvision_detection_dataset import TorchvisionYoloDetectionDataset, detection_collate_fn

    train_ds = TorchvisionYoloDetectionDataset(Path(args.train_images))
    val_ds = TorchvisionYoloDetectionDataset(Path(args.val_images))
    test_ds = TorchvisionYoloDetectionDataset(Path(args.test_images))
    print(f"[init] dataset sizes: train={len(train_ds)} val={len(val_ds)} test={len(test_ds)}", flush=True)

    log_csv = out_dir / "training_log.csv"
    with log_csv.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(
            [
                "epoch",
                "train_loss",
                "loss_classifier",
                "loss_box_reg",
                "loss_objectness",
                "loss_rpn_box_reg",
                "val_precision",
                "val_recall",
                "val_f1",
                "val_mAP50",
                "val_mAP50_95",
                "val_fp",
                "val_fn",
                "lr",
                "epoch_time_s",
                "batch_size",
            ]
        )

    def _count_empty(ds: TorchvisionYoloDetectionDataset) -> int:
        n = 0
        total = len(ds.image_paths)
        for i, img_path in enumerate(ds.image_paths):
            label_path = ds.labels_dir / f"{img_path.stem}.txt"
            if not label_path.exists():
                n += 1
            else:
                try:
                    if label_path.stat().st_size == 0:
                        n += 1
                    else:
                        chunk = label_path.read_bytes()[:256]
                        if not chunk.decode("utf-8", errors="ignore").strip():
                            n += 1
                except Exception:
                    n += 1
            if (i + 1) % 5000 == 0 or (i + 1) == total:
                print(f"[init] empty-scan: {i+1}/{total} (empty={n})", flush=True)
        return int(n)

    print("[init] scanning empty-label images (train/val) ...", flush=True)
    empty_train = _count_empty(train_ds)
    empty_val = _count_empty(val_ds)
    print(f"[init] empty-label counts: train={empty_train} val={empty_val}", flush=True)

    def make_loaders(batch_size: int):
        train_loader = torch.utils.data.DataLoader(
            train_ds,
            batch_size=int(batch_size),
            shuffle=True,
            num_workers=int(args.workers),
            collate_fn=detection_collate_fn,
            drop_last=True,
        )
        val_loader = torch.utils.data.DataLoader(
            val_ds,
            batch_size=int(batch_size),
            shuffle=False,
            num_workers=int(args.workers),
            collate_fn=detection_collate_fn,
        )
        return train_loader, val_loader

    num_classes = 2
    model, model_meta = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
    model.to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))

    used_batch = int(args.batch_size)
    train_loader, val_loader = make_loaders(used_batch)
    try:
        images, targets = next(iter(train_loader))
        images = [img.to(device) for img in images]
        targets = _to_device_targets(targets, device)
        loss_dict = model(images, targets)
        loss = sum(v for v in loss_dict.values())
        loss.backward()
        optimizer.zero_grad(set_to_none=True)
    except RuntimeError as e:
        msg = str(e).lower()
        if "out of memory" in msg and torch.cuda.is_available() and used_batch > 2:
            torch.cuda.empty_cache()
            used_batch = 2
            train_loader, val_loader = make_loaders(used_batch)
            print("[init] OOM with batch_size=4; fallback to batch_size=2", flush=True)
        else:
            raise

    best_metrics: dict | None = None
    best_epoch: int | None = None
    eval_cfg = EvalConfig(score_thr=float(args.val_score_thr), max_dets_per_image=int(args.max_dets_per_image))

    t0 = time.perf_counter()
    for epoch in range(1, int(args.epochs) + 1):
        ep0 = time.perf_counter()
        model.train()
        total_loss = 0.0
        batches = 0
        loss_sums: dict[str, float] = {}

        for images, targets in train_loader:
            images = [img.to(device) for img in images]
            targets = _to_device_targets(targets, device)
            optimizer.zero_grad(set_to_none=True)
            loss_dict = model(images, targets)
            loss = sum(v for v in loss_dict.values())
            loss.backward()
            if float(args.clip_norm) > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(args.clip_norm))
            optimizer.step()

            total_loss += float(loss.detach().cpu().item())
            batches += 1
            for k, v in loss_dict.items():
                loss_sums[k] = float(loss_sums.get(k, 0.0) + float(v.detach().cpu().item()))

        train_loss = float(total_loss / max(1, batches))
        loss_components = {k: float(loss_sums.get(k, 0.0) / max(1, batches)) for k in sorted(loss_sums.keys())}
        val_metrics = _evaluate_single_class(model, val_loader, device, eval_cfg)

        last_ckpt = out_dir / "last.pth"
        torch.save(model.state_dict(), last_ckpt)
        (out_dir / "last_metrics.json").write_text(json.dumps(val_metrics, indent=2, ensure_ascii=False), encoding="utf-8")

        if _better_metric(best_metrics, val_metrics):
            best_metrics = dict(val_metrics)
            best_epoch = int(epoch)
            best_ckpt = out_dir / "best.pth"
            torch.save(model.state_dict(), best_ckpt)
            (out_dir / "best_metrics.json").write_text(json.dumps(best_metrics, indent=2, ensure_ascii=False), encoding="utf-8")

        lr_now = float(optimizer.param_groups[0].get("lr", args.lr))
        ep1 = time.perf_counter()
        row = {
            "epoch": int(epoch),
            "train_loss": float(train_loss),
            "loss_classifier": float(loss_components.get("loss_classifier", 0.0)),
            "loss_box_reg": float(loss_components.get("loss_box_reg", 0.0)),
            "loss_objectness": float(loss_components.get("loss_objectness", 0.0)),
            "loss_rpn_box_reg": float(loss_components.get("loss_rpn_box_reg", 0.0)),
            "val_precision": float(val_metrics["precision"]),
            "val_recall": float(val_metrics["recall"]),
            "val_f1": float(val_metrics["f1"]),
            "val_mAP50": float(val_metrics["mAP50"]),
            "val_mAP50_95": float(val_metrics["mAP50_95"]),
            "val_fp": int(val_metrics["fp"]),
            "val_fn": int(val_metrics["fn"]),
            "lr": lr_now,
            "epoch_time_s": round(float(ep1 - ep0), 4),
            "batch_size": int(used_batch),
        }
        _append_row_csv(log_csv, row)
        print(
            f"epoch {epoch}/{int(args.epochs)} | train_loss={train_loss:.4f} | "
            f"val_mAP50_95={float(val_metrics['mAP50_95']):.4f} | val_mAP50={float(val_metrics['mAP50']):.4f} | "
            f"val_f1={float(val_metrics['f1']):.4f} | time_s={float(ep1 - ep0):.2f}",
            flush=True,
        )

    t1 = time.perf_counter()

    best_path = out_dir / "best.pth"
    last_path = out_dir / "last.pth"
    best_reload = _reload_forward_sanity(best_path, num_classes=num_classes) if best_path.exists() else {"ok": False}
    last_reload = _reload_forward_sanity(last_path, num_classes=num_classes) if last_path.exists() else {"ok": False}

    exp_summary = {
        "exp_name": out_dir.name,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "env": env,
        "model": model_meta,
        "data": {
            "train_images_dir": str(Path(args.train_images)),
            "val_images_dir": str(Path(args.val_images)),
            "test_images_dir": str(Path(args.test_images)),
            "train_images": int(len(train_ds)),
            "val_images": int(len(val_ds)),
            "test_images": int(len(test_ds)),
            "empty_train_images": int(empty_train),
            "empty_val_images": int(empty_val),
            "supports_empty_labels": True,
        },
        "train": {
            "epochs": int(args.epochs),
            "input_size": 320,
            "batch_size": int(used_batch),
            "workers": int(args.workers),
            "device": str(device),
            "optimizer": "AdamW",
            "lr": float(args.lr),
            "weight_decay": float(args.weight_decay),
            "clip_norm": float(args.clip_norm),
            "seed": int(args.seed),
            "train_time_s": round(float(t1 - t0), 4),
            "best_epoch_by_val_rule": best_epoch,
            "best_rule": "max mAP50-95; tie-breaker mAP50; tie-breaker F1",
            "val_score_thr_for_P_R_F1_FP_FN": float(args.val_score_thr),
            "max_dets_per_image": int(args.max_dets_per_image),
        },
        "best": {"metrics_path": str(out_dir / "best_metrics.json"), "ckpt_path": str(best_path)},
        "last": {"metrics_path": str(out_dir / "last_metrics.json"), "ckpt_path": str(last_path)},
        "safety_checks": {"best_reload": best_reload, "last_reload": last_reload},
        "constraints": {
            "no_original_full_image_sahi_tta_wbf_run": True,
            "do_not_add_slice_level_metrics_to_final_tables": True,
            "note_on_sahi": "This training script does not use SAHI. Original full-image SAHI+TTA+WBF evaluation remains a separate step.",
        },
    }
    (out_dir / "exp_summary.json").write_text(json.dumps(exp_summary, indent=2, ensure_ascii=False), encoding="utf-8")

    best_metrics_payload = {}
    last_metrics_payload = {}
    if (out_dir / "best_metrics.json").exists():
        best_metrics_payload = json.loads((out_dir / "best_metrics.json").read_text(encoding="utf-8"))
    if (out_dir / "last_metrics.json").exists():
        last_metrics_payload = json.loads((out_dir / "last_metrics.json").read_text(encoding="utf-8"))

    report_lines = [
        "# Faster R-CNN MobileNetV3-Large-320-FPN Training Report",
        "",
        "## Environment",
        "",
        f"- Python: {env.get('python')}",
        f"- torch: {env.get('torch')}",
        f"- torchvision: {env.get('torchvision')}",
        f"- CUDA available: {env.get('cuda_available')}",
        f"- CUDA runtime: {env.get('cuda_runtime')}",
        f"- GPU: {env.get('cuda_name')}",
        "",
        "## Model",
        "",
        "- model: torchvision.models.detection.fasterrcnn_mobilenet_v3_large_320_fpn",
        "- num_classes: 2 (background + psyllid)",
        f"- build: {model_meta.get('model_build_path')}",
        f"- ImageNet backbone pretrained: {str(model_meta.get('weights_backbone') is not None)} ({model_meta.get('weights_backbone')})",
        "",
        "## Data",
        "",
        f"- train images: {int(len(train_ds))} (empty labels: {int(empty_train)})",
        f"- val images: {int(len(val_ds))} (empty labels: {int(empty_val)})",
        f"- test images: {int(len(test_ds))}",
        "- Dataset: datasets/torchvision_detection_dataset.py (YOLO labels, no COCO conversion, no data modification)",
        "",
        "## Train Settings",
        "",
        f"- epochs: {int(args.epochs)}",
        "- input size: 320 (model default transform)",
        f"- batch_size: {int(used_batch)} (auto fallback from 4 to 2 on OOM)",
        f"- workers: {int(args.workers)}",
        f"- device: {str(device)}",
        f"- optimizer: AdamW (lr={float(args.lr)}, weight_decay={float(args.weight_decay)})",
        f"- gradient clipping max_norm: {float(args.clip_norm)}",
        f"- seed: {int(args.seed)}",
        "",
        "## Validation (sliced-level, for checkpoint selection only)",
        "",
        f"- score_thr for P/R/F1/FP/FN: {float(args.val_score_thr)}",
        "- best checkpoint rule: max mAP50-95; tie-breaker mAP50; tie-breaker F1",
        f"- best epoch: {best_epoch}",
        "",
        "### Best checkpoint metrics",
        "",
        f"- {json.dumps(best_metrics_payload, ensure_ascii=False)}",
        "",
        "### Last checkpoint metrics",
        "",
        f"- {json.dumps(last_metrics_payload, ensure_ascii=False)}",
        "",
        "## Safety Checks",
        "",
        f"- best.pth exists: {bool(best_path.exists())}, reload+forward ok: {bool(best_reload.get('ok'))}",
        f"- last.pth exists: {bool(last_path.exists())}, reload+forward ok: {bool(last_reload.get('ok'))}",
        "",
        "## Next Step",
        "",
        "- Suggested to enter original full-image SAHI+TTA+WBF test: "
        + ("YES (training complete; do NOT use sliced-level metrics in final tables)" if bool(best_reload.get("ok")) and bool(last_reload.get("ok")) else "NO (fix checkpoint issues first)"),
        "",
        "## Outputs",
        "",
        "- best.pth / last.pth",
        "- best_metrics.json / last_metrics.json",
        "- training_log.csv",
        "- exp_summary.json",
        "- train_fasterrcnn_report.md",
        "",
    ]
    (out_dir / "train_fasterrcnn_report.md").write_text("\n".join(report_lines), encoding="utf-8")


if __name__ == "__main__":
    os.environ.setdefault("CUDA_DEVICE_ORDER", "PCI_BUS_ID")
    main()
