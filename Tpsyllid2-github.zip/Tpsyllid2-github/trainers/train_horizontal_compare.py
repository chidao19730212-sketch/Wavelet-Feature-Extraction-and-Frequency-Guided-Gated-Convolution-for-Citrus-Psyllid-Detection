import argparse
import json
import math
import sys
import threading
import time
from pathlib import Path
from typing import Any

import pandas as pd
import psutil
import torch
from thop import profile
from ultralytics import RTDETR

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def safe_float(v: Any) -> float | None:
    try:
        if v is None:
            return None
        x = float(v)
        if math.isnan(x):
            return None
        return x
    except Exception:
        return None


def round_or_none(v: float | None, ndigits: int = 6) -> float | None:
    return None if v is None else round(float(v), ndigits)


class ResourceMonitor:
    def __init__(self) -> None:
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.max_system_ram_percent = 0.0
        self.max_system_cpu_percent = 0.0
        self.max_process_rss_mb = 0.0
        self._proc = psutil.Process()

    def _run(self) -> None:
        self._proc.cpu_percent(interval=None)
        while not self._stop.is_set():
            try:
                self.max_system_ram_percent = max(self.max_system_ram_percent, psutil.virtual_memory().percent)
                self.max_system_cpu_percent = max(self.max_system_cpu_percent, psutil.cpu_percent(interval=0.5))
                rss_mb = self._proc.memory_info().rss / (1024 * 1024)
                self.max_process_rss_mb = max(self.max_process_rss_mb, rss_mb)
            except Exception:
                time.sleep(0.5)

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)


def benchmark_fps(core_model: torch.nn.Module, device: torch.device, batch: int, imgsz: int) -> float:
    core_model = core_model.to(device)
    core_model.eval()
    dummy = torch.zeros((batch, 3, imgsz, imgsz), device=device)
    warmup = 20
    runs = 50
    with torch.no_grad():
        for i in range(warmup + runs):
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            if i == warmup:
                t0 = time.time()
            _ = core_model(dummy)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
    elapsed = time.time() - t0
    return (batch * runs) / elapsed if elapsed > 0 else 0.0


def get_complexity(core_model: torch.nn.Module, device: torch.device, imgsz: int) -> tuple[float, float]:
    core_model = core_model.to(device)
    core_model.eval()
    dummy = torch.zeros((1, 3, imgsz, imgsz), device=device)
    macs, params = profile(core_model, inputs=(dummy,), verbose=False)
    flops_g = float(macs) * 2.0 / 1e9
    params_m = float(params) / 1e6
    return params_m, flops_g


def get_model_spec(model_key: str) -> dict[str, str]:
    specs = {
        "rtdetr_resnet50": {
            "display_name": "RT-DETR-ResNet50",
            "config_name": "rtdetr-resnet50.yaml",
            "category": "Transformer/DETR baseline",
            "notes": "Uses Ultralytics built-in RT-DETR ResNet50 YAML config because local pretrained .pt is unavailable.",
        }
    }
    if model_key not in specs:
        raise KeyError(f"Unsupported model key: {model_key}")
    return specs[model_key]


def resolve_save_dir(project: str, name: str) -> Path:
    project_path = Path(project)
    candidates = []
    if project_path.is_absolute():
        candidates.append(project_path / name)
    else:
        candidates.append((ROOT / project_path / name).resolve())
        candidates.append((ROOT / "runs" / "detect" / project_path / name).resolve())
    for p in candidates:
        if p.exists():
            return p
    return candidates[0]


def train_single_model(
    model_key: str,
    epochs: int,
    imgsz: int,
    batch: int,
    workers: int,
    device_arg: str,
    project: str,
    name: str,
) -> dict[str, Any]:
    spec = get_model_spec(model_key)
    display_name = spec["display_name"]
    config_name = spec["config_name"]

    project_abs = str((ROOT / project).resolve()) if not Path(project).is_absolute() else project
    save_dir = resolve_save_dir(project_abs, name)

    print("=" * 80)
    print(f"Horizontal Compare Training: {display_name}")
    print("=" * 80)
    print(f"Config: {config_name}")
    print(f"Save dir: {save_dir}")
    print(f"Params: epochs={epochs}, batch={batch}, workers={workers}, imgsz={imgsz}, device={device_arg}")
    print("Note: single model only; no loop training.")

    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()

    monitor = ResourceMonitor()
    monitor.start()
    train_ok = False
    train_error = None
    try:
        model = RTDETR(config_name)
        _ = model.train(
            data="configs/psyllid_slice640_balanced.yaml",
            epochs=epochs,
            imgsz=imgsz,
            batch=batch,
            device=device_arg,
            project=project_abs,
            name=name,
            patience=3,
            workers=workers,
            cache=False,
            plots=False,
            save=True,
            save_json=False,
            save_period=-1,
            deterministic=True,
            pretrained=False,
        )
        train_ok = True
    except Exception as e:  # noqa: BLE001
        train_error = f"{type(e).__name__}: {e}"
    finally:
        monitor.stop()

    save_dir = resolve_save_dir(project_abs, name)
    best_model_path = save_dir / "weights" / "best.pt"
    last_model_path = save_dir / "weights" / "last.pt"
    results_csv = save_dir / "results.csv"

    runtime_device = torch.device(f"cuda:{device_arg}" if torch.cuda.is_available() else "cpu")
    eval_summary: dict[str, Any] = {
        "Model": display_name,
        "Category": spec["category"],
        "Precision": None,
        "Recall": None,
        "F1": None,
        "mAP50": None,
        "mAP50-95": None,
        "Params(M)": None,
        "FLOPs(G)": None,
        "FPS": None,
        "Model Size(MB)": None,
        "Weight Path": str(best_model_path).replace("\\", "/"),
        "Notes": spec["notes"],
        "train_success": train_ok,
        "train_error": train_error,
        "best_exists": best_model_path.exists(),
        "last_exists": last_model_path.exists(),
        "results_csv_exists": results_csv.exists(),
        "gpu_peak_memory_mb": None,
        "system_cpu_max_percent": round(monitor.max_system_cpu_percent, 3),
        "system_ram_max_percent": round(monitor.max_system_ram_percent, 3),
        "process_rss_max_mb": round(monitor.max_process_rss_mb, 3),
        "cpu_ram_status": "unknown",
    }

    if torch.cuda.is_available():
        eval_summary["gpu_peak_memory_mb"] = round(torch.cuda.max_memory_reserved(runtime_device) / (1024 * 1024), 3)

    if eval_summary["system_ram_max_percent"] is not None:
        eval_summary["cpu_ram_status"] = (
            "normal" if eval_summary["system_ram_max_percent"] < 85.0 else "warning_high_ram"
        )

    if best_model_path.exists():
        best_model = RTDETR(str(best_model_path))
        metrics = best_model.val(
            data="configs/psyllid_slice640_balanced.yaml",
            imgsz=imgsz,
            batch=batch,
            device=device_arg,
            plots=False,
            save_json=False,
            verbose=False,
        )
        box = metrics.box
        precision = safe_float(box.mp)
        recall = safe_float(box.mr)
        f1 = None
        if precision is not None and recall is not None and (precision + recall) > 0:
            f1 = 2.0 * precision * recall / (precision + recall)
        params_m, flops_g = get_complexity(best_model.model, runtime_device, imgsz)
        fps = benchmark_fps(best_model.model, runtime_device, batch=batch, imgsz=imgsz)
        model_size_mb = best_model_path.stat().st_size / (1024 * 1024)

        eval_summary.update(
            {
                "Precision": round_or_none(precision),
                "Recall": round_or_none(recall),
                "F1": round_or_none(f1),
                "mAP50": round_or_none(safe_float(box.map50)),
                "mAP50-95": round_or_none(safe_float(box.map)),
                "Params(M)": round_or_none(params_m),
                "FLOPs(G)": round_or_none(flops_g),
                "FPS": round_or_none(fps),
                "Model Size(MB)": round_or_none(model_size_mb),
            }
        )

        stats_path = save_dir / "safe_stats.json"
        stats_payload = {
            "params_m": eval_summary["Params(M)"],
            "flops_g": eval_summary["FLOPs(G)"],
            "fps": eval_summary["FPS"],
            "model_size_mb": eval_summary["Model Size(MB)"],
            "precision": eval_summary["Precision"],
            "recall": eval_summary["Recall"],
            "f1": eval_summary["F1"],
            "map50": eval_summary["mAP50"],
            "map50_95": eval_summary["mAP50-95"],
            "gpu_peak_memory_mb": eval_summary["gpu_peak_memory_mb"],
            "system_cpu_max_percent": eval_summary["system_cpu_max_percent"],
            "system_ram_max_percent": eval_summary["system_ram_max_percent"],
            "process_rss_max_mb": eval_summary["process_rss_max_mb"],
            "cpu_ram_status": eval_summary["cpu_ram_status"],
        }
        stats_path.write_text(json.dumps(stats_payload, indent=2, ensure_ascii=False), encoding="utf-8")

    summary_path = save_dir / "dryrun_summary.json"
    summary_path.write_text(json.dumps(eval_summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return eval_summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Train one horizontal comparison model at a time.")
    parser.add_argument("--model", required=True, choices=["rtdetr_resnet50"])
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=2)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--project", type=str, default="runs_lightweight/horizontal_compare")
    parser.add_argument("--name", type=str, default=None)
    args = parser.parse_args()

    default_name = {
        "rtdetr_resnet50": "rtdetr_resnet50_dryrun" if args.epochs <= 3 else "rtdetr_resnet50",
    }
    name = args.name if args.name else default_name[args.model]

    summary = train_single_model(
        model_key=args.model,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        workers=args.workers,
        device_arg=args.device,
        project=args.project,
        name=name,
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
