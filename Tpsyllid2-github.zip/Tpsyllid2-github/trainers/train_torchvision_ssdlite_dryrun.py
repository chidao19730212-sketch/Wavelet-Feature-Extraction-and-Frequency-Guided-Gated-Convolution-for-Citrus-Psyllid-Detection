from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

import torch


def _env_info() -> dict:
    info = {"python": sys.version.split()[0]}
    try:
        import torchvision

        info["torchvision"] = torchvision.__version__
    except Exception as e:
        info["torchvision_error"] = repr(e)
    try:
        info["torch"] = torch.__version__
        info["cuda_available"] = bool(torch.cuda.is_available())
        info["cuda_runtime"] = getattr(torch.version, "cuda", None)
        info["cuda_device_count"] = int(torch.cuda.device_count())
        info["cuda_name"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    except Exception as e:
        info["torch_error"] = repr(e)
    try:
        import sahi

        info["sahi_importable"] = True
    except Exception:
        info["sahi_importable"] = False
    return info


def _mkdir_or_fail(p: Path) -> None:
    if p.exists():
        raise SystemExit(f"OUTPUT_DIR_EXISTS\t{p}")
    p.mkdir(parents=True, exist_ok=False)


def _to_device_targets(targets: list[dict], device: torch.device) -> list[dict]:
    moved: list[dict] = []
    for t in targets:
        moved.append(
            {
                "boxes": t["boxes"].to(device),
                "labels": t["labels"].to(device),
                "image_id": t["image_id"].to(device),
                "area": t["area"].to(device),
                "iscrowd": t["iscrowd"].to(device),
            }
        )
    return moved


def _build_model(num_classes: int, prefer_imagenet_backbone: bool) -> tuple[torch.nn.Module, dict]:
    meta: dict = {"model_name": "ssdlite320_mobilenet_v3_large"}
    from torchvision.models.mobilenetv3 import MobileNet_V3_Large_Weights
    from torchvision.models.detection import ssdlite320_mobilenet_v3_large

    if prefer_imagenet_backbone:
        try:
            m = ssdlite320_mobilenet_v3_large(
                weights=None,
                weights_backbone=MobileNet_V3_Large_Weights.IMAGENET1K_V1,
                num_classes=int(num_classes),
            )
            meta["weights"] = None
            meta["weights_backbone"] = "MobileNet_V3_Large_Weights.IMAGENET1K_V1"
            meta["num_classes"] = int(num_classes)
            meta["model_build_path"] = "weights=None + ImageNet backbone weights"
            return m, meta
        except Exception as e:
            meta["model_build_warning"] = f"preferred API path failed: {type(e).__name__}: {e}"

    m = ssdlite320_mobilenet_v3_large(weights=None, weights_backbone=None, num_classes=int(num_classes))
    meta["weights"] = None
    meta["weights_backbone"] = None
    meta["num_classes"] = int(num_classes)
    meta["model_build_path"] = "weights=None + weights_backbone=None (fallback)"
    return m, meta


def _run_epoch(
    model: torch.nn.Module,
    loader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
) -> dict:
    model.train()
    total_loss = 0.0
    total_batches = 0
    for images, targets in loader:
        images = [img.to(device) for img in images]
        targets = _to_device_targets(targets, device)
        loss_dict = model(images, targets)
        loss = sum(v for v in loss_dict.values())
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        total_loss += float(loss.detach().cpu().item())
        total_batches += 1
    avg_loss = total_loss / max(1, total_batches)
    return {"train_loss": avg_loss, "train_batches": int(total_batches)}


@torch.no_grad()
def _val_sanity(model: torch.nn.Module, loader, device: torch.device, max_batches: int = 3) -> dict:
    model.eval()
    images_seen = 0
    dets_count = 0
    top1_scores: list[float] = []
    for b_idx, (images, _) in enumerate(loader):
        if b_idx >= max_batches:
            break
        images = [img.to(device) for img in images]
        outputs = model(images)
        for out in outputs:
            images_seen += 1
            scores = out.get("scores", None)
            if scores is None:
                continue
            scores_cpu = scores.detach().cpu()
            dets_count += int(scores_cpu.numel())
            if scores_cpu.numel() > 0:
                top1_scores.append(float(scores_cpu.max().item()))
    avg_dets = float(dets_count / max(1, images_seen))
    avg_top1 = float(sum(top1_scores) / max(1, len(top1_scores))) if top1_scores else 0.0
    return {"val_images_seen": int(images_seen), "avg_detections_per_image": avg_dets, "avg_top1_score": avg_top1}


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    keys: list[str] = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-2)
    parser.add_argument("--train_limit", type=int, default=300)
    parser.add_argument("--val_limit", type=int, default=100)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument(
        "--train_images",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\train\images",
    )
    parser.add_argument(
        "--val_images",
        type=str,
        default=r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_slice_640_balanced\val\images",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=r"runs_lightweight/lightweight_baselines/ssdlite_mobilenetv3_dryrun",
    )
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    _mkdir_or_fail(out_dir)

    env = _env_info()
    device = torch.device(args.device if torch.cuda.is_available() and str(args.device).startswith("cuda") else "cpu")

    root = Path(__file__).resolve().parent.parent
    datasets_dir = root / "datasets"
    sys.path.insert(0, str(datasets_dir))
    from torchvision_detection_dataset import TorchvisionYoloDetectionDataset, detection_collate_fn

    train_ds = TorchvisionYoloDetectionDataset(Path(args.train_images), limit=int(args.train_limit))
    val_ds = TorchvisionYoloDetectionDataset(Path(args.val_images), limit=int(args.val_limit))

    def make_loaders(batch_size: int):
        train_loader = torch.utils.data.DataLoader(
            train_ds,
            batch_size=int(batch_size),
            shuffle=True,
            num_workers=int(args.workers),
            collate_fn=detection_collate_fn,
        )
        val_loader = torch.utils.data.DataLoader(
            val_ds,
            batch_size=int(batch_size),
            shuffle=False,
            num_workers=int(args.workers),
            collate_fn=detection_collate_fn,
        )
        return train_loader, val_loader

    num_classes = 2
    model, model_meta = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
    model.to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
    optim_meta = {"optimizer": "AdamW", "lr": float(args.lr), "weight_decay": float(args.weight_decay)}

    used_batch = int(args.batch_size)
    try:
        train_loader, val_loader = make_loaders(used_batch)
        _ = next(iter(train_loader))
    except Exception as e:
        raise SystemExit(f"DATALOADER_INIT_FAILED\t{type(e).__name__}\t{e}")

    logs: list[dict] = []
    best_loss = None
    best_epoch = None
    t0 = time.perf_counter()
    completed_epochs = 0

    def run_with_current_batch_size() -> dict:
        nonlocal best_loss, best_epoch, completed_epochs
        for epoch in range(int(args.epochs)):
            ep0 = time.perf_counter()
            tr = _run_epoch(model, train_loader, optimizer, device)
            completed_epochs += 1

            train_loss = float(tr["train_loss"])
            if best_loss is None or train_loss < float(best_loss):
                best_loss = train_loss
                best_epoch = int(epoch + 1)
                torch.save(model.state_dict(), out_dir / "best.pth")

            torch.save(model.state_dict(), out_dir / "last.pth")
            val_sanity = _val_sanity(model, val_loader, device, max_batches=3)
            ep1 = time.perf_counter()
            row = {
                "epoch": int(epoch + 1),
                "train_loss": train_loss,
                "train_batches": int(tr["train_batches"]),
                "val_images_seen": int(val_sanity["val_images_seen"]),
                "avg_detections_per_image": float(val_sanity["avg_detections_per_image"]),
                "avg_top1_score": float(val_sanity["avg_top1_score"]),
                "epoch_time_s": round(float(ep1 - ep0), 4),
                "batch_size": int(used_batch),
                "device": str(device),
            }
            logs.append(row)
        return {"status": "ok"}

    try:
        train_loader, val_loader = make_loaders(used_batch)
        run_status = run_with_current_batch_size()
    except RuntimeError as e:
        msg = str(e).lower()
        if "out of memory" in msg and used_batch > 2 and torch.cuda.is_available():
            torch.cuda.empty_cache()
            used_batch = 2
            train_loader, val_loader = make_loaders(used_batch)
            logs = []
            best_loss = None
            best_epoch = None
            completed_epochs = 0
            model, model_meta = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
            model.to(device)
            optimizer = torch.optim.AdamW(model.parameters(), lr=float(args.lr), weight_decay=float(args.weight_decay))
            run_status = run_with_current_batch_size()
            run_status["note"] = "OOM with batch_size=4; restarted with batch_size=2"
        else:
            raise

    t1 = time.perf_counter()

    _write_csv(out_dir / "training_log.csv", logs)

    ckpt_load_ok = {"best": False, "last": False}
    reload_sanity = {}
    for name in ["best", "last"]:
        p = out_dir / f"{name}.pth"
        if not p.exists():
            continue
        try:
            m2, _ = _build_model(num_classes=num_classes, prefer_imagenet_backbone=True)
            sd = torch.load(str(p), map_location="cpu")
            m2.load_state_dict(sd, strict=True)
            m2.eval()
            ckpt_load_ok[name] = True
            images, _ = next(iter(make_loaders(batch_size=1)[1]))
            out = m2([images[0]])
            if isinstance(out, list) and out and isinstance(out[0], dict):
                reload_sanity[name] = {"output_keys": sorted(list(out[0].keys()))}
        except Exception as e:
            ckpt_load_ok[name] = False
            reload_sanity[name] = {"error": f"{type(e).__name__}: {e}"}

    summary = {
        "exp_name": out_dir.name,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "env": env,
        "data": {
            "train_images_dir": str(Path(args.train_images)),
            "val_images_dir": str(Path(args.val_images)),
            "train_subset": int(len(train_ds)),
            "val_subset": int(len(val_ds)),
            "supports_empty_labels": True,
        },
        "model": model_meta,
        "train": {
            "epochs_planned": int(args.epochs),
            "epochs_completed": int(completed_epochs),
            "batch_size": int(used_batch),
            "workers": int(args.workers),
            "device": str(device),
            **optim_meta,
            "train_time_s": round(float(t1 - t0), 4),
            "best_epoch_by_train_loss": best_epoch,
            "best_train_loss": best_loss,
            "last_epoch_train_loss": float(logs[-1]["train_loss"]) if logs else None,
        },
        "val_sanity_last_epoch": {
            "val_images_seen": int(logs[-1]["val_images_seen"]) if logs else 0,
            "avg_detections_per_image": float(logs[-1]["avg_detections_per_image"]) if logs else 0.0,
            "avg_top1_score": float(logs[-1]["avg_top1_score"]) if logs else 0.0,
        },
        "checkpoints": {
            "best_weight_path": str(out_dir / "best.pth"),
            "last_weight_path": str(out_dir / "last.pth"),
            "best_load_ok": bool(ckpt_load_ok["best"]),
            "last_load_ok": bool(ckpt_load_ok["last"]),
            "reload_sanity": reload_sanity,
        },
        "status": {"run_status": run_status},
        "constraints": {
            "no_sahi_tta_wbf_run": True,
            "sahi_missing_blocks_original_image_eval": not bool(env.get("sahi_importable", False)),
        },
    }
    (out_dir / "exp_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    report_lines = [
        "# SSDLite320-MobileNetV3-Large Dry-run Report",
        "",
        "## Environment",
        "",
        f"- Python: {env.get('python')}",
        f"- torch: {env.get('torch')}",
        f"- torchvision: {env.get('torchvision')}",
        f"- CUDA available: {env.get('cuda_available')}",
        f"- CUDA runtime: {env.get('cuda_runtime')}",
        f"- GPU: {env.get('cuda_name')}",
        "",
        "## Data",
        "",
        f"- train subset: {len(train_ds)}",
        f"- val subset: {len(val_ds)}",
        "- empty labels supported: True",
        "",
        "## Model / Training",
        "",
        "- model: torchvision.models.detection.ssdlite320_mobilenet_v3_large",
        "- num_classes: 2 (background + psyllid)",
        f"- epochs: {int(args.epochs)} (completed: {int(completed_epochs)})",
        f"- batch_size: {int(used_batch)}",
        f"- workers: {int(args.workers)}",
        f"- optimizer: {optim_meta.get('optimizer')} (lr={optim_meta.get('lr')}, wd={optim_meta.get('weight_decay')})",
        f"- final train loss: {float(logs[-1]['train_loss']) if logs else None}",
        "",
        "## Val sanity (not evaluation)",
        "",
        f"- val_images_seen (sampled): {int(logs[-1]['val_images_seen']) if logs else 0}",
        f"- avg_detections_per_image: {float(logs[-1]['avg_detections_per_image']) if logs else 0.0}",
        f"- avg_top1_score: {float(logs[-1]['avg_top1_score']) if logs else 0.0}",
        "",
        "## Checkpoints",
        "",
        f"- best.pth saved: {bool((out_dir / 'best.pth').exists())}, reload_ok: {bool(ckpt_load_ok['best'])}",
        f"- last.pth saved: {bool((out_dir / 'last.pth').exists())}, reload_ok: {bool(ckpt_load_ok['last'])}",
        "",
        "## Next-step recommendation",
        "",
        "- Ready to enter 100-epoch formal training: "
        + ("YES (pipeline OK; still need proper evaluation later)" if int(completed_epochs) == int(args.epochs) and all(ckpt_load_ok.values()) else "NO (fix blockers first)"),
        "",
        "## Current blockers",
        "",
        f"- SAHI importable (this run): {bool(env.get('sahi_importable', False))}",
        "- Note: earlier feasibility check reported SAHI import failure; if you switch environments, re-check SAHI availability before running original-image SAHI+TTA+WBF (still forbidden in this dry-run step).",
        "",
        "## Outputs",
        "",
        "- exp_summary.json",
        "- training_log.csv",
        "- dryrun_report.md",
        "- best.pth",
        "- last.pth",
        "",
    ]
    (out_dir / "dryrun_report.md").write_text("\n".join(report_lines), encoding="utf-8")


if __name__ == "__main__":
    os.environ.setdefault("CUDA_DEVICE_ORDER", "PCI_BUS_ID")
    main()
