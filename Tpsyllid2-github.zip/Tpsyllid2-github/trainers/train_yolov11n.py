import argparse
import json
import time
from pathlib import Path

import pandas as pd
import torch
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser(description="Train lightweight YOLOv11n student model")
    parser.add_argument(
        "--data",
        type=str,
        default=r"c:\Users\admim\Desktop\Tpsyllid2\configs\psyllid_slice640_balanced.yaml",
        help="Path to dataset YAML"
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=100,
        help="Number of training epochs"
    )
    parser.add_argument(
        "--imgsz",
        type=int,
        default=640,
        help="Input image size"
    )
    parser.add_argument(
        "--batch",
        type=int,
        default=16,
        help="Batch size"
    )
    parser.add_argument(
        "--name",
        type=str,
        default="yolo11n_baseline",
        help="Experiment name"
    )
    parser.add_argument(
        "--project",
        type=str,
        default=r"c:\Users\admim\Desktop\Tpsyllid2\runs_lightweight",
        help="Project directory"
    )
    parser.add_argument(
        "--pretrained",
        action="store_true",
        default=True,
        help="Use COCO-pretrained weights"
    )
    parser.add_argument(
        "--device",
        type=str,
        default="0",
        help="Device (0 for GPU, cpu for CPU)"
    )
    parser.add_argument(
        "--patience",
        type=int,
        default=100,
        help="Early stopping patience (epochs)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Dry run mode: epochs=3, name=yolo11n_dryrun"
    )
    args = parser.parse_args()

    # Apply dry-run settings
    if args.dry_run:
        args.epochs = 3
        args.name = "yolo11n_dryrun"
        args.patience = 3
        print("⚠️  Dry run mode enabled: epochs=3, name=yolo11n_dryrun")

    # Print configuration
    print("=" * 80)
    print("Training Configuration:")
    print(f"  Model: YOLOv11n")
    print(f"  Data: {args.data}")
    print(f"  Epochs: {args.epochs}")
    print(f"  Imgsz: {args.imgsz}")
    print(f"  Batch: {args.batch}")
    print(f"  Patience: {args.patience}")
    print(f"  Device: {args.device}")
    print(f"  Pretrained: {args.pretrained}")
    print(f"  Project: {args.project}")
    print(f"  Name: {args.name}")
    print(f"  Dry Run: {args.dry_run}")
    print("=" * 80)

    # Load model
    print("\nLoading model...")
    if args.pretrained:
        model = YOLO("yolo11n.pt")
    else:
        model = YOLO("yolo11n.yaml")

    # Train
    start_time = time.time()
    print("\nStarting training...")
    results = model.train(
        data=args.data,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        name=args.name,
        project=args.project,
        device=args.device,
        patience=args.patience,
        exist_ok=False,
        verbose=True
    )
    train_time = time.time() - start_time

    # Extract best metrics
    results_csv = Path(args.project) / args.name / "results.csv"
    if results_csv.exists():
        df = pd.read_csv(results_csv)
        best_idx = df["metrics/mAP50(B)"].astype(float).idxmax()
        best_row = df.loc[best_idx]

        exp_summary = {
            "model_name": "YOLOv11n",
            "dataset_version": "slice640_balanced",
            "train_status": "completed",
            "epochs": int(len(df)),
            "train_time_hours": train_time / 3600.0,
            "best_epoch_by_mAP50": int(best_row["epoch"]),
            "best_precision_by_mAP50": float(best_row["metrics/precision(B)"]),
            "best_recall_by_mAP50": float(best_row["metrics/recall(B)"]),
            "best_mAP50": float(best_row["metrics/mAP50(B)"]),
            "corresponding_mAP50_95": float(best_row["metrics/mAP50-95(B)"]),
            "last_epoch_precision": float(df.iloc[-1]["metrics/precision(B)"]),
            "last_epoch_recall": float(df.iloc[-1]["metrics/recall(B)"]),
            "last_epoch_mAP50": float(df.iloc[-1]["metrics/mAP50(B)"]),
            "last_epoch_mAP50_95": float(df.iloc[-1]["metrics/mAP50-95(B)"]),
            "pretrained": "COCO-pretrained" if args.pretrained else "from scratch",
        }

        # Save summary
        summary_path = Path(args.project) / args.name / "exp_summary.json"
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(exp_summary, f, indent=4, ensure_ascii=False)
        print(f"\nExperiment summary saved to: {summary_path}")

    print("\n" + "=" * 80)
    print("Training completed!")
    print(f"Total time: {train_time:.2f} seconds ({train_time / 3600:.2f} hours)")
    print("=" * 80)


if __name__ == "__main__":
    main()
