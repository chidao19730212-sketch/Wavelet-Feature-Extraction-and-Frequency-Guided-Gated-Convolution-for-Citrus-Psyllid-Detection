"""
LWS-Det-B0 Training Script (Dry-run)
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Register LWS-Det modules FIRST!
from models import register_lwsdet_modules
register_lwsdet_modules()

import argparse
import time
import json
import pandas as pd
from ultralytics import YOLO

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dry-run', action='store_true', default=False, 
                        help='Run dry-run (3 epochs)')
    parser.add_argument('--batch', type=int, default=16)
    parser.add_argument('--device', type=str, default='0')
    args = parser.parse_args()
    
    print("=" * 80)
    print("LWS-Det-B0 Training")
    print("=" * 80)
    
    # Load config
    yaml_path = Path(__file__).parent.parent / "configs" / "lwsdet_b0.yaml"
    
    # Load model
    model = YOLO(str(yaml_path), task='detect')
    
    # Data config (same as Teacher/YOLOv11n)
    data_config = Path(__file__).parent.parent / "configs" / "psyllid_slice640_balanced.yaml"
    
    # Training params
    if args.dry_run:
        epochs = 3
        name = "lwsdet_b0_dryrun"
    else:
        epochs = 100
        name = "lwsdet_b0_baseline"
    
    print(f"\nTraining config:")
    print(f"  Epochs: {epochs}")
    print(f"  Batch: {args.batch}")
    print(f"  Imgsz: 640")
    print(f"  Device: {args.device}")
    print(f"  Name: {name}")
    print(f"  Project: runs_lightweight")
    print()
    
    # Train
    results = model.train(
        data=str(data_config),
        epochs=epochs,
        imgsz=640,
        batch=args.batch,
        device=args.device,
        project="runs_lightweight",
        name=name,
        patience=100 if not args.dry_run else 3,
        save=True,
        plots=True,
        pretrained=False
    )
    
    print("\n" + "=" * 80)
    print("Training complete!")
    print("=" * 80)
    
    # Quick check on results
    last_run_dir = Path("runs_lightweight") / name
    
    if last_run_dir.exists():
        print(f"\nResults saved to: {last_run_dir}")
        
        weights_dir = last_run_dir / "weights"
        if weights_dir.exists():
            best_pt = weights_dir / "best.pt"
            last_pt = weights_dir / "last.pt"
            print(f"  - {best_pt.name}: {'✅' if best_pt.exists() else '❌'}")
            print(f"  - {last_pt.name}: {'✅' if last_pt.exists() else '❌'}")
        
        results_csv = last_run_dir / "results.csv"
        print(f"  - results.csv: {'✅' if results_csv.exists() else '❌'}")
    
    print("\nDone!")

if __name__ == "__main__":
    main()
