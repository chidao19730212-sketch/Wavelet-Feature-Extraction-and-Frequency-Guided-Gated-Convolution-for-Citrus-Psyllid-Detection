
"""
Ablation study training script for LWS-Det-B0
Trains: noWavelet, noSSM, basic versions
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models import register_lwsdet_modules
register_lwsdet_modules()

from ultralytics import YOLO
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, required=True,
                        choices=['no_wavelet', 'no_ssm', 'basic'],
                        help='Which ablation model to train')
    args = parser.parse_args()

    config_map = {
        'no_wavelet': 'configs/lwsdet_b0_no_wavelet.yaml',
        'no_ssm': 'configs/lwsdet_b0_no_ssm.yaml',
        'basic': 'configs/lwsdet_b0_basic.yaml'
    }
    name_map = {
        'no_wavelet': 'lwsdet_b0_no_wavelet',
        'no_ssm': 'lwsdet_b0_no_ssm',
        'basic': 'lwsdet_b0_basic'
    }

    yaml_path = config_map[args.model]
    name = name_map[args.model]

    print(f"=" * 80)
    print(f"Training ablation: {args.model}")
    print(f"=" * 80)
    print(f"Config: {yaml_path}")
    print(f"Save to: runs_lightweight/{name}")
    print()

    model = YOLO(str(yaml_path))
    data_config = "configs/psyllid_slice640_balanced.yaml"

    results = model.train(
        data=str(data_config),
        epochs=100,
        imgsz=640,
        batch=16,
        device=0,
        project="runs_lightweight",
        name=name,
        patience=100,
        save=True,
        plots=True,
        pretrained=False
    )

    print(f"\nTraining completed for {args.model}!")


if __name__ == "__main__":
    main()
