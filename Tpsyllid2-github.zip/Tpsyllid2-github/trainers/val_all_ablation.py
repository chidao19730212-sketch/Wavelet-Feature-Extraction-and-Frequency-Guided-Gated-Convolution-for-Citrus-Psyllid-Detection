
"""
Batch validation script for all ablation versions
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models import register_lwsdet_modules
register_lwsdet_modules()

from ultralytics import YOLO
import thop
import torch
import time
import json
import pandas as pd


def validate_model(model_name, weights_path):
    print(f"\nValidating: {model_name}")
    print("-" * 80)
    
    if not weights_path.exists():
        print(f"  ❌ Weights not found at {weights_path}")
        return None
    
    try:
        model = YOLO(str(weights_path))
    except Exception as e:
        print(f"  ❌ Failed to load model: {e}")
        return None
    
    # Validate on dataset
    try:
        data_config = "configs/psyllid_slice640_balanced.yaml"
        metrics = model.val(
            data=str(data_config),
            imgsz=640,
            device=0,
            verbose=False
        )
        
        p, r, f1 = -1, -1, -1
        try:
            p = float(metrics.mp)
            r = float(metrics.mr)
            f1 = 2 * (p * r) / (p + r) if (p + r) > 0 else -1
        except:
            pass
        
        map50 = float(metrics.map50) if hasattr(metrics, 'map50') else -1
        map = float(metrics.map) if hasattr(metrics, 'map') else -1
        
    except Exception as e:
        print(f"  ❌ Validation failed: {e}")
        p, r, f1, map50, map = -1, -1, -1, -1, -1
    
    # Calculate model info
    dummy_input = torch.randn(1, 3, 640, 640).to('cuda' if torch.cuda.is_available() else 'cpu')
    
    params = -1
    flops = -1
    try:
        flops, params = thop.profile(model.model, inputs=(dummy_input,), verbose=False)
    except:
        pass
    
    model_size_mb = -1
    try:
        model_size_mb = weights_path.stat().st_size / (1024 * 1024)
    except:
        pass
    
    fps = -1
    try:
        n_runs, warmup = 50, 20
        model.to('cuda' if torch.cuda.is_available() else 'cpu')
        with torch.no_grad():
            for i in range(n_runs + warmup):
                if i == warmup:
                    t0 = time.time()
                model(dummy_input, verbose=False)
        fps = n_runs / (time.time() - t0)
    except:
        pass
    
    result = {
        "model": model_name,
        "precision": p,
        "recall": r,
        "f1": f1,
        "map50": map50,
        "map50_95": map,
        "params_m": params / 1e6 if params > 0 else -1,
        "flops_g": flops / 1e9 if flops > 0 else -1,
        "model_size_mb": model_size_mb,
        "fps": fps
    }
    
    print(f"  Precision: {p:.4f}")
    print(f"  Recall:    {r:.4f}")
    print(f"  F1:        {f1:.4f}")
    print(f"  mAP50:     {map50:.4f}")
    print(f"  mAP50-95:  {map:.4f}")
    print(f"  Params:    {result['params_m']:.2f} M")
    print(f"  FLOPs:     {result['flops_g']:.2f} G")
    print(f"  Size:      {model_size_mb:.2f} MB")
    print(f"  FPS:       {fps:.2f}")
    
    return result


def main():
    print("=" * 80)
    print("Batch Validation - Ablation Studies")
    print("=" * 80)
    
    # List all ablation models with their weight paths
    ablation_list = [
        ("lwsdet_b0_basic", "runs_lightweight/lwsdet_b0_basic_dryrun/weights/best.pt"),
        ("lwsdet_b0_no_wavelet", "runs_lightweight/lwsdet_b0_no_wavelet_dryrun/weights/best.pt"),
        ("lwsdet_b0_no_ssm", "runs_lightweight/lwsdet_b0_no_ssm_dryrun/weights/best.pt")
    ]
    
    all_results = []
    
    for model_name, weights_str in ablation_list:
        weights_path = Path(weights_str)
        result = validate_model(model_name, weights_path)
        if result is not None:
            all_results.append(result)
    
    # Save summary
    if all_results:
        save_dir = Path("runs_lightweight")
        df = pd.DataFrame(all_results)
        
        summary_csv = save_dir / "ablation_dryrun_summary.csv"
        df.to_csv(summary_csv, index=False)
        
        print("\n" + "=" * 80)
        print(f"Summary saved to: {summary_csv}")
        print("=" * 80)
        print(df.to_string(index=False))


if __name__ == "__main__":
    main()
