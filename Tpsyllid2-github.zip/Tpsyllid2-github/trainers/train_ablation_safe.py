
"""
SAFE Ablation study training script
Only trains ONE model at a time, with minimal resource usage
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Register modules
from models import register_lwsdet_modules
register_lwsdet_modules()

import argparse
import time
import json
import torch
import thop
from ultralytics import YOLO


def compute_model_stats(model_path, imgsz=640):
    """
    Compute FLOPs, Params, FPS once after training completes
    """
    print("\n" + "=" * 80)
    print("Computing model stats (FLOPs/Params/FPS)...")
    print("=" * 80)
    
    try:
        # Load best model
        model = YOLO(model_path)
        model.to('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Compute FLOPs and Params
        dummy_input = torch.randn(1, 3, imgsz, imgsz).to(model.device)
        
        # Compute FLOPs and params using thop
        flops, params = thop.profile(model.model, inputs=(dummy_input,), verbose=False)
        
        # Compute FPS (warmup 10, run 50)
        model.eval()
        with torch.no_grad():
            # Warmup
            for _ in range(10):
                _ = model(dummy_input, verbose=False)
                
            # Measure FPS
            t0 = time.time()
            for _ in range(50):
                _ = model(dummy_input, verbose=False)
            fps = 50 / (time.time() - t0)
        
        # Get model size
        model_size_mb = Path(model_path).stat().st_size / (1024 * 1024)
        
        # Print results
        print(f"Params: {params/1e6:.2f} M")
        print(f"FLOPs:  {flops/1e9:.2f} G")
        print(f"FPS:    {fps:.2f}")
        print(f"Model size: {model_size_mb:.2f} MB")
        
        return {
            'params_m': float(params/1e6),
            'flops_g': float(flops/1e9),
            'fps': float(fps),
            'model_size_mb': float(model_size_mb)
        }
        
    except Exception as e:
        print(f"Failed to compute stats: {e}")
        return None


def main():
    parser = argparse.ArgumentParser(description='SAFE: Train ONE ablation model at a time')
    parser.add_argument('--variant', type=str, required=True,
                        choices=['basic', 'no_wavelet', 'no_ssm', 'fg_lssm_p5'],
                        help='Which variant to train: basic | no_wavelet | no_ssm | fg_lssm_p5')
    
    # Optional overrides with safe defaults
    parser.add_argument('--epochs', type=int, default=3)
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--batch', type=int, default=4)
    parser.add_argument('--workers', type=int, default=0)
    parser.add_argument('--device', type=str, default='0')
    parser.add_argument('--project', type=str, default='runs_lightweight')
    parser.add_argument('--name', type=str, default=None,
                        help='Custom save directory name (defaults to variant_dryrun_safe)')
    
    args = parser.parse_args()
    
    # Configuration mappings
    config_map = {
        'basic': 'configs/lwsdet_b0_basic.yaml',
        'no_wavelet': 'configs/lwsdet_b0_no_wavelet.yaml',
        'no_ssm': 'configs/lwsdet_b0_no_ssm.yaml',
        'fg_lssm_p5': 'configs/lwsdet_b1_fg_lssm_p5.yaml'
    }
    
    name_map = {
        'basic': 'lwsdet_b0_basic_dryrun_safe',
        'no_wavelet': 'lwsdet_b0_no_wavelet_dryrun_safe',
        'no_ssm': 'lwsdet_b0_no_ssm_dryrun_safe',
        'fg_lssm_p5': 'lwsdet_b1_fg_lssm_p5_dryrun'
    }
    
    yaml_path = config_map[args.variant]
    name = args.name if args.name is not None else name_map[args.variant]
    
    print(f"=" * 80)
    print(f"SAFE Training: {args.variant} (SINGLE MODEL ONLY)")
    print(f"=" * 80)
    print(f"Config: {yaml_path}")
    print(f"Save dir: {args.project}/{name}")
    print(f"Params: epochs={args.epochs}, batch={args.batch}, workers={args.workers}, imgsz={args.imgsz}")
    print()
    
    # Initialize model
    model = YOLO(str(yaml_path))
    data_config = "configs/psyllid_slice640_balanced.yaml"
    
    # Train with SAFE settings
    results = model.train(
        data=str(data_config),
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        device=args.device,
        project=args.project,
        name=name,
        patience=args.epochs,
        workers=args.workers,
        cache=False,          # Disable cache to save memory
        plots=False,          # Disable plots to save disk/memory
        save=True,
        save_json=False,      # Disable extra JSON saving
        save_period=-1,       # Only save last/best
        pretrained=False,
        deterministic=True
    )
    
    print("\n" + "=" * 80)
    print(f"Training complete for: {args.variant}")
    print("=" * 80)
    
    # Compute stats ONCE after training completes
    best_model_path = Path(args.project) / name / "weights" / "best.pt"
    if best_model_path.exists():
        stats = compute_model_stats(str(best_model_path), imgsz=args.imgsz)
        
        # Save stats to JSON
        if stats:
            stats_file = Path(args.project) / name / "safe_stats.json"
            with open(stats_file, 'w') as f:
                json.dump(stats, f, indent=2)
            print(f"\nStats saved to: {stats_file}")
    else:
        print(f"\nWarning: Best model not found at {best_model_path}")
    
    print("\n" + "=" * 80)
    print(f"SAFE training DONE for: {args.variant}")
    print(f"=" * 80)


if __name__ == "__main__":
    main()
