import argparse
import json
import time
from pathlib import Path

import pandas as pd
import torch
from ultralytics import YOLO


def calculate_model_info(model, weights_path, imgsz=640):
    """Calculate model parameters, FLOPs, and size"""
    # Calculate parameters
    params = sum(p.numel() for p in model.model.parameters())
    params_m = params / 1e6

    # YOLOv11n known FLOPs from ultralytics
    flops_g = 6.4

    # Get model size
    model_path = Path(weights_path)
    if model_path.exists():
        model_size_mb = model_path.stat().st_size / (1024 * 1024)
    else:
        model_size_mb = 0.0

    return {
        "params_m": round(params_m, 4),
        "flops_g": round(flops_g, 4),
        "model_size_mb": round(model_size_mb, 4),
        "input_size": [3, imgsz, imgsz]
    }


def measure_fps(model, imgsz=640, device='0', num_warmup=10, num_test=30):
    """Measure inference FPS"""
    device_str = device if device != '0' else 'cuda:0'
    dummy_input = torch.rand(1, 3, imgsz, imgsz).to(device_str)  # Use 0-1 range

    # Warmup
    for _ in range(num_warmup):
        _ = model.predict(dummy_input, verbose=False)

    # Measure
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    start_time = time.time()
    for _ in range(num_test):
        _ = model.predict(dummy_input, verbose=False)
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    total_time = time.time() - start_time

    fps = num_test / total_time
    return round(fps, 4)


def main():
    parser = argparse.ArgumentParser(description="Validate YOLOv11n model and output metrics")
    parser.add_argument(
        "--weights",
        type=str,
        default=r"c:\Users\admim\Desktop\Tpsyllid2\runs_lightweight\yolo11n_baseline\weights\best.pt",
        help="Path to model weights"
    )
    parser.add_argument(
        "--data",
        type=str,
        default=r"c:\Users\admim\Desktop\Tpsyllid2\configs\psyllid_slice640_balanced.yaml",
        help="Path to dataset YAML"
    )
    parser.add_argument(
        "--imgsz",
        type=int,
        default=640,
        help="Input image size"
    )
    parser.add_argument(
        "--device",
        type=str,
        default="0",
        help="Device (0 for GPU, cpu for CPU)"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Output directory for results (default: same as weights dir)"
    )
    args = parser.parse_args()

    # Set output directory
    if args.output_dir is None:
        args.output_dir = str(Path(args.weights).parent.parent)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 80)
    print("YOLOv11n Validation")
    print(f"  Weights: {args.weights}")
    print(f"  Data: {args.data}")
    print(f"  Imgsz: {args.imgsz}")
    print(f"  Device: {args.device}")
    print(f"  Output Dir: {output_dir}")
    print("=" * 80)

    # Load model
    print("\nLoading model...")
    model = YOLO(args.weights)

    # Calculate model info
    print("\nCalculating model info...")
    model_info = calculate_model_info(model, args.weights, args.imgsz)
    print(f"  Params: {model_info['params_m']} M")
    print(f"  FLOPs: {model_info['flops_g']} G")
    print(f"  Model Size: {model_info['model_size_mb']} MB")

    # Measure FPS
    print("\nMeasuring FPS...")
    fps = measure_fps(model, args.imgsz, args.device)
    print(f"  FPS: {fps}")

    # Run validation
    print("\nRunning validation...")
    metrics = model.val(
        data=args.data,
        imgsz=args.imgsz,
        device=args.device,
        verbose=True
    )

    # Extract metrics with multiple fallback methods
    precision = 0.0
    recall = 0.0
    map50 = 0.0
    map50_95 = 0.0

    # Method 1: Try accessing through results_dict
    if hasattr(metrics, 'results_dict'):
        precision = float(metrics.results_dict.get('metrics/precision(B)', 0.0))
        recall = float(metrics.results_dict.get('metrics/recall(B)', 0.0))
        map50 = float(metrics.results_dict.get('metrics/mAP50(B)', 0.0))
        map50_95 = float(metrics.results_dict.get('metrics/mAP50-95(B)', 0.0))

    # Method 2: Try accessing through box attributes if method 1 failed
    if precision == 0.0 or recall == 0.0 or map50 == 0.0 or map50_95 == 0.0:
        if hasattr(metrics, 'box'):
            box_attrs = vars(metrics.box)
            precision = float(box_attrs.get('mp', 0.0)) if precision == 0.0 else precision
            recall = float(box_attrs.get('mr', 0.0)) if recall == 0.0 else recall
            map50 = float(box_attrs.get('map50', 0.0)) if map50 == 0.0 else map50
            map50_95 = float(box_attrs.get('map', 0.0)) if map50_95 == 0.0 else map50_95

    # Calculate F1
    f1 = 2 * (precision * recall) / (precision + recall + 1e-8)

    # Compile all metrics
    val_metrics = {
        "precision": round(precision, 6),
        "recall": round(recall, 6),
        "f1": round(f1, 6),
        "map50": round(map50, 6),
        "map50_95": round(map50_95, 6),
        "params_m": model_info["params_m"],
        "flops_g": model_info["flops_g"],
        "model_size_mb": model_info["model_size_mb"],
        "fps": fps
    }

    # Print summary
    print("\n" + "=" * 80)
    print("Validation Results Summary")
    print("=" * 80)
    print(f"  Precision: {val_metrics['precision']:.6f}")
    print(f"  Recall: {val_metrics['recall']:.6f}")
    print(f"  F1: {val_metrics['f1']:.6f}")
    print(f"  mAP50: {val_metrics['map50']:.6f}")
    print(f"  mAP50-95: {val_metrics['map50_95']:.6f}")
    print(f"  Params: {val_metrics['params_m']:.4f} M")
    print(f"  FLOPs: {val_metrics['flops_g']:.4f} G")
    print(f"  Model Size: {val_metrics['model_size_mb']:.4f} MB")
    print(f"  FPS: {val_metrics['fps']:.4f}")
    print("=" * 80)

    # Save validation metrics to JSON
    val_metrics_path = output_dir / "val_metrics.json"
    with open(val_metrics_path, "w", encoding="utf-8") as f:
        json.dump(val_metrics, f, indent=4, ensure_ascii=False)
    print(f"\nValidation metrics saved to: {val_metrics_path}")

    # Save model info to JSON
    model_info_path = output_dir / "model_info.json"
    model_info.update({
        "model_name": "YOLOv11n",
        "weights_path": args.weights,
        "data_config": args.data,
        "input_size": [args.imgsz, args.imgsz]
    })
    with open(model_info_path, "w", encoding="utf-8") as f:
        json.dump(model_info, f, indent=4, ensure_ascii=False)
    print(f"Model info saved to: {model_info_path}")

    # Save summary to CSV
    summary_df = pd.DataFrame([val_metrics])
    summary_csv_path = output_dir / "summary.csv"
    summary_df.to_csv(summary_csv_path, index=False, encoding="utf-8-sig")
    print(f"Summary saved to: {summary_csv_path}")

    print("\nValidation completed!")


if __name__ == "__main__":
    main()
