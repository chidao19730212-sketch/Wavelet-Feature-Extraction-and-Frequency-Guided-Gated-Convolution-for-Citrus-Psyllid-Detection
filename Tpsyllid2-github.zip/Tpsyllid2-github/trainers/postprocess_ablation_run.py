import argparse
import csv
import json
from pathlib import Path

import sys
import yaml
from ultralytics import YOLO

sys.path.insert(0, str(Path(__file__).parent.parent))
from models import register_lwsdet_modules

register_lwsdet_modules()


def _safe_float(x, default=-1.0):
    try:
        return float(x)
    except Exception:
        return float(default)


def _read_safe_stats(run_dir: Path):
    stats_path = run_dir / "safe_stats.json"
    if not stats_path.exists():
        return None
    try:
        return json.loads(stats_path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _read_best_metrics_from_results_csv(run_dir: Path):
    results_csv = run_dir / "results.csv"
    if not results_csv.exists():
        return None
    try:
        with results_csv.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            best = None
            best_key = None
            for row in reader:
                key = _safe_float(row.get("metrics/mAP50-95(B)", None), default=-1)
                if best is None or key > best_key:
                    best = row
                    best_key = key
            if best is None:
                return None
            return {
                "epoch": int(float(best.get("epoch", -1))),
                "precision": _safe_float(best.get("metrics/precision(B)", None)),
                "recall": _safe_float(best.get("metrics/recall(B)", None)),
                "map50": _safe_float(best.get("metrics/mAP50(B)", None)),
                "map50_95": _safe_float(best.get("metrics/mAP50-95(B)", None)),
            }
    except Exception:
        return None


def _count_val_instances_from_data_yaml(data_yaml: Path):
    data = yaml.safe_load(data_yaml.read_text(encoding="utf-8"))
    val_images = data.get("val", None)
    if val_images is None:
        raise ValueError(f"Missing 'val' in data yaml: {data_yaml}")

    val_images_path = Path(val_images)
    if not val_images_path.exists():
        raise FileNotFoundError(f"val images path not found: {val_images_path}")

    if val_images_path.name == "images":
        labels_dir = val_images_path.parent / "labels"
    else:
        labels_dir = val_images_path.parent / "labels"

    if not labels_dir.exists():
        raise FileNotFoundError(f"val labels dir not found: {labels_dir}")

    total = 0
    for p in labels_dir.rglob("*.txt"):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore").strip()
        except Exception:
            continue
        if not text:
            continue
        total += sum(1 for line in text.splitlines() if line.strip())
    return int(total)


def _append_summary_row(summary_csv: Path, row: dict):
    desired_header = [
        "Model",
        "Precision",
        "Recall",
        "F1",
        "mAP50",
        "mAP50_95",
        "Params_M",
        "FLOPs_G",
        "Model_Size_MB",
        "FPS",
        "FP",
        "FN",
        "Remarks",
    ]

    rows = []
    existing_header = None
    if summary_csv.exists():
        with summary_csv.open("r", newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            for r in reader:
                if not r or all(not c.strip() for c in r):
                    continue
                if existing_header is None:
                    existing_header = r
                else:
                    rows.append(r)

    if existing_header is None:
        existing_header = desired_header
    else:
        if "FP" not in existing_header:
            existing_header = existing_header + ["FP", "FN"]
        if "Remarks" not in existing_header:
            existing_header = existing_header + ["Remarks"]

    header = existing_header
    header_set = set(header)
    out_row = []
    for k in header:
        out_row.append(row.get(k, ""))

    normalized_rows = []
    for r in rows:
        if len(r) < len(header):
            r = r + [""] * (len(header) - len(r))
        normalized_rows.append(r[: len(header)])

    model_idx = 0 if header and header[0] == "Model" else None
    if model_idx is not None:
        normalized_rows = [r for r in normalized_rows if r[model_idx] != str(row.get("Model", ""))]

    summary_csv.parent.mkdir(parents=True, exist_ok=True)
    with summary_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for r in normalized_rows:
            writer.writerow(r)
        writer.writerow(out_row)

    return header_set != set(desired_header)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", type=str, required=True)
    parser.add_argument("--run-dir", type=str, required=True)
    parser.add_argument("--model-name", type=str, required=True)
    parser.add_argument("--data", type=str, default="configs/psyllid_slice640_balanced.yaml")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--summary-csv", type=str, default="runs_lightweight/summary_all_models.csv")
    args = parser.parse_args()

    weights_path = Path(args.weights)
    run_dir = Path(args.run_dir)
    data_yaml = Path(args.data)
    summary_csv = Path(args.summary_csv)

    if not weights_path.exists():
        raise FileNotFoundError(f"weights not found: {weights_path}")
    if not data_yaml.exists():
        raise FileNotFoundError(f"data yaml not found: {data_yaml}")
    run_dir.mkdir(parents=True, exist_ok=True)

    best_metrics = _read_best_metrics_from_results_csv(run_dir)
    if best_metrics is None:
        model = YOLO(str(weights_path))
        metrics = model.val(
            data=str(data_yaml),
            imgsz=args.imgsz,
            device=args.device,
            plots=False,
            save_json=False,
            verbose=False,
        )
        results_dict = getattr(metrics, "results_dict", None) or {}
        precision = _safe_float(results_dict.get("metrics/precision(B)", None))
        recall = _safe_float(results_dict.get("metrics/recall(B)", None))
        map50 = _safe_float(results_dict.get("metrics/mAP50(B)", None))
        map5095 = _safe_float(results_dict.get("metrics/mAP50-95(B)", None))
        best_epoch = -1
    else:
        precision = best_metrics["precision"]
        recall = best_metrics["recall"]
        map50 = best_metrics["map50"]
        map5095 = best_metrics["map50_95"]
        best_epoch = best_metrics["epoch"]
    f1 = (2.0 * precision * recall / (precision + recall)) if (precision + recall) > 0 else -1.0

    gt_instances = -1
    fp = -1
    fn = -1
    try:
        gt_instances = _count_val_instances_from_data_yaml(data_yaml)
        tp = int(round(recall * gt_instances)) if gt_instances >= 0 and recall >= 0 else -1
        fn = int(gt_instances - tp) if tp >= 0 else -1
        fp = int(round(tp * (1.0 / max(precision, 1e-9) - 1.0))) if tp >= 0 and precision > 0 else -1
    except Exception:
        pass

    safe_stats = _read_safe_stats(run_dir) or {}
    params_m = _safe_float(safe_stats.get("params_m", -1))
    flops_g_macs = _safe_float(safe_stats.get("flops_g", -1))
    fps = _safe_float(safe_stats.get("fps", -1))
    model_size_mb = _safe_float(safe_stats.get("model_size_mb", -1))

    val_metrics = {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "map50": map50,
        "map50_95": map5095,
        "best_epoch_from_results_csv": best_epoch,
        "val_gt_instances": gt_instances,
        "fp_est": fp,
        "fn_est": fn,
    }
    (run_dir / "val_metrics.json").write_text(json.dumps(val_metrics, indent=2), encoding="utf-8")

    model_info = {
        "params_m": params_m,
        "flops_g_macs": flops_g_macs,
        "flops_g_2xmacs": (2.0 * flops_g_macs) if flops_g_macs >= 0 else -1,
        "model_size_mb": model_size_mb,
        "fps": fps,
        "note_flops": "thop.profile reports MACs; Ultralytics 'GFLOPs' display is typically ~2x MACs (MACs*2).",
        "weights": str(weights_path),
    }
    (run_dir / "model_info.json").write_text(json.dumps(model_info, indent=2), encoding="utf-8")

    summary_row_csv = run_dir / "summary.csv"
    with summary_row_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "Model",
                "Precision",
                "Recall",
                "F1",
                "mAP50",
                "mAP50_95",
                "Params_M",
                "FLOPs_G",
                "Model_Size_MB",
                "FPS",
                "FP",
                "FN",
            ],
        )
        writer.writeheader()
        writer.writerow(
            {
                "Model": args.model_name,
                "Precision": precision,
                "Recall": recall,
                "F1": f1,
                "mAP50": map50,
                "mAP50_95": map5095,
                "Params_M": params_m,
                "FLOPs_G": flops_g_macs,
                "Model_Size_MB": model_size_mb,
                "FPS": fps,
                "FP": fp,
                "FN": fn,
            }
        )

    remarks = []
    if gt_instances >= 0:
        remarks.append(f"FP/FN estimated from P/R and GT={gt_instances}")
    row = {
        "Model": args.model_name,
        "Precision": precision,
        "Recall": recall,
        "F1": f1,
        "mAP50": map50,
        "mAP50_95": map5095,
        "Params_M": params_m,
        "FLOPs_G": flops_g_macs,
        "Model_Size_MB": model_size_mb,
        "FPS": fps,
        "FP": fp,
        "FN": fn,
        "Remarks": "; ".join(remarks),
    }

    _append_summary_row(summary_csv, row)


if __name__ == "__main__":
    main()
