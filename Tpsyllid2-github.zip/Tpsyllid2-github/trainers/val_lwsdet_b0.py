"""
LWS-Det-B0 Validation Script
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Register LWS-Det modules FIRST!
from models import register_lwsdet_modules
register_lwsdet_modules()

import argparse
import time
import json
import pandas as pd
import thop
import torch
from ultralytics import YOLO

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str, 
                        default='runs_lightweight/lwsdet_b0_dryrun/weights/best.pt',
                        help='Path to model weights')
    args = parser.parse_args()
    
    print("=" * 80)
    print("LWS-Det-B0 Validation")
    print("=" * 80)
    
    # Load model
    weights_path = Path(args.weights)
    if not weights_path.exists():
        print(f"❌ Weights not found: {weights_path}")
        return
    
    print(f"\nLoading model: {weights_path}")
    model = YOLO(str(weights_path))
    
    # Data config
    data_config = Path(__file__).parent.parent / "configs" / "psyllid_slice640_balanced.yaml"
    
    # Validate
    print(f"\nValidating...")
    metrics = model.val(
        data=str(data_config),
        imgsz=640,
        device='0',
        verbose=True
    )
    
    # Get model info (params, FLOPs)
    print("\n" + "=" * 80)
    print("Model Info")
    print("=" * 80)
    
    dummy_input = torch.randn(1, 3, 640, 640).to('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Calculate Params & FLOPs
    try:
        flops, params = thop.profile(model.model, inputs=(dummy_input,), verbose=False)
        print(f"Params:  {params/1e6:.2f} M")
        print(f"FLOPs:  {flops/1e9:.2f} G")
    except Exception as e:
        print(f"Could not calculate FLOPs: {e}")
        flops, params = 0, 0
    
    # Get file size
    model_size_mb = weights_path.stat().st_size / (1024 * 1024)
    print(f"Model Size: {model_size_mb:.2f} MB")
    
    # Get inference speed (FPS)
    print("\nMeasuring FPS...")
    model.to('cuda' if torch.cuda.is_available() else 'cpu')
    n_runs = 100
    warmup = 20
    with torch.no_grad():
        for i in range(n_runs + warmup):
            if i == warmup:
                t0 = time.time()
            model(dummy_input, verbose=False)
    t1 = time.time()
    fps = n_runs / (t1 - t0)
    print(f"FPS: {fps:.2f}")
    
    # Print all metrics
    print("\n" + "=" * 80)
    print("Validation Results Summary")
    print("=" * 80)
    p = metrics.box.map50 if hasattr(metrics.box, 'map50') else 0
    r = metrics.box.map if hasattr(metrics.box, 'map') else 0
    map50 = metrics.box.map50 if hasattr(metrics.box, 'map50') else 0
    map50_95 = metrics.box.map if hasattr(metrics.box, 'map') else 0
    
    try:
        p = metrics.box.mp
        r = metrics.box.mr
        map50 = metrics.box.map50
        map50_95 = metrics.box.map
    except:
        pass
    
    print(f"  Precision:    {p:.6f}")
    print(f"  Recall:       {r:.6f}")
    f1 = 2 * (p * r) / (p + r) if (p + r) > 0 else 0
    print(f"  F1:           {f1:.6f}")
    print(f"  mAP50:      {map50:.6f}")
    print(f"  mAP50-95: {map50_95:.6f}")
    print(f"  Params:       {params/1e6:.2f} M")
    print(f"  FLOPs:        {flops/1e9:.2f} G")
    print(f"  Model Size: {model_size_mb:.2f} MB")
    print(f"  FPS:          {fps:.2f}")
    print("=" * 80)
    
    # Save to JSON/CSV
    save_dir = weights_path.parent.parent
    val_metrics = {
        'precision': float(p),
        'recall': float(r),
        'f1': float(f1),
        'map50': float(map50),
        'map50_95': float(map50_95),
        'params_m': float(params/1e6),
        'flops_g': float(flops/1e9),
        'model_size_mb': float(model_size_mb),
        'fps': float(fps)
    }
    
    with open(save_dir / 'val_metrics.json', 'w') as f:
        json.dump(val_metrics, f, indent=2)
    print(f"\nSaved: {save_dir / 'val_metrics.json'}")
    
    model_info = {
        'params': int(params),
        'flops': int(flops),
        'model_size_bytes': weights_path.stat().st_size,
        'model_size_mb': float(model_size_mb),
        'fps': float(fps)
    }
    with open(save_dir / 'model_info.json', 'w') as f:
        json.dump(model_info, f, indent=2)
    print(f"Saved: {save_dir / 'model_info.json'}")
    
    # Create summary CSV
    df = pd.DataFrame([val_metrics])
    csv_path = save_dir / 'summary.csv'
    df.to_csv(csv_path, index=False)
    print(f"Saved: {csv_path}")
    
    print("\nDone!")

if __name__ == "__main__":
    main()
