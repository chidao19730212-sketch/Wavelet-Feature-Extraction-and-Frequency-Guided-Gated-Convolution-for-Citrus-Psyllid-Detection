import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from trainers.official_reval_fg_lssm import run_official_val
from models import register_lwsdet_modules


def main() -> None:
    register_lwsdet_modules()

    out_dir = ROOT / "runs_lightweight" / "official_reval_ablation"
    out_dir.mkdir(parents=True, exist_ok=True)

    data_yaml = "configs/psyllid_slice640_balanced.yaml"
    imgsz = 640
    batch = 4
    device_arg = "0"

    specs = [
        ("b0_basic_best", ROOT / "runs_lightweight" / "lwsdet_b0_basic" / "weights" / "best.pt"),
        ("b0_no_wavelet_best", ROOT / "runs_lightweight" / "lwsdet_b0_no_wavelet" / "weights" / "best.pt"),
        ("b0_full_best", ROOT / "runs_lightweight" / "lwsdet_b0_baseline" / "weights" / "best.pt"),
        ("b0_no_ssm_best", ROOT / "runs_lightweight" / "lwsdet_b0_no_ssm" / "weights" / "best.pt"),
        ("b1_fg_lssm_p5_last", ROOT / "runs_lightweight" / "lwsdet_b1_fg_lssm_p5" / "weights" / "last.pt"),
    ]

    rows = []
    for label, weights in specs:
        print(f"Running ablation official re-validation: {label}")
        rows.append(
            run_official_val(
                label=label,
                weights=weights,
                data_yaml=data_yaml,
                imgsz=imgsz,
                batch=batch,
                device_arg=device_arg,
                save_dir=out_dir,
            )
        )

    df = pd.DataFrame(rows)
    csv_path = out_dir / "ablation_summary.csv"
    json_path = out_dir / "ablation_summary.json"
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    payload = {
        "meta": {
            "data_yaml": data_yaml,
            "imgsz": imgsz,
            "batch": batch,
            "device": device_arg,
            "tta": False,
            "sahi": False,
            "wbf": False,
            "training_rerun": False,
            "b0_full_alias": "runs_lightweight/lwsdet_b0_baseline/weights/best.pt",
            "fps_note": "FPS is measured as images/second with batch=4 on device=0 using direct forward on dummy inputs.",
            "flops_note": "FLOPs are estimated as 2*MACs via thop on 1x3x640x640.",
        },
        "results": rows,
    }
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"WROTE {csv_path}")
    print(f"WROTE {json_path}")
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
