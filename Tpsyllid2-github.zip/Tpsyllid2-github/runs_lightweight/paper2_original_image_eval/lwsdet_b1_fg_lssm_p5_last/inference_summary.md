# Inference Summary

- experiment_name: lwsdet_b1_fg_lssm_p5_last
- base_model: lwsdet_b1_fg_lssm_p5
- model_type: LWS-Det-B1-FG-LSSM-P5
- dataset_version: slice640_balanced_rebuild_v1
- eval_level: original_full_image
- inference_pipeline: SAHI_TTA_WBF
- conf: 0.35
- iou_merge: 0.3
- weight_path: c:\Users\admim\Desktop\Tpsyllid2\runs_lightweight\lwsdet_b1_fg_lssm_p5\weights\last.pt

## Settings

- SAHI: slice_size=640, overlap=0.25
- TTA: scales=640/768/960; flip=lr
- WBF: conf=0.35, iou_merge=0.3, conf_type=avg

## Metrics

| split | Precision | Recall | F1 | mAP50 | mAP50-95 | TP | FP | FN | GT | time_s | FPS | avg_s/img |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| test | 0.5527 | 0.9105 | 0.6879 | 0.8215 | 0.3129 | 173 | 140 | 17 | 190 | 741.927 | 0.1415 | 7.065973 |