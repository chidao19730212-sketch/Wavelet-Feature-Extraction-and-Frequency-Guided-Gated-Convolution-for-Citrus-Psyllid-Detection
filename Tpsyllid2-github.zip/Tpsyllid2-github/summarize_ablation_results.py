import argparse
import csv
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class GroupCfg:
    key: str
    name: str
    train_dir: Path
    has_lightwavelet: bool
    has_fg_gdpr_p5: bool


def _groups(repo_root: Path, weights_type: str) -> list[GroupCfg]:
    base = repo_root / "runs" / "ablation"
    return [
        GroupCfg("A", "A_base", base / "A_base", False, False),
        GroupCfg("B", "B_wavelet", base / "B_wavelet", True, False),
        GroupCfg("C", "C_fg", base / "C_fg", False, True),
        GroupCfg("D", "D_full", base / "D_full", True, True),
    ]


def _read_eval_summary(group: GroupCfg, weights_type: str) -> dict | None:
    eval_dir = group.train_dir / f"original_image_eval_{weights_type}"
    p = eval_dir / "original_image_eval_summary.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))

    tm = eval_dir / "test_metrics.json"
    if not tm.exists():
        return None

    payload = json.loads(tm.read_text(encoding="utf-8"))
    best_metrics = payload.get("best_metrics", {})
    timing = payload.get("timing", {})

    structure_path = group.train_dir / "structure_check" / "structure_check.json"
    structure = json.loads(structure_path.read_text(encoding="utf-8")) if structure_path.exists() else {}
    weight_path = group.train_dir / "weights" / f"{weights_type}.pt"
    model_size_mb = (weight_path.stat().st_size / (1024 * 1024)) if weight_path.exists() else None

    return {
        "precision": best_metrics.get("precision"),
        "recall": best_metrics.get("recall"),
        "f1": best_metrics.get("f1"),
        "map50": best_metrics.get("mAP50"),
        "map50_95": best_metrics.get("mAP50_95"),
        "fp": best_metrics.get("fp"),
        "fn": best_metrics.get("fn"),
        "tp": best_metrics.get("tp"),
        "gt": best_metrics.get("gt"),
        "params_m": (structure.get("params_total") / 1e6) if structure.get("params_total") is not None else None,
        "flops_g": structure.get("flops_g"),
        "model_size_mb": model_size_mb,
        "test_fps": timing.get("fps"),
        "summary_path": str(tm),
    }


def _safe_float(v):
    try:
        return float(v)
    except Exception:
        return None


def _calc_f1(p: float, r: float) -> float:
    if p + r == 0:
        return 0.0
    return float((2.0 * p * r) / (p + r))


def _format_delta(a: dict, b: dict) -> dict:
    keys = [
        "precision",
        "recall",
        "f1",
        "map50",
        "map50_95",
        "fp",
        "fn",
        "params_m",
        "flops_g",
        "test_fps",
    ]
    out = {}
    for k in keys:
        va = a.get(k)
        vb = b.get(k)
        if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
            out[f"Δ{k}"] = float(vb - va)
        else:
            out[f"Δ{k}"] = None
    if isinstance(a.get("params_m"), (int, float)) and isinstance(b.get("params_m"), (int, float)) and float(a["params_m"]) != 0:
        out["Δparams_%"] = float((float(b["params_m"]) - float(a["params_m"])) / float(a["params_m"]) * 100.0)
    else:
        out["Δparams_%"] = None
    if isinstance(a.get("flops_g"), (int, float)) and isinstance(b.get("flops_g"), (int, float)) and float(a["flops_g"]) != 0:
        out["Δflops_%"] = float((float(b["flops_g"]) - float(a["flops_g"])) / float(a["flops_g"]) * 100.0)
    else:
        out["Δflops_%"] = None
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights_type", type=str, default="best", choices=["best", "last"])
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parent
    groups = _groups(repo_root, args.weights_type)

    rows = []
    by_key = {}
    for g in groups:
        summary = _read_eval_summary(g, args.weights_type)
        if summary is None:
            rows.append(
                {
                    "Group": g.key,
                    "LightWavelet": str(bool(g.has_lightwavelet)),
                    "FG_GDPR_P5": str(bool(g.has_fg_gdpr_p5)),
                    "Precision": "",
                    "Recall": "",
                    "F1": "",
                    "mAP50": "",
                    "mAP50-95": "",
                    "FP": "",
                    "FN": "",
                    "Params_M": "",
                    "FLOPs_G": "",
                    "ModelSize_MB": "",
                    "FPS": "",
                    "Status": "未完成",
                    "EvalSummary": "",
                }
            )
            continue

        p = _safe_float(summary.get("precision"))
        r = _safe_float(summary.get("recall"))
        f1 = _calc_f1(p, r) if p is not None and r is not None else _safe_float(summary.get("f1"))

        row = {
            "Group": g.key,
            "LightWavelet": str(bool(g.has_lightwavelet)),
            "FG_GDPR_P5": str(bool(g.has_fg_gdpr_p5)),
            "Precision": p,
            "Recall": r,
            "F1": f1,
            "mAP50": _safe_float(summary.get("map50")),
            "mAP50-95": _safe_float(summary.get("map50_95")),
            "FP": int(summary.get("fp")) if summary.get("fp") is not None else "",
            "FN": int(summary.get("fn")) if summary.get("fn") is not None else "",
            "Params_M": _safe_float(summary.get("params_m")),
            "FLOPs_G": _safe_float(summary.get("flops_g")),
            "ModelSize_MB": _safe_float(summary.get("model_size_mb")),
            "FPS": _safe_float(summary.get("test_fps")),
            "Status": "完成",
            "EvalSummary": str(summary.get("summary_path") or (g.train_dir / f"original_image_eval_{args.weights_type}" / "original_image_eval_summary.json")),
        }
        rows.append(row)
        by_key[g.key] = {
            "precision": row["Precision"],
            "recall": row["Recall"],
            "f1": row["F1"],
            "map50": row["mAP50"],
            "map50_95": row["mAP50-95"],
            "fp": row["FP"],
            "fn": row["FN"],
            "params_m": row["Params_M"],
            "flops_g": row["FLOPs_G"],
            "test_fps": row["FPS"],
        }

    out_csv = repo_root / "runs" / "ablation" / "ablation_4groups_summary.csv"
    out_md = repo_root / "runs" / "ablation" / "ablation_4groups_summary.md"
    out_delta = repo_root / "runs" / "ablation" / "ablation_4groups_deltas.json"
    out_csv.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "Group",
        "LightWavelet",
        "FG_GDPR_P5",
        "Precision",
        "Recall",
        "F1",
        "mAP50",
        "mAP50-95",
        "FP",
        "FN",
        "Params_M",
        "FLOPs_G",
        "ModelSize_MB",
        "FPS",
        "Status",
        "EvalSummary",
    ]

    with out_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)

    md_lines = []
    md_lines.append("| Group | LightWavelet | FG_GDPR_P5 | Precision | Recall | F1 | mAP50 | mAP50-95 | FP | FN | Params_M | FLOPs_G | ModelSize_MB | FPS | Status |")
    md_lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")
    for r in rows:
        md_lines.append(
            "| {Group} | {LightWavelet} | {FG_GDPR_P5} | {Precision} | {Recall} | {F1} | {mAP50} | {mAP50-95} | {FP} | {FN} | {Params_M} | {FLOPs_G} | {ModelSize_MB} | {FPS} | {Status} |".format(
                **{k: ("" if r[k] is None else r[k]) for k in fieldnames}
            )
        )
    out_md.write_text("\n".join(md_lines) + "\n", encoding="utf-8")

    deltas = {}
    if all(k in by_key for k in ["A", "B"]):
        deltas["B-A"] = _format_delta(by_key["A"], by_key["B"])
    if all(k in by_key for k in ["A", "C"]):
        deltas["C-A"] = _format_delta(by_key["A"], by_key["C"])
    if all(k in by_key for k in ["B", "D"]):
        deltas["D-B"] = _format_delta(by_key["B"], by_key["D"])
    if all(k in by_key for k in ["C", "D"]):
        deltas["D-C"] = _format_delta(by_key["C"], by_key["D"])
    if all(k in by_key for k in ["A", "D"]):
        deltas["D-A"] = _format_delta(by_key["A"], by_key["D"])

    out_delta.write_text(json.dumps(deltas, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
