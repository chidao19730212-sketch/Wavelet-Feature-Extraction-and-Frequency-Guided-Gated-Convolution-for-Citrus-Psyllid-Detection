import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

try:
    from sahi import AutoDetectionModel
    from sahi.predict import get_sliced_prediction
    from sahi.utils.cv import read_image
except ImportError as exc:
    raise SystemExit("SAHI not found. Please install it before running this script.") from exc


def register_project_modules(project_root: Path) -> None:
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))
    from models import register_lwsdet_modules

    register_lwsdet_modules()


def weighted_box_fusion(pred_sets, iou_thr=0.30, conf_type="avg", weights=None, topk=300):
    if not pred_sets:
        return []
    if weights is None:
        weights = [1.0] * len(pred_sets)

    candidates = []
    for w, dets in zip(weights, pred_sets):
        for det in dets:
            candidates.append(
                {
                    "box": [float(x) for x in det["box"]],
                    "score": float(det["score"]),
                    "w": float(w),
                }
            )
    candidates.sort(key=lambda d: d["score"], reverse=True)

    fused = []
    used = [False] * len(candidates)
    for i, det in enumerate(candidates):
        if used[i]:
            continue
        cluster = [det]
        used[i] = True
        for j in range(i + 1, len(candidates)):
            if used[j]:
                continue
            if xyxy_iou(det["box"], candidates[j]["box"]) >= float(iou_thr):
                used[j] = True
                cluster.append(candidates[j])

        ws = np.array([c["w"] for c in cluster], dtype=np.float32)
        ss = np.array([c["score"] for c in cluster], dtype=np.float32)
        weight_scores = ws * ss
        denom = float(weight_scores.sum() + 1e-16)
        coords = np.array([c["box"] for c in cluster], dtype=np.float32)
        fused_box = (coords * weight_scores[:, None]).sum(axis=0) / denom

        if conf_type == "avg":
            fused_score = float((ss * ws).sum() / (ws.sum() + 1e-16))
        elif conf_type == "max":
            fused_score = float(ss.max())
        elif conf_type == "sum":
            fused_score = float(min(1.0, (ss * ws).sum() / (ws.sum() + 1e-16) * len(cluster)))
        else:
            raise ValueError(f"Unknown conf_type: {conf_type}")

        fused.append({"box": fused_box.tolist(), "score": fused_score})
        if len(fused) >= int(topk):
            break

    fused.sort(key=lambda d: d["score"], reverse=True)
    return fused[:topk]


def xyxy_iou(a, b) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    iw = max(0.0, ix2 - ix1)
    ih = max(0.0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return float(inter / union) if union > 0 else 0.0


def build_detection_model(weights: Path, min_conf: float, device: str):
    return AutoDetectionModel.from_pretrained(
        model_type="ultralytics",
        model_path=str(weights),
        confidence_threshold=float(min_conf),
        device=device,
    )


def predict_with_original_protocol(image_path: Path, detection_model, overlap_ratio: float):
    img = read_image(str(image_path))
    h, w = img.shape[:2]
    scales = [640, 768, 960]
    pred_sets = []

    for scale in scales:
        result = get_sliced_prediction(
            str(image_path),
            detection_model,
            slice_height=int(scale),
            slice_width=int(scale),
            overlap_height_ratio=float(overlap_ratio),
            overlap_width_ratio=float(overlap_ratio),
            perform_standard_pred=False,
            verbose=0,
        )
        dets = []
        for obj in result.object_prediction_list:
            dets.append(
                {
                    "box": [
                        float(obj.bbox.minx),
                        float(obj.bbox.miny),
                        float(obj.bbox.maxx),
                        float(obj.bbox.maxy),
                    ],
                    "score": float(obj.score.value),
                }
            )
        pred_sets.append(dets)

        img_flipped = img[:, ::-1, :].copy()
        result_flipped = get_sliced_prediction(
            img_flipped,
            detection_model,
            slice_height=int(scale),
            slice_width=int(scale),
            overlap_height_ratio=float(overlap_ratio),
            overlap_width_ratio=float(overlap_ratio),
            perform_standard_pred=False,
            verbose=0,
        )
        dets_flip = []
        for obj in result_flipped.object_prediction_list:
            x1 = float(obj.bbox.minx)
            y1 = float(obj.bbox.miny)
            x2 = float(obj.bbox.maxx)
            y2 = float(obj.bbox.maxy)
            dets_flip.append({"box": [w - x2, y1, w - x1, y2], "score": float(obj.score.value)})
        pred_sets.append(dets_flip)

    filtered_sets = []
    for dets in pred_sets:
        filtered_sets.append([d for d in dets if d["score"] >= 0.35])

    fused = weighted_box_fusion(filtered_sets, iou_thr=0.30, conf_type="avg")
    fused = [d for d in fused if d["score"] >= 0.35]
    return img, fused


def draw_detections(image_rgb: np.ndarray, detections, class_name: str) -> np.ndarray:
    image_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)
    vis = image_bgr.copy()
    h, w = vis.shape[:2]
    base = max(h, w)
    line_thickness = max(2, int(round(base / 1024.0)))
    font_scale = max(0.8, base / 2400.0)
    font_thickness = max(2, int(round(line_thickness * 0.8)))

    for det in detections:
        x1, y1, x2, y2 = [int(round(v)) for v in det["box"]]
        x1 = max(0, min(x1, w - 1))
        y1 = max(0, min(y1, h - 1))
        x2 = max(0, min(x2, w - 1))
        y2 = max(0, min(y2, h - 1))
        if x2 <= x1 or y2 <= y1:
            continue

        label = f"{class_name} {det['score']:.2f}"
        (tw, th), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, font_thickness)
        box_h = th + baseline + 8
        box_w = tw + 10

        label_x1 = x1
        if label_x1 + box_w > w - 1:
            label_x1 = (w - 1) - box_w
        label_x1 = max(0, label_x1)
        label_x2 = min(w - 1, label_x1 + box_w)

        if y1 - box_h - 2 >= 0:
            text_y1 = y1 - box_h - 2
        else:
            text_y1 = min(h - 1 - box_h, y1 + 2)
            text_y1 = max(0, text_y1)
        text_y2 = min(h - 1, text_y1 + box_h)

        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 0), line_thickness)
        cv2.rectangle(vis, (label_x1, text_y1), (label_x2, text_y2), (0, 255, 0), -1)
        cv2.putText(
            vis,
            label,
            (label_x1 + 5, text_y2 - baseline - 4),
            cv2.FONT_HERSHEY_SIMPLEX,
            font_scale,
            (0, 0, 0),
            font_thickness,
            lineType=cv2.LINE_AA,
        )
    return vis


def _select_zoom_roi(img_h: int, img_w: int, detections):
    if not detections:
        side = min(img_w, img_h)
        side = min(side, 1024)
        x0 = max(0, (img_w - side) // 2)
        y0 = max(0, (img_h - side) // 2)
        return x0, y0, x0 + side, y0 + side

    best = max(detections, key=lambda d: float(d.get("score", 0.0)))
    x1, y1, x2, y2 = [float(v) for v in best["box"]]
    bw = max(1.0, x2 - x1)
    bh = max(1.0, y2 - y1)
    cx = 0.5 * (x1 + x2)
    cy = 0.5 * (y1 + y2)

    side = int(round(max(bw, bh) * 8.0))
    side = max(800, side)
    side = min(side, min(img_w, img_h))

    x0 = int(round(cx - side / 2))
    y0 = int(round(cy - side / 2))
    x0 = max(0, min(x0, img_w - side))
    y0 = max(0, min(y0, img_h - side))
    return x0, y0, x0 + side, y0 + side


def _shift_detections(detections, dx: float, dy: float):
    shifted = []
    for d in detections:
        x1, y1, x2, y2 = [float(v) for v in d["box"]]
        shifted.append({"box": [x1 - dx, y1 - dy, x2 - dx, y2 - dy], "score": float(d["score"])})
    return shifted


def _compose_side_by_side(left_bgr: np.ndarray, right_bgr: np.ndarray):
    lh, lw = left_bgr.shape[:2]
    rh, rw = right_bgr.shape[:2]
    if rh <= 0 or rw <= 0:
        return left_bgr

    scale = float(lh) / float(rh)
    new_w = max(1, int(round(rw * scale)))
    right_resized = cv2.resize(right_bgr, (new_w, lh), interpolation=cv2.INTER_LINEAR)

    gap = max(10, int(round(max(lh, lw) / 400.0)))
    canvas = np.full((lh, lw + gap + new_w, 3), 255, dtype=np.uint8)
    canvas[:, :lw] = left_bgr
    canvas[:, lw + gap : lw + gap + new_w] = right_resized
    return canvas


def parse_args():
    project_root = Path(__file__).resolve().parent
    default_weights = project_root / "runs_lightweight" / "lwsdet_b1_fg_lssm_p5" / "weights" / "best.pt"
    default_output = project_root / "visualization_outputs"
    default_test_dir = Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_split\test\images")

    parser = argparse.ArgumentParser(description="Visualize LWG/LWS-Det detections on original high-resolution images.")
    parser.add_argument("--weights", type=Path, default=default_weights, help="Path to LWG/LWS-Det final best.pt")
    parser.add_argument("--output_dir", type=Path, default=default_output, help="Directory to save visualization outputs")
    parser.add_argument(
        "--images",
        type=Path,
        nargs=3,
        default=[
            default_test_dir / "0011.jpg",
            default_test_dir / "0033.jpg",
            default_test_dir / "0036.jpg",
        ],
        help="Exactly three original high-resolution test images",
    )
    parser.add_argument("--device", type=str, default="cuda:0", help="Inference device, e.g. cuda:0 or cpu")
    parser.add_argument("--class_name", type=str, default="psyllid", help="Class label drawn on detections")
    return parser.parse_args()


def main():
    args = parse_args()
    project_root = Path(__file__).resolve().parent

    if not args.weights.exists():
        raise SystemExit(f"Weight file does not exist: {args.weights}")
    for image_path in args.images:
        if not image_path.exists():
            raise SystemExit(f"Image file does not exist: {image_path}")

    args.output_dir.mkdir(parents=True, exist_ok=True)

    register_project_modules(project_root)
    detection_model = build_detection_model(args.weights, min_conf=0.15, device=args.device)

    output_stems = ["image1_lwg", "image2_lwg", "image3_lwg"]
    for idx, image_path in enumerate(args.images):
        image_rgb, fused = predict_with_original_protocol(image_path, detection_model, overlap_ratio=0.25)
        vis_bgr = draw_detections(image_rgb, fused, args.class_name)

        h, w = vis_bgr.shape[:2]
        x0, y0, x1, y1 = _select_zoom_roi(h, w, fused)
        crop_rgb = image_rgb[y0:y1, x0:x1, :]
        crop_dets = _shift_detections(fused, dx=float(x0), dy=float(y0))
        zoom_bgr = draw_detections(crop_rgb, crop_dets, args.class_name)
        collage_bgr = _compose_side_by_side(vis_bgr, zoom_bgr)

        jpg_path = args.output_dir / f"{output_stems[idx]}.jpg"
        png_path = args.output_dir / f"{output_stems[idx]}.png"
        cv2.imwrite(str(jpg_path), collage_bgr)
        cv2.imwrite(str(png_path), collage_bgr)
        print(f"[{idx + 1}/3] saved {jpg_path}")
        print(f"[{idx + 1}/3] saved {png_path}")

        zoom_jpg = args.output_dir / f"{output_stems[idx]}_zoom.jpg"
        zoom_png = args.output_dir / f"{output_stems[idx]}_zoom.png"
        cv2.imwrite(str(zoom_jpg), zoom_bgr)
        cv2.imwrite(str(zoom_png), zoom_bgr)

        full_jpg = args.output_dir / f"{output_stems[idx]}_full.jpg"
        full_png = args.output_dir / f"{output_stems[idx]}_full.png"
        cv2.imwrite(str(full_jpg), vis_bgr)
        cv2.imwrite(str(full_png), vis_bgr)


if __name__ == "__main__":
    main()
