from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms.functional import to_tensor


@dataclass(frozen=True)
class YoloSliceSplitPaths:
    images_dir: Path
    labels_dir: Path


def _list_images(images_dir: Path) -> list[Path]:
    exts = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp")
    files: list[Path] = []
    for p in images_dir.iterdir():
        if p.is_file() and p.suffix.lower() in exts:
            files.append(p)
    files.sort(key=lambda x: x.name)
    return files


def _read_yolo_txt(label_path: Path) -> list[list[float]]:
    if not label_path.exists():
        return []
    rows: list[list[float]] = []
    for line in label_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        s = line.strip()
        if not s:
            continue
        parts = s.split()
        if len(parts) < 5:
            continue
        try:
            xc = float(parts[1])
            yc = float(parts[2])
            w = float(parts[3])
            h = float(parts[4])
        except Exception:
            continue
        rows.append([xc, yc, w, h])
    return rows


def _xywhn_to_xyxy_pixels(xc: float, yc: float, w: float, h: float, img_w: int, img_h: int) -> tuple[float, float, float, float]:
    x1 = (xc - w / 2.0) * float(img_w)
    y1 = (yc - h / 2.0) * float(img_h)
    x2 = (xc + w / 2.0) * float(img_w)
    y2 = (yc + h / 2.0) * float(img_h)
    return x1, y1, x2, y2


def _clamp_xyxy(x1: float, y1: float, x2: float, y2: float, img_w: int, img_h: int) -> tuple[float, float, float, float]:
    x1 = max(0.0, min(float(img_w), x1))
    x2 = max(0.0, min(float(img_w), x2))
    y1 = max(0.0, min(float(img_h), y1))
    y2 = max(0.0, min(float(img_h), y2))
    return x1, y1, x2, y2


def _filter_valid_boxes(xyxy: Iterable[tuple[float, float, float, float]], min_size_px: float = 1.0) -> list[tuple[float, float, float, float]]:
    out: list[tuple[float, float, float, float]] = []
    for x1, y1, x2, y2 in xyxy:
        if (x2 - x1) >= min_size_px and (y2 - y1) >= min_size_px:
            out.append((x1, y1, x2, y2))
    return out


class TorchvisionYoloDetectionDataset(Dataset):
    def __init__(
        self,
        images_dir: str | Path,
        labels_dir: str | Path | None = None,
        limit: int = 0,
        start_index: int = 0,
    ) -> None:
        self.images_dir = Path(images_dir)
        self.labels_dir = Path(labels_dir) if labels_dir is not None else (self.images_dir.parent / "labels")
        self._all_images = _list_images(self.images_dir)
        if start_index < 0:
            start_index = 0
        if limit and limit > 0:
            self.image_paths = self._all_images[start_index : start_index + int(limit)]
        else:
            self.image_paths = self._all_images[start_index:]

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int):
        img_path = self.image_paths[idx]
        with Image.open(img_path) as im:
            im = im.convert("RGB")
            img_w, img_h = im.size
            image = to_tensor(im)

        label_path = self.labels_dir / f"{img_path.stem}.txt"
        rows = _read_yolo_txt(label_path)

        xyxy: list[tuple[float, float, float, float]] = []
        for xc, yc, w, h in rows:
            x1, y1, x2, y2 = _xywhn_to_xyxy_pixels(xc, yc, w, h, img_w, img_h)
            x1, y1, x2, y2 = _clamp_xyxy(x1, y1, x2, y2, img_w, img_h)
            xyxy.append((x1, y1, x2, y2))
        xyxy = _filter_valid_boxes(xyxy, min_size_px=1.0)

        if xyxy:
            boxes = torch.tensor(xyxy, dtype=torch.float32)
            labels = torch.ones((boxes.shape[0],), dtype=torch.int64)
            area = (boxes[:, 2] - boxes[:, 0]).clamp(min=0) * (boxes[:, 3] - boxes[:, 1]).clamp(min=0)
        else:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.int64)
            area = torch.zeros((0,), dtype=torch.float32)

        target = {
            "boxes": boxes,
            "labels": labels,
            "image_id": torch.tensor([int(idx)], dtype=torch.int64),
            "area": area,
            "iscrowd": torch.zeros((labels.shape[0],), dtype=torch.int64),
        }
        return image, target


def detection_collate_fn(batch):
    images, targets = zip(*batch)
    return list(images), list(targets)

