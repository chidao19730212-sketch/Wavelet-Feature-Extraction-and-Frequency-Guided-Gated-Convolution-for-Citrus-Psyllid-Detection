# Horizontal Comparison Plan

## Scope

- This document only defines the horizontal comparison experiment plan.
- No training, dependency installation, model structure modification, or result overwriting is performed in this step.

## Execution Order

1. YOLO11n unified official re-validation
2. RT-DETR-ResNet50 dry-run
3. RT-DETR-ResNet50 formal training
4. LWS-Det-B1-FG-LSSM-P5-last unified official re-validation
5. Teacher Wavelet+SSM read-only result organization or re-validation

## Result Directory Naming

- `runs_lightweight/horizontal_compare/yolo11n/`
- `runs_lightweight/horizontal_compare/rtdetr_resnet50_dryrun/`
- `runs_lightweight/horizontal_compare/rtdetr_resnet50/`
- `runs_lightweight/horizontal_compare/ours_lwsdet_b1_fg_lssm_p5/`
- `runs_lightweight/horizontal_compare/teacher_wavelet_ssm/`

## Main Table Template

| Model | Category | Precision | Recall | F1 | mAP50 | mAP50-95 | Params(M) | FLOPs(G) | FPS | Model Size(MB) | Notes |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| YOLO11n | lightweight real-time YOLO baseline | - | - | - | - | - | - | - | - | - | - |
| RT-DETR-ResNet50 | Transformer/DETR baseline | - | - | - | - | - | - | - | - | - | - |
| Teacher Wavelet+SSM | heavy upper-bound reference | - | - | - | - | - | - | - | - | - | - |
| LWS-Det-B1-FG-LSSM-P5 | ours | - | - | - | - | - | - | - | - | - | - |

## Model Positioning

- `YOLO11n`: lightweight real-time YOLO baseline
- `RT-DETR-ResNet50`: Transformer/DETR baseline
- `Teacher Wavelet+SSM`: heavy upper-bound reference
- `LWS-Det-B1-FG-LSSM-P5`: ours

## Unified Experimental Protocol

- `data=configs/psyllid_slice640_balanced.yaml`
- `imgsz=640`
- `batch=4`
- `device=0`
- `SAHI/TTA/WBF`: all disabled
- Do not mix diagnosis metrics with official validation metrics
- `Params/FLOPs/FPS`: must be computed by one unified statistics script

## Risk Notes

- `RT-DETR-ResNet50` is not a lightweight model and is included mainly as a Transformer/DETR paradigm reference.
- `Teacher Wavelet+SSM` is a heavy upper-bound reference and should not be used to make resource-fair conclusions against lightweight models.
- If dependency installation is allowed later, `RTMDet-tiny` can be added to strengthen the non-YOLO single-stage comparison.

## Restrictions

- Do not start training in this step.
- Do not install new dependencies in this step.
- Do not modify the `LWS-Det` structure in this step.
- Do not overwrite any existing results in this step.
