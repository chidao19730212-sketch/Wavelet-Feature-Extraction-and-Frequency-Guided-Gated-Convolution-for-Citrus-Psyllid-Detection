# LWS-Det 设计计划

**Lightweight Wavelet-State Space Detector**

---

## 1. 第一篇 Wavelet+SSM 原型结构分析

### 1.1 文件清单（当前工程已包含）

| 文件 | 位置 |
|------|------|
| 模型定义 | `teacher/models/wavelet_ssm_def.py` |
| 配置文件 | `configs/teacher_wavelet_ssm.yaml` |
| 权重文件 | `teacher/weights/best.pt` |

### 1.2 网络结构概览

```
Input (640x640)
    │
    ▼
┌─────────────────────────────────────────┐
│  Backbone                               │
│  ├── Conv(64, 3, 2)                    │
│  ├── WaveletBlock(128)                 │
│  ├── 3x C2f(128)                       │
│  ├── Conv(256, 3, 2)                   │
│  ├── 6x C2f(256, is_mamba=True)        │
│  ├── Conv(512, 3, 2)                   │
│  ├── 6x C2f(512, is_mamba=True)        │
│  ├── Conv(1024, 3, 2)                  │
│  ├── 3x C2f(1024, is_mamba=True)       │
│  └── SPPF(1024, 5)                     │
└─────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────┐
│  Neck (FPN-PAN)                        │
│  ├── Upsample + Concat                  │
│  ├── 3x C2f(512)                       │
│  ├── Upsample + Concat                  │
│  ├── 3x C2f(256)                       │
│  ├── Conv(256, 3, 2) + Concat          │
│  ├── 3x C2f(512)                       │
│  ├── Conv(512, 3, 2) + Concat          │
│  └── 3x C2f(1024)                      │
└─────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────┐
│  Detection Head                         │
│  └── Detect(P3, P4, P5)                │
└─────────────────────────────────────────┘
```

### 1.3 各模块分析

#### WaveletBlock（小波增强模块）
```python
class WaveletBlock:
    - dwt_haar(x): Haar小波分解 (LL, LH, HL, HH)
    - cv_ll: Conv(c1, c2, 3, 1)
    - cv_high: Conv(c1*3, c2, 1, 1)
    - fusion: Conv(c2*2, c2, 1, 1)
    - noise_suppression: 参数化噪声抑制
```
**特点：**
- 分离低频和高频分量
- 参数量中等，但有多个 Conv
- 高频分量可学习抑制

#### MambaBlock（SSM 模块）
```python
class MambaBlock:
    - conv: Conv2d(c, c, 3, padding=1, groups=c)
    - proj: Conv2d(c, c, 1)
    - act: SiLU
```
**特点：**
- 简化版 Mamba（非完整 Mamba）
- Depth-wise + Point-wise 结构
- 参数量主要在 proj conv

#### 参数量和 FLOPs 大头
| 部分 | 原因 |
|------|------|
| 大通道数 | 1024、512、256 通道开销大 |
| 多层 C2f | 3, 6, 6, 3 层堆积 |
| Neck 重复 C2f | 各分支都有 3 层 C2f |
| 标准 FPN-PAN | 双向上采样 + Concat |

---

## 2. LWS-Det 总体结构设计

### 2.1 核心理念

**保留 + 轻量化 + 创新**
- ✅ 保留：小波频域增强思想
- ✅ 保留：状态空间建模思想
- 🔄 轻量化：通道压缩、层数减少、模块简化
- 💡 创新：轻量小波模块、轻量 SSM、简化 Neck

### 2.2 总体架构

```
Input (640x640)
    │
    ▼
┌─────────────────────────────────────────┐
│  LWS-Backbone                          │
│  ├── LightStem (轻量化 Stem)          │
│  ├── LightWavelet (轻量小波模块)      │
│  ├── LightSSM-Stage1 (轻量 SSM 阶段1) │
│  ├── LightSSM-Stage2 (轻量 SSM 阶段2) │
│  ├── LightSSM-Stage3 (轻量 SSM 阶段3) │
│  └── LightSPPF (轻量 SPPF)            │
└─────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────┐
│  LWS-Neck (轻量化 FPN-PAN)             │
│  ├── LightFPN                          │
│  └── LightPAN                          │
└─────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────┐
│  LWS-Head                              │
│  └── Detect(P3, P4, P5)               │
└─────────────────────────────────────────┘
```

---

## 3. LWS-Det 三阶段版本设计

### 3.1 LWS-Det-B0：最小化验证版本

| 项目 | 设计 |
|------|------|
| 目标 | 验证小波 + SSM 思想可在轻量模型上工作 |
| 参数量 | ~3-4M |
| FLOPs | ~8-10G |

#### Backbone (LWS-Backbone-B0)
```
Stem: Conv(32, 3, 2)

Stage 1 (P2/4):
  - LightWavelet(32→64)
  - 1x LightC2f(64)

Stage 2 (P3/8):
  - Conv(64, 3, 2)
  - 2x LightSSMC2f(128)

Stage 3 (P4/16):
  - Conv(128, 3, 2)
  - 2x LightSSMC2f(256)

Stage 4 (P5/32):
  - Conv(256, 3, 2)
  - 1x LightC2f(512)
  - LightSPPF(512)
```

#### Neck (LWS-Neck-B0)
```
FPN:
  - Upsample P5 → P4, Concat with P4
  - 1x LightC2f(256)
  - Upsample P4 → P3, Concat with P3
  - 1x LightC2f(128)

PAN:
  - Conv(128, 3, 2) → P4, Concat with P4
  - 1x LightC2f(256)
  - Conv(256, 3, 2) → P5, Concat with P5
  - 1x LightC2f(512)
```

### 3.2 LWS-Det-B1：平衡版本

| 项目 | 设计 |
|------|------|
| 目标 | 平衡精度和速度，接近 YOLOv11n |
| 参数量 | ~4-5M |
| FLOPs | ~10-12G |

#### Backbone (LWS-Backbone-B1)
```
Stem: Conv(32, 3, 2)

Stage 1 (P2/4):
  - LightWavelet(32→64)
  - 2x LightC2f(64)

Stage 2 (P3/8):
  - Conv(64, 3, 2)
  - 3x LightSSMC2f(128)

Stage 3 (P4/16):
  - Conv(128, 3, 2)
  - 3x LightSSMC2f(256)

Stage 4 (P5/32):
  - Conv(256, 3, 2)
  - 2x LightSSMC2f(512)
  - LightSPPF(512)
```

#### Neck (LWS-Neck-B1)
```
FPN:
  - Upsample P5 → P4, Concat with P4
  - 2x LightC2f(256)
  - Upsample P4 → P3, Concat with P3
  - 2x LightC2f(128)

PAN:
  - Conv(128, 3, 2) → P4, Concat with P4
  - 2x LightC2f(256)
  - Conv(256, 3, 2) → P5, Concat with P5
  - 2x LightC2f(512)
```

### 3.3 LWS-Det-B2：性能优先版本

| 项目 | 设计 |
|------|------|
| 目标 | 尽可能接近 Teacher，保持轻量 |
| 参数量 | ~6-8M |
| FLOPs | ~15-20G |

#### Backbone (LWS-Backbone-B2)
```
Stem: Conv(48, 3, 2)

Stage 1 (P2/4):
  - LightWavelet(48→96)
  - 3x LightC2f(96)

Stage 2 (P3/8):
  - Conv(96, 3, 2)
  - 4x LightSSMC2f(192)

Stage 3 (P4/16):
  - Conv(192, 3, 2)
  - 4x LightSSMC2f(384)

Stage 4 (P5/32):
  - Conv(384, 3, 2)
  - 3x LightSSMC2f(512)
  - LightSPPF(512)
```

#### Neck (LWS-Neck-B2)
```
FPN:
  - Upsample P5 → P4, Concat with P4
  - 3x LightC2f(384)
  - Upsample P4 → P3, Concat with P3
  - 3x LightC2f(192)

PAN:
  - Conv(192, 3, 2) → P4, Concat with P4
  - 3x LightC2f(384)
  - Conv(384, 3, 2) → P5, Concat with P5
  - 3x LightC2f(512)
```

---

## 4. 轻量化模块设计方向

### 4.1 小波模块轻量化

| 原设计 | 轻量化方案 |
|--------|-----------|
| WaveletBlock(128) | LightWavelet(压缩通道) |
| - cv_ll: Conv(3x3) | - cv_ll: Conv(1x1 或 3x3 groups) |
| - cv_high: Conv(1x1) | - cv_high: 保持 1x1 或分组 |
| - fusion: Conv(1x1) | - fusion: 保持 1x1 |
| - 独立 noise_suppression | - 移除或简化 noise_suppression |

### 4.2 SSM 模块轻量化

| 原设计 | 轻量化方案 |
|--------|-----------|
| MambaBlock(c) | LightSSMBlock(简化) |
| - Depth-wise Conv(3x3) | - 保持，但可选更小 kernel |
| - Point-wise Conv(1x1) | - 保持，但压缩通道 |
| - 完整版 | - 可选：用 GhostConv 或 Mobile 模块 |

### 4.3 C2f 模块轻量化

| 原设计 | 轻量化方案 |
|--------|-----------|
| C2f(c) | LightC2f(压缩瓶颈) |
| Bottleneck 完整 | - 简化 Bottleneck 结构 |
| 重复多层 | - 减少重复次数 |

---

## 5. 文件清单与新增计划

### 5.1 需新增/修改的文件

| 文件 | 类型 | 阶段 |
|------|------|------|
| `models/modules/lws_modules.py` | 新增 | B0 |
| `models/lwsdet_backbone.py` | 新增 | B0 |
| `models/lwsdet_neck.py` | 新增 | B0 |
| `configs/lwsdet_b0.yaml` | 新增 | B0 |
| `configs/lwsdet_b1.yaml` | 新增 | B1 |
| `configs/lwsdet_b2.yaml` | 新增 | B2 |
| `trainers/train_lwsdet.py` | 新增 | B0 |
| `trainers/val_lwsdet.py` | 新增 | B0 |
| `docs/lwsdet_structure.md` | 新增 | B0 |
| `docs/lwsdet_ablation.md` | 新增 | B1 |

### 5.2 保留文件（只读）

| 文件 | 用途 |
|------|------|
| `teacher/models/wavelet_ssm_def.py` | Teacher 模型定义 |
| `configs/teacher_wavelet_ssm.yaml` | Teacher 配置 |
| `teacher/weights/best.pt` | Teacher 权重 |
| `trainers/train_yolo11n.py` | YOLO11n 基线训练 |
| `trainers/val_yolo11n.py` | YOLO11n 基线验证 |

---

## 6. 可能的风险点

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| 小波模块简化后性能下降 | 精度下降 | 保留 B0 版本，如果降太多保留原始小波 |
| SSM 模块简化后效果变差 | 精度下降 | 可选：保留原始 MambaBlock，但减少层数 |
| 通道压缩太多信息丢失 | 精度下降 | 从 B0 到 B2 逐渐增加通道 |
| 训练不稳定 | 收敛难 | 先用 B0 验证训练流程 |
| 与 Ultralytics 框架集成问题 | 工程问题 | 参考 teacher 模块的注册方式 |
| 轻量后与 YOLOv11n 相比无优势 | 论文难写 | 从 B0 开始，确保至少持平或更好 |

---

## 7. 下一步最小可实现任务

### 任务 1：创建轻量模块骨架
**目标文件：** `models/modules/lws_modules.py`
- 实现 `LightWavelet` 类（简化版小波）
- 实现 `LightSSMBlock` 类（简化版 SSM）
- 实现 `LightC2f` 类（简化版 C2f）
- 实现 `LightSPPF` 类（简化版 SPPF）

### 任务 2：创建 B0 配置
**目标文件：** `configs/lwsdet_b0.yaml`
- 定义 LWS-Det-B0 的完整结构
- 设置通道数、层数等参数

### 任务 3：验证模块注册
- 参考 `teacher/models/wavelet_ssm_def.py` 的注册方式
- 确保模块可被 Ultralytics 正确解析

**预期输出：**
- 可初始化的 LWS-Det-B0 模型
- 能打印模型结构和参数量

---

## 8. 完整阶段规划

| 阶段 | 目标 | 时间 |
|------|------|------|
| Phase 1 | LWS-Det-B0 实现 + 验证 | - |
| Phase 2 | LWS-Det-B1 实现 + 消融 | - |
| Phase 3 | LWS-Det-B2 实现 + 完整对比 | - |
| Phase 4 | 频域引导知识蒸馏 (FG-KD) | - |

---

## 9. 对比基线

| 模型 | Params | FLOPs | mAP50 | mAP50-95 |
|------|--------|-------|-------|----------|
| Wavelet+SSM (Teacher) | 49.85M | 121.6G | 0.8062 | 0.3111 |
| YOLOv11n (Baseline) | 2.59M | 6.4G | 0.7047 | 0.3034 |
| LWS-Det-B0 (Target) | ~3.5M | ~9G | >0.68 | >0.29 |
| LWS-Det-B1 (Target) | ~4.5M | ~11G | >0.70 | >0.30 |
| LWS-Det-B2 (Target) | ~7M | ~18G | >0.73 | >0.31 |

---

## 10. 核心原则

1. **保留核心思想**：小波频域增强 + SSM 状态空间建模
2. **分阶段验证**：B0 → B1 → B2 渐进式开发
3. **不修改 Teacher**：仅用于蒸馏和对比
4. **不替换 YOLO11n**：作为独立基线，用于对比
5. **可复现优先**：每个版本有独立配置和结果
