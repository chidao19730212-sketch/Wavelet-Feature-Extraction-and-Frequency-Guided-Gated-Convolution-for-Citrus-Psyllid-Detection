import argparse
import json
import time
from dataclasses import dataclass
from pathlib import Path

import torch
import thop
from ultralytics import YOLO

from models import register_lwsdet_modules


@dataclass(frozen=True)
class AblationGroup:
    key: str
    yaml_path: Path
    save_dir: Path
    has_lightwavelet: bool
    has_fg_gdpr_p5: bool


def _ensure_parent(p: Path) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)


def _shape(x):
    if isinstance(x, torch.Tensor):
        return list(x.shape)
    if isinstance(x, (list, tuple)):
        return [_shape(t) for t in x]
    return str(type(x).__name__)


def _infer_stride_from_hw(out_shape, base_hw=640):
    if not isinstance(out_shape, list) or len(out_shape) != 4:
        return None
    h = out_shape[2]
    if not isinstance(h, int) or h <= 0:
        return None
    return int(base_hw // h) if base_hw % h == 0 else None


def _run_structure_check(group: AblationGroup, device: str, overwrite: bool) -> dict:
    out_dir = group.save_dir / "structure_check"
    out_json = out_dir / "structure_check.json"
    out_txt = out_dir / "structure_check.txt"

    if out_json.exists() and not overwrite:
        return json.loads(out_json.read_text(encoding="utf-8"))

    out_dir.mkdir(parents=True, exist_ok=True)

    model = YOLO(str(group.yaml_path), task="detect")
    dm = model.model
    dm.to(device)
    dm.eval()

    dummy = torch.randn(1, 3, 640, 640, device=device)
    layer_records = []
    handles = []

    for idx, layer in enumerate(dm.model):
        def hook(mod, inp, out, idx=idx):
            in_v = inp[0] if isinstance(inp, tuple) and len(inp) == 1 else inp
            in_s = _shape(in_v)
            out_s = _shape(out)
            rec = {
                "index": idx,
                "from": getattr(mod, "f", None),
                "class": mod.__class__.__name__,
                "in_shape": in_s,
                "out_shape": out_s,
                "out_stride": _infer_stride_from_hw(out_s),
                "params": int(sum(p.numel() for p in mod.parameters())),
            }
            if isinstance(out, torch.Tensor) and out.dim() == 4:
                rec["out_channels"] = int(out.shape[1])
            layer_records.append(rec)

        handles.append(layer.register_forward_hook(hook))

    forward_ok = True
    forward_error = ""
    detect_out = None
    try:
        with torch.no_grad():
            detect_out = dm(dummy)
    except Exception as e:
        forward_ok = False
        forward_error = repr(e)
    finally:
        for h in handles:
            h.remove()

    params_total = int(sum(p.numel() for p in dm.parameters()))

    flops = None
    macs = None
    try:
        macs_raw, params_thop = thop.profile(dm, inputs=(dummy,), verbose=False)
        macs = float(macs_raw) / 1e9
        flops = float(macs_raw) * 2.0 / 1e9
        _ = params_thop
    except Exception:
        macs = None
        flops = None

    detect_indices = []
    detect_from = None
    for rec in layer_records:
        if rec["class"] == "Detect":
            detect_indices.append(int(rec["index"]))
            detect_from = rec["from"]

    p3p4p5 = None
    if isinstance(detect_out, list) and len(detect_out) == 3:
        p3p4p5 = [_shape(t) for t in detect_out]

    payload = {
        "group": group.key,
        "yaml_path": str(group.yaml_path),
        "save_dir": str(group.save_dir),
        "has_lightwavelet": bool(group.has_lightwavelet),
        "has_fg_gdpr_p5": bool(group.has_fg_gdpr_p5),
        "device": device,
        "forward_ok": forward_ok,
        "forward_error": forward_error,
        "detect_out_shapes": p3p4p5,
        "detect_indices": detect_indices,
        "detect_from": detect_from,
        "params_total": params_total,
        "macs_g": macs,
        "flops_g": flops,
        "layers": layer_records,
    }

    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    out_txt.write_text(_format_structure_check(payload), encoding="utf-8")
    return payload


def _format_structure_check(payload: dict) -> str:
    lines = []
    lines.append(f"group={payload.get('group')}")
    lines.append(f"yaml_path={payload.get('yaml_path')}")
    lines.append(f"save_dir={payload.get('save_dir')}")
    lines.append(f"has_lightwavelet={payload.get('has_lightwavelet')}")
    lines.append(f"has_fg_gdpr_p5={payload.get('has_fg_gdpr_p5')}")
    lines.append(f"device={payload.get('device')}")
    lines.append(f"forward_ok={payload.get('forward_ok')}")
    if not payload.get("forward_ok"):
        lines.append(f"forward_error={payload.get('forward_error')}")
    lines.append(f"params_total={payload.get('params_total')}")
    lines.append(f"macs_g={payload.get('macs_g')}")
    lines.append(f"flops_g={payload.get('flops_g')}")
    lines.append(f"detect_indices={payload.get('detect_indices')}")
    lines.append(f"detect_from={payload.get('detect_from')}")
    lines.append(f"detect_out_shapes={payload.get('detect_out_shapes')}")
    lines.append("")
    lines.append("index\tfrom\tclass\tin_shape\tout_shape\tout_stride\tparams\tout_channels")
    for rec in payload.get("layers", []):
        lines.append(
            f"{rec.get('index')}\t{rec.get('from')}\t{rec.get('class')}\t{rec.get('in_shape')}\t{rec.get('out_shape')}\t{rec.get('out_stride')}\t{rec.get('params')}\t{rec.get('out_channels')}"
        )
    lines.append("")
    return "\n".join(lines)


def _train_one(group: AblationGroup, device: str, resume: bool, overwrite: bool) -> dict:
    train_args = {
        "data": str(Path("configs/psyllid_slice640_balanced.yaml")),
        "imgsz": 640,
        "epochs": 100,
        "patience": 100,
        "batch": 4,
        "lr0": 0.01,
        "lrf": 0.01,
        "momentum": 0.937,
        "weight_decay": 0.0005,
        "warmup_epochs": 3.0,
        "warmup_momentum": 0.8,
        "optimizer": "auto",
        "device": "0" if device.startswith("cuda") else device,
        "seed": 42,
        "deterministic": True,
        "project": str(group.save_dir.parent),
        "name": group.save_dir.name,
        "exist_ok": True,
        "pretrained": False,
        "workers": 0,
        "plots": True,
        "save": True,
    }

    save_dir = group.save_dir
    best_pt = save_dir / "weights" / "best.pt"
    last_pt = save_dir / "weights" / "last.pt"
    out_json = save_dir / "train_result.json"

    if best_pt.exists() and not overwrite:
        payload = {"group": group.key, "status": "skipped", "reason": "best.pt exists", "best_pt": str(best_pt)}
        _ensure_parent(out_json)
        out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        return payload

    if resume and last_pt.exists():
        model = YOLO(str(last_pt))
        train_args["resume"] = True
    else:
        model = YOLO(str(group.yaml_path), task="detect")
        train_args["resume"] = False

    t0 = time.time()
    results = model.train(**train_args)
    elapsed_s = float(time.time() - t0)

    payload = {
        "group": group.key,
        "status": "trained",
        "elapsed_s": elapsed_s,
        "save_dir": str(save_dir),
        "best_pt": str(best_pt) if best_pt.exists() else "",
        "last_pt": str(last_pt) if last_pt.exists() else "",
        "results": str(results),
    }
    _ensure_parent(out_json)
    out_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return payload


def _groups(repo_root: Path) -> list[AblationGroup]:
    project_root = repo_root / "runs" / "ablation"
    cfg_root = repo_root / "configs"
    return [
        AblationGroup(
            key="A",
            yaml_path=cfg_root / "lwgdet_ablation_A_base.yaml",
            save_dir=project_root / "A_base",
            has_lightwavelet=False,
            has_fg_gdpr_p5=False,
        ),
        AblationGroup(
            key="B",
            yaml_path=cfg_root / "lwgdet_ablation_B_wavelet.yaml",
            save_dir=project_root / "B_wavelet",
            has_lightwavelet=True,
            has_fg_gdpr_p5=False,
        ),
        AblationGroup(
            key="C",
            yaml_path=cfg_root / "lwgdet_ablation_C_fg.yaml",
            save_dir=project_root / "C_fg",
            has_lightwavelet=False,
            has_fg_gdpr_p5=True,
        ),
        AblationGroup(
            key="D",
            yaml_path=cfg_root / "lwgdet_ablation_D_full.yaml",
            save_dir=project_root / "D_full",
            has_lightwavelet=True,
            has_fg_gdpr_p5=True,
        ),
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check_only", action="store_true", default=False)
    parser.add_argument("--train", action="store_true", default=False)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--resume", action="store_true", default=False)
    parser.add_argument("--overwrite", action="store_true", default=False)
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parent

    register_lwsdet_modules()

    device = args.device
    if device.startswith("cuda") and not torch.cuda.is_available():
        device = "cpu"

    groups = _groups(repo_root)
    checks = []
    for g in groups:
        checks.append(_run_structure_check(g, device=device, overwrite=bool(args.overwrite)))

    all_ok = all(c.get("forward_ok") for c in checks)
    if not all_ok:
        raise SystemExit("STRUCTURE_CHECK_FAILED")

    if bool(args.check_only) and not bool(args.train):
        return

    if bool(args.train):
        for g in groups:
            _train_one(g, device=device, resume=bool(args.resume), overwrite=bool(args.overwrite))


if __name__ == "__main__":
    main()
