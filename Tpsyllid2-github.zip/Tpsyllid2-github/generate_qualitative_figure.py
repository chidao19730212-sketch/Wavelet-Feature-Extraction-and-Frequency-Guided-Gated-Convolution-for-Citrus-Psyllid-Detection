import argparse
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import cv2
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm

try:
    from sahi import AutoDetectionModel
    from sahi.predict import get_sliced_prediction
    from sahi.utils.cv import read_image
except ImportError as exc:
    raise SystemExit("SAHI not found. Please install it before running this script.") from exc


def register_project_modules(project_root: Path) -> None:
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))
    from models import register_lwsdet_modules

    register_lwsdet_modules()


def _xyxy_iou(a, b) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    iw = max(0.0, ix2 - ix1)
    ih = max(0.0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return float(inter / union) if union > 0 else 0.0


def _match_detections(dets, gts, iou_thr=0.5):
    if not dets:
        return [], [], [False] * len(gts)
    dets_sorted = sorted(dets, key=lambda d: d["score"], reverse=True)
    matched = [False] * len(gts)
    tp, fp = [], []
    for det in dets_sorted:
        best_iou = 0.0
        best_j = -1
        for j, gt in enumerate(gts):
            if matched[j]:
                continue
            iou = _xyxy_iou(det["box"], gt)
            if iou > best_iou:
                best_iou, best_j = iou, j
        if best_iou >= float(iou_thr) and best_j >= 0:
            matched[best_j] = True
            tp.append(1)
            fp.append(0)
        else:
            tp.append(0)
            fp.append(1)
    return tp, fp, matched


def _load_yolo_gts(label_path: Path, img_w: int, img_h: int):
    gts = []
    if not label_path.exists():
        return gts
    with open(label_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) != 5:
                continue
            _, x, y, nw, nh = map(float, parts)
            x1 = (x - nw / 2) * img_w
            y1 = (y - nh / 2) * img_h
            x2 = (x + nw / 2) * img_w
            y2 = (y + nh / 2) * img_h
            gts.append([float(x1), float(y1), float(x2), float(y2)])
    return gts


def weighted_box_fusion(pred_sets, iou_thr=0.30, conf_type="avg", weights=None, topk=300):
    if not pred_sets:
        return []
    if weights is None:
        weights = [1.0] * len(pred_sets)

    candidates = []
    for w, dets in zip(weights, pred_sets):
        for d in dets:
            candidates.append({"box": d["box"], "score": float(d["score"]), "w": float(w)})
    candidates.sort(key=lambda d: d["score"], reverse=True)

    fused = []
    used = [False] * len(candidates)
    for i, d in enumerate(candidates):
        if used[i]:
            continue
        cluster = [d]
        used[i] = True
        for j in range(i + 1, len(candidates)):
            if used[j]:
                continue
            if _xyxy_iou(d["box"], candidates[j]["box"]) >= float(iou_thr):
                used[j] = True
                cluster.append(candidates[j])

        ws = np.array([c["w"] for c in cluster], dtype=np.float32)
        ss = np.array([c["score"] for c in cluster], dtype=np.float32)
        weight_scores = ws * ss
        denom = float(weight_scores.sum() + 1e-16)
        coords = np.array([c["box"] for c in cluster], dtype=np.float32)
        fused_box = (coords * weight_scores[:, None]).sum(axis=0) / denom

        if conf_type == "avg":
            fused_score = float((ss * ws).sum() / (ws.sum() + 1e-16))
        elif conf_type == "max":
            fused_score = float(ss.max())
        elif conf_type == "sum":
            fused_score = float(min(1.0, (ss * ws).sum() / (ws.sum() + 1e-16) * len(cluster)))
        else:
            raise ValueError(f"Unknown conf_type: {conf_type}")

        fused.append({"box": fused_box.tolist(), "score": fused_score})
        if len(fused) >= int(topk):
            break
    fused.sort(key=lambda d: d["score"], reverse=True)
    return fused[:topk]


def _infer_one_image(
    image_path: Path,
    detection_model,
    overlap_ratio: float,
    conf_thr: float,
    min_conf: float,
    wbf_iou: float,
):
    img = read_image(str(image_path))
    h, w = img.shape[:2]
    scales = [640, 768, 960]
    pred_sets = []
    for scale in scales:
        result = get_sliced_prediction(
            str(image_path),
            detection_model,
            slice_height=int(scale),
            slice_width=int(scale),
            overlap_height_ratio=float(overlap_ratio),
            overlap_width_ratio=float(overlap_ratio),
            perform_standard_pred=False,
            verbose=0,
        )
        dets = []
        for obj in result.object_prediction_list:
            sc = float(obj.score.value)
            if sc < float(min_conf):
                continue
            dets.append(
                {
                    "box": [float(obj.bbox.minx), float(obj.bbox.miny), float(obj.bbox.maxx), float(obj.bbox.maxy)],
                    "score": sc,
                }
            )
        pred_sets.append(dets)

        img_flipped = img[:, ::-1, :].copy()
        result_flipped = get_sliced_prediction(
            img_flipped,
            detection_model,
            slice_height=int(scale),
            slice_width=int(scale),
            overlap_height_ratio=float(overlap_ratio),
            overlap_width_ratio=float(overlap_ratio),
            perform_standard_pred=False,
            verbose=0,
        )
        dets_flip = []
        for obj in result_flipped.object_prediction_list:
            sc = float(obj.score.value)
            if sc < float(min_conf):
                continue
            x1, y1, x2, y2 = float(obj.bbox.minx), float(obj.bbox.miny), float(obj.bbox.maxx), float(obj.bbox.maxy)
            dets_flip.append({"box": [w - x2, y1, w - x1, y2], "score": sc})
        pred_sets.append(dets_flip)

    filtered_sets = []
    for dets in pred_sets:
        filtered_sets.append([d for d in dets if float(d["score"]) >= float(conf_thr)])
    fused = weighted_box_fusion(filtered_sets, iou_thr=float(wbf_iou), conf_type="avg")
    fused = [d for d in fused if float(d["score"]) >= float(conf_thr)]
    return img, fused


def _intersect_roi(box, roi):
    x1, y1, x2, y2 = box
    rx1, ry1, rx2, ry2 = roi
    ix1, iy1 = max(x1, rx1), max(y1, ry1)
    ix2, iy2 = min(x2, rx2), min(y2, ry2)
    if ix2 <= ix1 or iy2 <= iy1:
        return None
    return [ix1, iy1, ix2, iy2]


def _crop_boxes_to_roi(dets, roi):
    rx1, ry1, _, _ = roi
    out = []
    for d in dets:
        ib = _intersect_roi(d["box"], roi)
        if ib is None:
            continue
        out.append({"box": [ib[0] - rx1, ib[1] - ry1, ib[2] - rx1, ib[3] - ry1], "score": float(d["score"])})
    return out


def _crop_gts_to_roi(gts, roi):
    rx1, ry1, _, _ = roi
    out = []
    for gt in gts:
        ib = _intersect_roi(gt, roi)
        if ib is None:
            continue
        out.append([ib[0] - rx1, ib[1] - ry1, ib[2] - rx1, ib[3] - ry1])
    return out


def _make_square_roi(boxes, img_w: int, img_h: int):
    if not boxes:
        side = min(img_w, img_h)
        side = min(side, 1400)
        x0 = max(0, (img_w - side) // 2)
        y0 = max(0, (img_h - side) // 2)
        return [int(x0), int(y0), int(x0 + side), int(y0 + side)]

    x1 = min(b[0] for b in boxes)
    y1 = min(b[1] for b in boxes)
    x2 = max(b[2] for b in boxes)
    y2 = max(b[3] for b in boxes)
    cx = 0.5 * (x1 + x2)
    cy = 0.5 * (y1 + y2)
    bw = max(1.0, x2 - x1)
    bh = max(1.0, y2 - y1)
    side = int(round(max(bw, bh) * 8.0))
    side = max(900, side)
    side = min(side, min(img_w, img_h))
    rx1 = int(round(cx - side / 2))
    ry1 = int(round(cy - side / 2))
    rx1 = max(0, min(rx1, img_w - side))
    ry1 = max(0, min(ry1, img_h - side))
    return [int(rx1), int(ry1), int(rx1 + side), int(ry1 + side)]


def _draw_dashed_rect(img, x1, y1, x2, y2, color, thickness, dash_len=12, gap_len=8):
    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(img.shape[1] - 1, x2), min(img.shape[0] - 1, y2)
    if x2 <= x1 or y2 <= y1:
        return

    def _hline(y, xa, xb):
        cur = xa
        while cur < xb:
            end = min(xb, cur + dash_len)
            cv2.line(img, (cur, y), (end, y), color, thickness, lineType=cv2.LINE_AA)
            cur = end + gap_len

    def _vline(x, ya, yb):
        cur = ya
        while cur < yb:
            end = min(yb, cur + dash_len)
            cv2.line(img, (x, cur), (x, end), color, thickness, lineType=cv2.LINE_AA)
            cur = end + gap_len

    _hline(y1, x1, x2)
    _hline(y2, x1, x2)
    _vline(x1, y1, y2)
    _vline(x2, y1, y2)


def _resize_to_panel(img_bgr, panel_w, panel_h):
    h, w = img_bgr.shape[:2]
    if h <= 0 or w <= 0:
        return np.full((panel_h, panel_w, 3), 255, dtype=np.uint8), 1.0, 0, 0
    scale = min(panel_w / w, panel_h / h)
    nw = max(1, int(round(w * scale)))
    nh = max(1, int(round(h * scale)))
    resized = cv2.resize(img_bgr, (nw, nh), interpolation=cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LINEAR)
    canvas = np.full((panel_h, panel_w, 3), 255, dtype=np.uint8)
    ox = (panel_w - nw) // 2
    oy = (panel_h - nh) // 2
    canvas[oy : oy + nh, ox : ox + nw] = resized
    return canvas, float(scale), int(ox), int(oy)


def _resize_to_panel_fill(img_bgr, panel_w, panel_h, zoom: float = 1.0):
    h, w = img_bgr.shape[:2]
    if h <= 0 or w <= 0:
        return np.full((panel_h, panel_w, 3), 255, dtype=np.uint8), 1.0, 0, 0
    scale = max(panel_w / w, panel_h / h) * float(zoom)
    nw = max(1, int(round(w * scale)))
    nh = max(1, int(round(h * scale)))
    resized = cv2.resize(img_bgr, (nw, nh), interpolation=cv2.INTER_LINEAR)
    x0 = max(0, (nw - panel_w) // 2)
    y0 = max(0, (nh - panel_h) // 2)
    crop = resized[y0 : y0 + panel_h, x0 : x0 + panel_w]
    dx = float(x0) / float(scale)
    dy = float(y0) / float(scale)
    return crop, float(scale), -dx * scale, -dy * scale


def _draw_predictions_roi(roi_bgr, dets_roi, gts_roi, thickness=3):
    tp_flags, fp_flags, matched = _match_detections(dets_roi, gts_roi, iou_thr=0.5)
    dets_sorted = sorted(dets_roi, key=lambda d: d["score"], reverse=True)

    for gt in gts_roi:
        x1, y1, x2, y2 = gt
        _draw_dashed_rect(roi_bgr, x1, y1, x2, y2, (0, 255, 255), thickness)

    for det, is_tp, is_fp in zip(dets_sorted, tp_flags, fp_flags):
        x1, y1, x2, y2 = [int(round(v)) for v in det["box"]]
        if is_tp == 1:
            cv2.rectangle(roi_bgr, (x1, y1), (x2, y2), (255, 255, 0), thickness, lineType=cv2.LINE_AA)
        elif is_fp == 1:
            cv2.rectangle(roi_bgr, (x1, y1), (x2, y2), (0, 0, 255), thickness, lineType=cv2.LINE_AA)

    fn = int(len(gts_roi) - int(sum(matched)))
    tp = int(sum(tp_flags))
    fp = int(sum(fp_flags))
    return tp, fp, fn


@dataclass
class ModelSpec:
    name: str
    weight_path: Path
    detection_model: object


def _build_model(weight_path: Path, device: str):
    return AutoDetectionModel.from_pretrained(
        model_type="ultralytics",
        model_path=str(weight_path),
        confidence_threshold=0.15,
        device=device,
    )

def _build_model_with_retry(weight_path: Path, device: str, project_root: Path):
    try:
        return _build_model(weight_path, device)
    except Exception as first_error:
        try:
            register_project_modules(project_root)
            return _build_model(weight_path, device)
        except Exception:
            raise first_error


def _find_rtdetr_l_weight(project_root: Path):
    candidates = []
    for p in (project_root / "runs_lightweight").glob("**/weights/best.pt"):
        args_yaml = p.parent.parent / "args.yaml"
        model_field = None
        if args_yaml.exists():
            for line in args_yaml.read_text(encoding="utf-8", errors="ignore").splitlines():
                if line.strip().startswith("model:"):
                    model_field = line.split(":", 1)[1].strip()
                    break
        candidates.append({"weight": str(p), "args_yaml": str(args_yaml) if args_yaml.exists() else "", "model": model_field})

    selected = None
    for c in candidates:
        m = (c.get("model") or "").lower()
        if "rtdetr" in m and ("-l" in m or "_l" in m or "resnet101" in m or "resnet-101" in m):
            selected = Path(c["weight"])
            break
    return selected, candidates

def _is_low_texture_white_background(img_rgb: np.ndarray) -> bool:
    if img_rgb is None or img_rgb.size == 0:
        return True
    gray = cv2.cvtColor(cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR), cv2.COLOR_BGR2GRAY)
    mean = float(gray.mean())
    std = float(gray.std())
    return mean >= 230.0 and std <= 18.0


def parse_args():
    project_root = Path(__file__).resolve().parent
    default_results_dir = project_root / "results"
    default_dataset_root = Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\data\yolo_split")
    default_rtdetr_l = Path(r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\runs\detect\rtdetr_l_rebuild_v1\weights\best.pt")
    default_yolo11n_per_image = Path(
        r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\yolov11n_rebuild_v1_fullimage_sahi_tta_wbf\test\analysis\per_image_fp_fn.csv"
    )
    default_rtdetr_per_image = Path(
        r"C:\Users\admim\Desktop\Tpsyllid\workspace\outputs\compare_inference\rtdetr_l_rebuild_v1_fullimage_sahi_tta_wbf\test\analysis\per_image_fp_fn.csv"
    )

    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_root", type=Path, default=default_dataset_root)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--results_dir", type=Path, default=default_results_dir)
    parser.add_argument("--overwrite", action="store_true", default=False)

    parser.add_argument(
        "--lwg_weights",
        type=Path,
        default=project_root / "runs_lightweight" / "lwsdet_b1_fg_lssm_p5" / "weights" / "best.pt",
    )
    parser.add_argument(
        "--yolo_weights",
        type=Path,
        default=project_root / "runs_lightweight" / "yolo11n_baseline" / "weights" / "best.pt",
    )
    parser.add_argument("--rtdetr_l_weights", type=Path, default=default_rtdetr_l)
    parser.add_argument(
        "--per_image_yolo11n",
        type=Path,
        default=default_yolo11n_per_image,
        help="Per-image FP/FN CSV used only for selecting 2 representative images (not used for drawing).",
    )
    parser.add_argument(
        "--per_image_rtdetr_l",
        type=Path,
        default=default_rtdetr_per_image,
        help="Per-image FP/FN CSV used only for selecting 2 representative images (not used for drawing).",
    )
    parser.add_argument(
        "--images",
        type=Path,
        nargs="*",
        default=[],
        help="Optional: provide 1-3 specific test images to render candidate figures for manual selection (skips auto selection).",
    )
    parser.add_argument(
        "--candidate_prefix",
        type=str,
        default="Fig7_candidate",
        help="Prefix for candidate output files when --images is provided.",
    )
    parser.add_argument(
        "--auto_candidates",
        type=int,
        default=0,
        help="If > 0, automatically pick and render top-K candidate images with most obvious contrast.",
    )
    parser.add_argument(
        "--candidate_scene",
        type=str,
        default="background_fp",
        choices=["background_fp", "small_or_occluded_fn"],
        help="Scoring/ROI strategy for auto candidates.",
    )
    parser.add_argument(
        "--review_root",
        type=Path,
        default=None,
        help='Optional: use reviewed subset for qualitative analysis (expects "<review_root>/obj_train_data/*.jpg + *.txt").',
    )
    parser.add_argument(
        "--review_all_grid",
        action="store_true",
        default=False,
        help="When used with --review_root, render all reviewed images into one big grid figure (N rows x 4 cols).",
    )
    parser.add_argument(
        "--build_breeding_room_fig7_from_cache",
        action="store_true",
        default=False,
        help="Build the 5x4 breeding-room illumination Fig7 using cached predictions + reviewed labels + original test images (no inference).",
    )
    parser.add_argument(
        "--build_breeding_room_fig7_split_from_cache",
        action="store_true",
        default=False,
        help="Build two breeding-room Fig7 figures using cached predictions + reviewed labels + original test images (no inference): 3x4 white_light_backlight and 2x4 fluorescent.",
    )
    parser.add_argument(
        "--build_fp_candidates_3_from_cache",
        action="store_true",
        default=False,
        help="Build a 3x4 qualitative figure for images 0982/0994/1018 using cached per-image metadata JSONs (no inference).",
    )
    parser.add_argument(
        "--cache_metadata",
        type=Path,
        default=Path("results/Fig7_reviewed8_grid_metadata.json"),
        help="Metadata JSON that contains cached predictions for reviewed images.",
    )
    return parser.parse_args()

def _read_per_image_counts(csv_path: Path):
    import csv

    if not csv_path.exists():
        raise FileNotFoundError(str(csv_path))
    out = {}
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            img_id = str(row.get("img_id", "")).strip()
            if not img_id:
                continue
            out[img_id] = {
                "tp": int(float(row.get("tp", 0) or 0)),
                "fp": int(float(row.get("fp", 0) or 0)),
                "fn": int(float(row.get("fn", 0) or 0)),
                "gt": int(float(row.get("gt", 0) or 0)),
            }
    return out


def main():
    args = parse_args()
    project_root = Path(__file__).resolve().parent

    if args.review_root is not None:
        review_dir = Path(args.review_root)
        images_dir = review_dir / "obj_train_data"
        labels_dir = images_dir
        if not images_dir.exists():
            raise SystemExit(f"review_root missing obj_train_data: {images_dir}")
    else:
        images_dir = args.dataset_root / "test" / "images"
        labels_dir = args.dataset_root / "test" / "labels"
        if not images_dir.exists() or not labels_dir.exists():
            raise SystemExit(f"Dataset not found: {images_dir} / {labels_dir}")

    if not args.lwg_weights or not Path(args.lwg_weights).exists():
        raise SystemExit(f"Missing LWG/LWS-Det weights: {args.lwg_weights}")
    if not args.yolo_weights or not Path(args.yolo_weights).exists():
        raise SystemExit(f"Missing YOLOv11n weights: {args.yolo_weights}")

    rtdetr_weight = args.rtdetr_l_weights
    rtdetr_candidates = []
    if rtdetr_weight is None:
        found, candidates = _find_rtdetr_l_weight(project_root)
        rtdetr_candidates = candidates
        rtdetr_weight = found

    if rtdetr_weight is None or not Path(rtdetr_weight).exists():
        payload = {
            "missing": "RT-DETR-L weights",
            "required": "A local RT-DETR-L fine-tuned weight file (no download). Provide via --rtdetr_l_weights.",
            "searched_under": str(project_root / "runs_lightweight"),
            "found_bestpt_candidates": rtdetr_candidates[:50],
        }
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        raise SystemExit(2)

    out_png = args.results_dir / "Fig7_qualitative_comparison.png"
    out_pdf = args.results_dir / "Fig7_qualitative_comparison.pdf"
    out_meta = args.results_dir / "Fig7_qualitative_metadata.json"

    if not args.overwrite:
        for p in [out_png, out_pdf, out_meta]:
            if p.exists():
                raise SystemExit(f"OUTPUT_EXISTS: {p} (use --overwrite to replace)")

    args.results_dir.mkdir(parents=True, exist_ok=True)

    yolo_model = _build_model_with_retry(Path(args.yolo_weights), args.device, project_root)
    rtdetr_model = _build_model_with_retry(Path(rtdetr_weight), args.device, project_root)
    lwg_model = _build_model_with_retry(Path(args.lwg_weights), args.device, project_root)

    models = [
        ModelSpec(name="YOLOv11n", weight_path=Path(args.yolo_weights), detection_model=yolo_model),
        ModelSpec(name="RT-DETR-L", weight_path=Path(rtdetr_weight), detection_model=rtdetr_model),
        ModelSpec(name="LWG-Det", weight_path=Path(args.lwg_weights), detection_model=lwg_model),
    ]

    image_paths = sorted(images_dir.glob("*.jpg"))
    if len(image_paths) < 2:
        raise SystemExit(f"Not enough test images: {images_dir}")

    conf_thr = 0.35
    min_conf = 0.15
    overlap_ratio = 0.25
    wbf_iou = 0.30

    def _draw_case_label(panel_bgr: np.ndarray, text: str):
        if not text:
            return panel_bgr
        x = 10
        y = 35
        cv2.rectangle(panel_bgr, (x - 6, y - 26), (x + 130, y + 10), (255, 255, 255), -1)
        cv2.putText(
            panel_bgr,
            text,
            (x, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 0, 0),
            2,
            lineType=cv2.LINE_AA,
        )
        return panel_bgr

    def _read_cached_pred_map(meta_path: Path):
        if not meta_path.exists():
            raise FileNotFoundError(str(meta_path))
        payload = json.loads(meta_path.read_text(encoding="utf-8"))
        samples = payload.get("samples", [])
        pred_map = {}
        roi_map = {}
        for s in samples:
            img_path = str(s.get("image", ""))
            img_id = Path(img_path).stem if img_path else ""
            preds = s.get("pred_full_xyxy") or s.get("pred_full_xyxy".lower())
            if isinstance(preds, dict):
                pred_map[img_id] = preds
            roi = s.get("roi_xyxy")
            if isinstance(roi, list) and len(roi) == 4:
                roi_map[img_id] = [int(v) for v in roi]
        return pred_map, roi_map

    def _read_single_cached_meta(meta_path: Path):
        if not meta_path.exists():
            raise FileNotFoundError(str(meta_path))
        payload = json.loads(meta_path.read_text(encoding="utf-8"))
        image_path = Path(str(payload.get("image", "")))
        if not str(image_path):
            raise SystemExit(f"Invalid metadata (missing image): {meta_path}")
        img_id = image_path.stem
        roi = payload.get("roi_xyxy")
        if not isinstance(roi, list) or len(roi) != 4:
            raise SystemExit(f"Invalid metadata (missing roi_xyxy): {meta_path}")
        preds = payload.get("pred_full_xyxy")
        if not isinstance(preds, dict):
            raise SystemExit(f"Invalid metadata (missing pred_full_xyxy): {meta_path}")
        gts = payload.get("gt_full_xyxy")
        if not isinstance(gts, list) or len(gts) == 0:
            raise SystemExit(f"Invalid metadata (missing gt_full_xyxy): {meta_path}")
        return {
            "img_id": img_id,
            "image_path": image_path,
            "roi_xyxy": [int(v) for v in roi],
            "pred_full_xyxy": preds,
            "gt_full_xyxy": gts,
        }

    def _load_original_test_image(dataset_root: Path, img_id: str):
        p = dataset_root / "test" / "images" / f"{img_id}.jpg"
        img = cv2.imread(str(p), cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(str(p))
        return img, p

    def _xyxy_iou_box(a, b) -> float:
        return _xyxy_iou(a, b)

    def _match_tp_fp(dets, gts, iou_thr=0.5):
        dets_sorted = sorted(dets, key=lambda d: float(d.get("score", 0.0)), reverse=True)
        matched = [False] * len(gts)
        flags = []
        for det in dets_sorted:
            best_iou = 0.0
            best_j = -1
            for j, gt in enumerate(gts):
                if matched[j]:
                    continue
                iou = _xyxy_iou_box(det["box"], gt)
                if iou > best_iou:
                    best_iou, best_j = iou, j
            if best_iou >= float(iou_thr) and best_j >= 0:
                matched[best_j] = True
                flags.append(("tp", det))
            else:
                flags.append(("fp", det))
        return flags

    def _build_panels_from_cached(
        img_full_bgr: np.ndarray,
        roi,
        gts_full,
        preds_full_by_model: dict,
        thickness: int = 3,
        full_panel_w: int = 900,
        full_panel_h: int = 1200,
        crop_panel_w: int = 1050,
        crop_panel_h: int = 1050,
        zoom: float = 1.12,
    ):
        h, w = img_full_bgr.shape[:2]

        full_panel, s, ox, oy = _resize_to_panel_fill(img_full_bgr, full_panel_w, full_panel_h, zoom=zoom)
        for gt in gts_full:
            x1, y1, x2, y2 = gt
            _draw_dashed_rect(full_panel, x1 * s + ox, y1 * s + oy, x2 * s + ox, y2 * s + oy, (0, 255, 255), 2)
        rx1, ry1, rx2, ry2 = roi
        cv2.rectangle(
            full_panel,
            (int(round(rx1 * s + ox)), int(round(ry1 * s + oy))),
            (int(round(rx2 * s + ox)), int(round(ry2 * s + oy))),
            (255, 255, 255),
            2,
            lineType=cv2.LINE_AA,
        )

        crop_bgr = img_full_bgr[roi[1] : roi[3], roi[0] : roi[2], :].copy()
        crop_panel, cs, cox, coy = _resize_to_panel_fill(crop_bgr, crop_panel_w, crop_panel_h, zoom=zoom)

        gts_roi = _crop_gts_to_roi(gts_full, roi)
        gts_roi_scaled = [[g[0] * cs + cox, g[1] * cs + coy, g[2] * cs + cox, g[3] * cs + coy] for g in gts_roi]

        panels = {"Input and GT": full_panel}
        for model_name in ["YOLOv11n", "RT-DETR-L", "LWG-Det"]:
            dets_full = preds_full_by_model.get(model_name, [])
            dets_roi = _crop_boxes_to_roi(dets_full, roi)
            dets_roi_scaled = [
                {"box": [d["box"][0] * cs + cox, d["box"][1] * cs + coy, d["box"][2] * cs + cox, d["box"][3] * cs + coy], "score": d.get("score", 0.0)}
                for d in dets_roi
            ]

            panel = crop_panel.copy()
            for gt in gts_roi_scaled:
                _draw_dashed_rect(panel, gt[0], gt[1], gt[2], gt[3], (0, 255, 255), thickness)

            flags = _match_tp_fp(dets_roi_scaled, gts_roi_scaled, iou_thr=0.5)
            for tag, det in flags:
                x1, y1, x2, y2 = [int(round(v)) for v in det["box"]]
                if tag == "tp":
                    cv2.rectangle(panel, (x1, y1), (x2, y2), (255, 255, 0), thickness, lineType=cv2.LINE_AA)
                else:
                    cv2.rectangle(panel, (x1, y1), (x2, y2), (0, 0, 255), thickness, lineType=cv2.LINE_AA)

            panels[model_name] = panel
        return panels

    def _collect_panels_rows(
        img_ids,
        pred_map,
        roi_map,
        dataset_root: Path,
        reviewed_dir: Path,
        required_models,
        case_labels,
        crop_cfg_by_img_id=None,
    ):
        def _clip_xyxy_to_image(box, w: int, h: int):
            x1, y1, x2, y2 = [float(v) for v in box]
            x1 = max(0.0, min(x1, float(w)))
            y1 = max(0.0, min(y1, float(h)))
            x2 = max(0.0, min(x2, float(w)))
            y2 = max(0.0, min(y2, float(h)))
            if x2 <= x1 or y2 <= y1:
                return None
            return [x1, y1, x2, y2]

        def _apply_crop(
            img_bgr: np.ndarray,
            roi_xyxy,
            gts_full,
            preds_full_by_model: dict,
            crop_left_px: int = 0,
            crop_top_px: int = 0,
            crop_right_px: int = 0,
            crop_bottom_px: int = 0,
        ):
            crop_left_px = int(crop_left_px or 0)
            crop_top_px = int(crop_top_px or 0)
            crop_right_px = int(crop_right_px or 0)
            crop_bottom_px = int(crop_bottom_px or 0)
            if crop_left_px <= 0 and crop_top_px <= 0 and crop_right_px <= 0 and crop_bottom_px <= 0:
                return img_bgr, roi_xyxy, gts_full, preds_full_by_model
            h0, w0 = img_bgr.shape[:2]
            x0 = max(0, min(crop_left_px, w0 - 1))
            y0 = max(0, min(crop_top_px, h0 - 1))
            x1 = max(x0 + 1, min(w0, w0 - crop_right_px))
            y1 = max(y0 + 1, min(h0, h0 - crop_bottom_px))
            img_bgr = img_bgr[y0:y1, x0:x1, :].copy()
            new_h, new_w = img_bgr.shape[:2]

            rx1, ry1, rx2, ry2 = [int(v) for v in roi_xyxy]
            roi_xyxy = [rx1 - x0, ry1 - y0, rx2 - x0, ry2 - y0]
            roi_xyxy = [
                max(0, min(int(roi_xyxy[0]), new_w)),
                max(0, min(int(roi_xyxy[1]), new_h)),
                max(0, min(int(roi_xyxy[2]), new_w)),
                max(0, min(int(roi_xyxy[3]), new_h)),
            ]

            gts_new = []
            for gt in gts_full:
                shifted = [gt[0] - x0, gt[1] - y0, gt[2] - x0, gt[3] - y0]
                clipped = _clip_xyxy_to_image(shifted, new_w, new_h)
                if clipped is not None:
                    gts_new.append(clipped)

            preds_new = {}
            for m, dets in preds_full_by_model.items():
                dets_out = []
                for d in dets:
                    box = d["box"]
                    shifted = [box[0] - x0, box[1] - y0, box[2] - x0, box[3] - y0]
                    clipped = _clip_xyxy_to_image(shifted, new_w, new_h)
                    if clipped is None:
                        continue
                    dets_out.append({"box": clipped, "score": float(d.get("score", 0.0))})
                preds_new[m] = dets_out
            return img_bgr, roi_xyxy, gts_new, preds_new

        panels_rows = []
        for img_id in img_ids:
            img_full_bgr, _ = _load_original_test_image(dataset_root, img_id)
            gt_path = reviewed_dir / f"{img_id}.txt"
            if not gt_path.exists():
                raise SystemExit(f"Missing reviewed label: {gt_path}")
            h, w = img_full_bgr.shape[:2]
            gts_full = _load_yolo_gts(gt_path, w, h)
            if len(gts_full) == 0:
                raise SystemExit(f"Reviewed label empty: {gt_path}")
            roi = roi_map.get(img_id)
            if roi is None:
                roi = _make_square_roi(gts_full, img_w=w, img_h=h)
            preds_full_by_model = {k: pred_map[img_id][k] for k in required_models}

            if crop_cfg_by_img_id and img_id in crop_cfg_by_img_id:
                cfg = crop_cfg_by_img_id.get(img_id) or {}
                img_full_bgr, roi, gts_full, preds_full_by_model = _apply_crop(
                    img_full_bgr,
                    roi,
                    gts_full,
                    preds_full_by_model,
                    crop_left_px=cfg.get("crop_left_px", 0),
                    crop_top_px=cfg.get("crop_top_px", 0),
                    crop_right_px=cfg.get("crop_right_px", 0),
                    crop_bottom_px=cfg.get("crop_bottom_px", 0),
                )

            panels = _build_panels_from_cached(
                img_full_bgr,
                roi,
                gts_full,
                preds_full_by_model,
                thickness=3,
                full_panel_w=900,
                full_panel_h=1200,
                crop_panel_w=1050,
                crop_panel_h=1050,
            )
            panels["Input and GT"] = _draw_case_label(panels["Input and GT"], case_labels.get(img_id, ""))
            panels_rows.append((img_id, panels))
        return panels_rows

    def _render_panels_grid(
        panels_rows,
        out_png: Path,
        out_pdf: Path,
        fig_w_in: float,
        fig_h_in: float,
        dpi: int = 360,
        wspace: float = 0.012,
        hspace: float = 0.010,
        width_ratios=None,
        left: float = 0.012,
        right: float = 0.988,
        top: float = 0.994,
        bottom: float = 0.010,
        pad_inches: float = 0.01,
    ):
        titles = ["Input and GT", "YOLOv11n", "RT-DETR-L", "LWG-Det"]
        nrows = len(panels_rows)
        if width_ratios is None:
            width_ratios = [0.92, 1.02, 1.02, 1.02]

        fig = plt.figure(figsize=(fig_w_in, fig_h_in), dpi=dpi)
        gs = fig.add_gridspec(
            nrows,
            4,
            width_ratios=width_ratios,
            wspace=wspace,
            hspace=hspace,
        )
        fig.subplots_adjust(left=left, right=right, top=top, bottom=bottom)

        for r in range(nrows):
            _, panels = panels_rows[r]
            for c in range(4):
                ax = fig.add_subplot(gs[r, c])
                ax.set_axis_off()
                key = titles[c]
                panel_bgr = panels[key] if key in panels else panels.get(key, None)
                panel_rgb = cv2.cvtColor(panel_bgr, cv2.COLOR_BGR2RGB)
                ax.imshow(panel_rgb)
                if r == 0:
                    ax.set_title(titles[c], fontsize=11, pad=2)

        fig.savefig(str(out_png), dpi=dpi, bbox_inches="tight", pad_inches=pad_inches, facecolor="white")
        fig.savefig(str(out_pdf), bbox_inches="tight", pad_inches=pad_inches, facecolor="white")
        plt.close(fig)

    if bool(args.build_breeding_room_fig7_split_from_cache):
        if args.review_root is None:
            raise SystemExit("--build_breeding_room_fig7_split_from_cache requires --review_root")

        pred_map, roi_map = _read_cached_pred_map(Path(args.cache_metadata))
        dataset_root = Path(args.dataset_root)
        reviewed_dir = Path(args.review_root) / "obj_train_data"

        img_ids_all = ["0011", "0033", "0036", "0666", "0683"]
        case_labels_3 = {
            "0011": "Case A",
            "0033": "Case B",
            "0036": "Case C",
        }
        case_labels_2 = {
            "0666": "Case A",
            "0683": "Case B",
        }
        required_models = ["YOLOv11n", "RT-DETR-L", "LWG-Det"]
        for img_id in img_ids_all:
            if img_id not in pred_map:
                raise SystemExit(f"Missing cached predictions for image {img_id} in {args.cache_metadata}")
            for m in required_models:
                if m not in pred_map[img_id]:
                    raise SystemExit(f"Missing cached predictions for model {m} image {img_id} in {args.cache_metadata}")

        out1_png = Path("results/Fig7_breeding_room_white_light_backlight.png")
        out1_pdf = Path("results/Fig7_breeding_room_white_light_backlight.pdf")
        out2_png = Path("results/Fig7_breeding_room_fluorescent.png")
        out2_pdf = Path("results/Fig7_breeding_room_fluorescent.pdf")
        out1_png.parent.mkdir(parents=True, exist_ok=True)
        if not args.overwrite and (out1_png.exists() or out1_pdf.exists() or out2_png.exists() or out2_pdf.exists()):
            raise SystemExit("OUTPUT_EXISTS: breeding-room split figures already exist (use --overwrite)")

        rows_3 = _collect_panels_rows(
            ["0011", "0033", "0036"],
            pred_map,
            roi_map,
            dataset_root,
            reviewed_dir,
            required_models,
            case_labels_3,
            crop_cfg_by_img_id={
                "0011": {"crop_bottom_px": 1700},
                "0033": {"crop_bottom_px": 2100},
                "0036": {"crop_bottom_px": 2200, "crop_right_px": 900},
            },
        )
        rows_2 = _collect_panels_rows(
            ["0666", "0683"],
            pred_map,
            roi_map,
            dataset_root,
            reviewed_dir,
            required_models,
            case_labels_2,
            crop_cfg_by_img_id={
                "0666": {"crop_right_px": 1200, "crop_bottom_px": 1400},
                "0683": {"crop_left_px": 500, "crop_bottom_px": 1400},
            },
        )

        _render_panels_grid(rows_3, out1_png, out1_pdf, fig_w_in=12.0, fig_h_in=10.8, dpi=360)
        _render_panels_grid(rows_2, out2_png, out2_pdf, fig_w_in=12.0, fig_h_in=7.2, dpi=360)

        print(f"Saved: {out1_png}")
        print(f"Saved: {out1_pdf}")
        print(f"Saved: {out2_png}")
        print(f"Saved: {out2_pdf}")
        return

    if bool(args.build_fp_candidates_3_from_cache):
        meta_0982 = Path("results/Fig7_candidate_strong_fn_auto_0982_metadata.json")
        meta_0994 = Path("results/Fig7_candidate_strong_auto_0994_metadata.json")
        meta_1018 = Path("results/Fig7_candidate_strong_auto_1018_metadata.json")

        items = [_read_single_cached_meta(meta_0982), _read_single_cached_meta(meta_0994), _read_single_cached_meta(meta_1018)]
        required_models = ["YOLOv11n", "RT-DETR-L", "LWG-Det"]
        for it in items:
            for m in required_models:
                if m not in it["pred_full_xyxy"]:
                    raise SystemExit(f"Missing cached predictions for model {m} in metadata of image {it['img_id']}")

        out_png = Path("results/Fig7_fp_candidates_0982_0994_1018.png")
        out_pdf = Path("results/Fig7_fp_candidates_0982_0994_1018.pdf")
        out_png.parent.mkdir(parents=True, exist_ok=True)
        if not args.overwrite and (out_png.exists() or out_pdf.exists()):
            raise SystemExit(f"OUTPUT_EXISTS: {out_png} or {out_pdf} (use --overwrite)")

        case_labels = {"0982": "Case A", "0994": "Case B", "1018": "Case C"}
        crop_cfg_by_img_id = {
            "0982": {"crop_bottom_px": 1200},
            "0994": {"crop_bottom_px": 1400},
            "1018": {"crop_bottom_px": 1300},
        }
        panels_rows = []
        for it in items:
            img_full_bgr = cv2.imread(str(it["image_path"]), cv2.IMREAD_COLOR)
            if img_full_bgr is None:
                raise FileNotFoundError(str(it["image_path"]))
            roi = it["roi_xyxy"]
            gts_full = it["gt_full_xyxy"]
            preds_full_by_model = {k: it["pred_full_xyxy"][k] for k in required_models}
            cfg = crop_cfg_by_img_id.get(it["img_id"], {})
            if cfg:
                def _clip_xyxy(box, w: int, h: int):
                    x1, y1, x2, y2 = [float(v) for v in box]
                    x1 = max(0.0, min(x1, float(w)))
                    y1 = max(0.0, min(y1, float(h)))
                    x2 = max(0.0, min(x2, float(w)))
                    y2 = max(0.0, min(y2, float(h)))
                    if x2 <= x1 or y2 <= y1:
                        return None
                    return [x1, y1, x2, y2]

                h0, w0 = img_full_bgr.shape[:2]
                x0 = int(max(0, min(int(cfg.get("crop_left_px", 0) or 0), w0 - 1)))
                y0 = int(max(0, min(int(cfg.get("crop_top_px", 0) or 0), h0 - 1)))
                x1 = int(max(x0 + 1, min(w0, w0 - int(cfg.get("crop_right_px", 0) or 0))))
                y1 = int(max(y0 + 1, min(h0, h0 - int(cfg.get("crop_bottom_px", 0) or 0))))
                img_full_bgr = img_full_bgr[y0:y1, x0:x1, :].copy()
                new_h, new_w = img_full_bgr.shape[:2]

                rx1, ry1, rx2, ry2 = [int(v) for v in roi]
                roi = [rx1 - x0, ry1 - y0, rx2 - x0, ry2 - y0]
                roi = [
                    max(0, min(int(roi[0]), new_w)),
                    max(0, min(int(roi[1]), new_h)),
                    max(0, min(int(roi[2]), new_w)),
                    max(0, min(int(roi[3]), new_h)),
                ]

                gts_new = []
                for gt in gts_full:
                    shifted = [gt[0] - x0, gt[1] - y0, gt[2] - x0, gt[3] - y0]
                    clipped = _clip_xyxy(shifted, new_w, new_h)
                    if clipped is not None:
                        gts_new.append(clipped)
                gts_full = gts_new

                preds_new = {}
                for m, dets in preds_full_by_model.items():
                    dets_out = []
                    for d in dets:
                        box = d["box"]
                        shifted = [box[0] - x0, box[1] - y0, box[2] - x0, box[3] - y0]
                        clipped = _clip_xyxy(shifted, new_w, new_h)
                        if clipped is None:
                            continue
                        dets_out.append({"box": clipped, "score": float(d.get("score", 0.0))})
                    preds_new[m] = dets_out
                preds_full_by_model = preds_new

            panels = _build_panels_from_cached(
                img_full_bgr,
                roi,
                gts_full,
                preds_full_by_model,
                thickness=3,
                full_panel_w=900,
                full_panel_h=1200,
                crop_panel_w=1050,
                crop_panel_h=1050,
            )
            panels["Input and GT"] = _draw_case_label(panels["Input and GT"], case_labels.get(it["img_id"], ""))
            panels_rows.append((it["img_id"], panels))

        _render_panels_grid(panels_rows, out_png, out_pdf, fig_w_in=12.0, fig_h_in=10.8, dpi=360)
        print(f"Saved: {out_png}")
        print(f"Saved: {out_pdf}")
        return

    if bool(args.build_breeding_room_fig7_from_cache):
        if args.review_root is None:
            raise SystemExit("--build_breeding_room_fig7_from_cache requires --review_root")

        pred_map, roi_map = _read_cached_pred_map(Path(args.cache_metadata))

        dataset_root = Path(args.dataset_root)
        reviewed_dir = Path(args.review_root) / "obj_train_data"
        img_ids = ["0011", "0033", "0036", "0666", "0683"]
        case_labels = {
            "0011": "Case I",
            "0033": "Case II",
            "0036": "Case II",
            "0666": "Case III",
            "0683": "Case III",
        }

        required_models = ["YOLOv11n", "RT-DETR-L", "LWG-Det"]
        for img_id in img_ids:
            if img_id not in pred_map:
                raise SystemExit(f"Missing cached predictions for image {img_id} in {args.cache_metadata}")
            for m in required_models:
                if m not in pred_map[img_id]:
                    raise SystemExit(f"Missing cached predictions for model {m} image {img_id} in {args.cache_metadata}")

        out_png = Path("results/Fig7_breeding_room_illumination_comparison.png")
        out_pdf = Path("results/Fig7_breeding_room_illumination_comparison.pdf")
        out_png.parent.mkdir(parents=True, exist_ok=True)
        if not args.overwrite and (out_png.exists() or out_pdf.exists()):
            raise SystemExit(f"OUTPUT_EXISTS: {out_png} or {out_pdf} (use --overwrite)")

        panels_rows = _collect_panels_rows(
            img_ids,
            pred_map,
            roi_map,
            dataset_root,
            reviewed_dir,
            required_models,
            case_labels,
        )
        _render_panels_grid(panels_rows, out_png, out_pdf, fig_w_in=12.0, fig_h_in=18.0, dpi=360)
        print(f"Saved: {out_png}")
        print(f"Saved: {out_pdf}")
        return

    def _render_one_row_figure(img_path: Path, roi, gts, model_outputs, out_prefix: str):
        panel_w = 1200
        panel_h = 1200
        thickness = 3

        img = read_image(str(img_path))
        full_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        full_panel, s, ox, oy = _resize_to_panel(full_bgr, panel_w, panel_h)
        for gt in gts:
            x1, y1, x2, y2 = gt
            _draw_dashed_rect(full_panel, x1 * s + ox, y1 * s + oy, x2 * s + ox, y2 * s + oy, (0, 255, 255), 2)
        rx1, ry1, rx2, ry2 = roi
        cv2.rectangle(
            full_panel,
            (int(round(rx1 * s + ox)), int(round(ry1 * s + oy))),
            (int(round(rx2 * s + ox)), int(round(ry2 * s + oy))),
            (255, 255, 255),
            2,
            lineType=cv2.LINE_AA,
        )

        crop_rgb = img[roi[1] : roi[3], roi[0] : roi[2], :]
        crop_bgr = cv2.cvtColor(crop_rgb, cv2.COLOR_RGB2BGR)
        crop_panel, cs, cox, coy = _resize_to_panel(crop_bgr, panel_w, panel_h)
        gts_roi = _crop_gts_to_roi(gts, roi)
        gts_roi_scaled = [[g[0] * cs + cox, g[1] * cs + coy, g[2] * cs + cox, g[3] * cs + coy] for g in gts_roi]

        panels = {"Input and GT": full_panel}
        console_counts = {}
        for spec in models:
            dets_roi = _crop_boxes_to_roi(model_outputs[spec.name], roi)
            dets_roi_scaled = [
                {"box": [d["box"][0] * cs + cox, d["box"][1] * cs + coy, d["box"][2] * cs + cox, d["box"][3] * cs + coy], "score": d["score"]}
                for d in dets_roi
            ]
            panel = crop_panel.copy()
            tp, fp, fn = _draw_predictions_roi(panel, dets_roi_scaled, gts_roi_scaled, thickness=thickness)
            panels[spec.name] = panel
            console_counts[spec.name] = {"tp": tp, "fp": fp, "fn": fn}

        titles = ["Input and GT", "YOLOv11n", "RT-DETR-L", "LWG-Det"]
        letters = list("abcd")

        fig_w_in = 14.0
        fig_h_in = 4.8
        dpi = 300
        fig = plt.figure(figsize=(fig_w_in, fig_h_in), dpi=dpi)
        gs = fig.add_gridspec(2, 4, height_ratios=[1.0, 0.15], wspace=0.02, hspace=0.06)

        for c, title in enumerate(titles):
            ax = fig.add_subplot(gs[0, c])
            ax.set_axis_off()
            panel_bgr = panels[title if title == "Input and GT" else title]
            if title not in panels:
                panel_bgr = panels[title]
            panel_rgb = cv2.cvtColor(panel_bgr, cv2.COLOR_BGR2RGB)
            ax.imshow(panel_rgb)
            ax.set_title(title, fontsize=11)
            ax.text(
                0.02,
                0.06,
                f"({letters[c]})",
                transform=ax.transAxes,
                fontsize=11,
                ha="left",
                va="bottom",
                color="black",
                bbox=dict(facecolor="white", edgecolor="none", pad=1.5),
            )

        leg_ax = fig.add_subplot(gs[1, :])
        leg_ax.set_axis_off()
        y = 0.5
        x = 0.02
        leg_ax.plot([x, x + 0.05], [y, y], color="yellow", linestyle="--", linewidth=3)
        leg_ax.text(x + 0.055, y, "yellow dashed = ground truth", va="center", fontsize=11)
        x = 0.42
        leg_ax.plot([x, x + 0.05], [y, y], color="cyan", linestyle="-", linewidth=3)
        leg_ax.text(x + 0.055, y, "cyan = true positive", va="center", fontsize=11)
        x = 0.70
        leg_ax.plot([x, x + 0.05], [y, y], color="red", linestyle="-", linewidth=3)
        leg_ax.text(x + 0.055, y, "red = false positive", va="center", fontsize=11)

        out_png = args.results_dir / f"{out_prefix}.png"
        out_pdf = args.results_dir / f"{out_prefix}.pdf"
        out_meta = args.results_dir / f"{out_prefix}_metadata.json"

        fig.savefig(str(out_png), dpi=dpi, bbox_inches="tight", facecolor="white")
        fig.savefig(str(out_pdf), bbox_inches="tight", facecolor="white")
        plt.close(fig)

        meta = {
            "image": str(img_path),
            "label": str(labels_dir / f"{img_path.stem}.txt"),
            "roi_xyxy": roi,
            "weights": {spec.name: str(spec.weight_path.resolve()) for spec in models},
            "protocol": {
                "slice_size": 640,
                "overlap_ratio": overlap_ratio,
                "tta_scales": [640, 768, 960],
                "flip": True,
                "wbf_conf": conf_thr,
                "wbf_iou": wbf_iou,
                "min_conf": min_conf,
            },
            "counts_in_roi": console_counts,
            "gt_full_xyxy": gts,
            "gt_roi_xyxy": gts_roi,
            "pred_full_xyxy": {k: model_outputs[k] for k in model_outputs.keys()},
            "pred_roi_xyxy": {k: _crop_boxes_to_roi(model_outputs[k], roi) for k in model_outputs.keys()},
        }
        out_meta.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Saved: {out_png}")
        print(f"Saved: {out_pdf}")
        print(f"Saved: {out_meta}")
        return console_counts

    def _build_panels_for_image(img_path: Path, roi, gts, model_outputs):
        panel_w = 1200
        panel_h = 1200
        thickness = 3

        img = read_image(str(img_path))
        full_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        full_panel, s, ox, oy = _resize_to_panel(full_bgr, panel_w, panel_h)
        for gt in gts:
            x1, y1, x2, y2 = gt
            _draw_dashed_rect(full_panel, x1 * s + ox, y1 * s + oy, x2 * s + ox, y2 * s + oy, (0, 255, 255), 2)
        rx1, ry1, rx2, ry2 = roi
        cv2.rectangle(
            full_panel,
            (int(round(rx1 * s + ox)), int(round(ry1 * s + oy))),
            (int(round(rx2 * s + ox)), int(round(ry2 * s + oy))),
            (255, 255, 255),
            2,
            lineType=cv2.LINE_AA,
        )

        crop_rgb = img[roi[1] : roi[3], roi[0] : roi[2], :]
        crop_bgr = cv2.cvtColor(crop_rgb, cv2.COLOR_RGB2BGR)
        crop_panel, cs, cox, coy = _resize_to_panel(crop_bgr, panel_w, panel_h)
        gts_roi = _crop_gts_to_roi(gts, roi)
        gts_roi_scaled = [[g[0] * cs + cox, g[1] * cs + coy, g[2] * cs + cox, g[3] * cs + coy] for g in gts_roi]

        panels = {"Input and GT": full_panel}
        console_counts = {}
        for spec in models:
            dets_roi = _crop_boxes_to_roi(model_outputs[spec.name], roi)
            dets_roi_scaled = [
                {"box": [d["box"][0] * cs + cox, d["box"][1] * cs + coy, d["box"][2] * cs + cox, d["box"][3] * cs + coy], "score": d["score"]}
                for d in dets_roi
            ]
            panel = crop_panel.copy()
            tp, fp, fn = _draw_predictions_roi(panel, dets_roi_scaled, gts_roi_scaled, thickness=thickness)
            panels[spec.name] = panel
            console_counts[spec.name] = {"tp": tp, "fp": fp, "fn": fn}
        return panels, console_counts

    if args.review_root is not None and bool(args.review_all_grid):
        if len(image_paths) < 1:
            raise SystemExit("No reviewed images found.")

        titles = ["Input and GT", "YOLOv11n", "RT-DETR-L", "LWG-Det"]
        panels_all = []
        meta_samples = []

        for img_path in tqdm(image_paths, desc="Running inference for reviewed grid"):
            img = read_image(str(img_path))
            h, w = img.shape[:2]
            gt_path = labels_dir / (img_path.stem + ".txt")
            gts = _load_yolo_gts(gt_path, w, h)
            if len(gts) == 0:
                continue

            model_outputs = {}
            for spec in models:
                _, dets = _infer_one_image(
                    img_path,
                    spec.detection_model,
                    overlap_ratio=overlap_ratio,
                    conf_thr=conf_thr,
                    min_conf=min_conf,
                    wbf_iou=wbf_iou,
                )
                model_outputs[spec.name] = dets

            roi = _make_square_roi(gts, img_w=w, img_h=h)
            panels, counts = _build_panels_for_image(img_path, roi, gts, model_outputs)
            panels_all.append({"id": img_path.stem, "panels": panels, "roi": roi, "counts": counts})
            meta_samples.append(
                {
                    "image": str(img_path),
                    "label": str(gt_path),
                    "roi_xyxy": roi,
                    "counts_in_roi": counts,
                    "gt_full_xyxy": gts,
                    "pred_full_xyxy": {k: model_outputs[k] for k in model_outputs.keys()},
                }
            )

        if len(panels_all) == 0:
            raise SystemExit("No reviewed images with GT labels found.")

        out_png_grid = args.results_dir / "Fig7_reviewed8_grid.png"
        out_pdf_grid = args.results_dir / "Fig7_reviewed8_grid.pdf"
        out_meta_grid = args.results_dir / "Fig7_reviewed8_grid_metadata.json"

        if not args.overwrite:
            for p in [out_png_grid, out_pdf_grid, out_meta_grid]:
                if p.exists():
                    raise SystemExit(f"OUTPUT_EXISTS: {p} (use --overwrite to replace)")

        nrows = len(panels_all)
        dpi = 300
        fig_w_in = 14.0
        fig_h_in = max(8.0, 1.9 * nrows + 1.0)
        fig = plt.figure(figsize=(fig_w_in, fig_h_in), dpi=dpi)
        gs = fig.add_gridspec(nrows + 1, 4, height_ratios=[1.0] * nrows + [0.18], wspace=0.02, hspace=0.06)

        letters = []
        for i in range(nrows * 4):
            letters.append(chr(ord("a") + (i % 26)))

        idx = 0
        for r in range(nrows):
            row = panels_all[r]
            for c in range(4):
                ax = fig.add_subplot(gs[r, c])
                ax.set_axis_off()
                key = titles[c]
                panel_bgr = row["panels"][key if key == "Input and GT" else key]
                if key not in row["panels"]:
                    panel_bgr = row["panels"][key]
                panel_rgb = cv2.cvtColor(panel_bgr, cv2.COLOR_BGR2RGB)
                ax.imshow(panel_rgb)
                if r == 0:
                    ax.set_title(titles[c], fontsize=11)
                ax.text(
                    0.02,
                    0.06,
                    f"({letters[idx]})",
                    transform=ax.transAxes,
                    fontsize=10,
                    ha="left",
                    va="bottom",
                    color="black",
                    bbox=dict(facecolor="white", edgecolor="none", pad=1.2),
                )
                idx += 1
                if c == 0:
                    ax.text(
                        0.02,
                        0.92,
                        f"{row['id']}.jpg",
                        transform=ax.transAxes,
                        fontsize=10,
                        ha="left",
                        va="top",
                        color="black",
                        bbox=dict(facecolor="white", edgecolor="none", pad=1.2),
                    )

        leg_ax = fig.add_subplot(gs[nrows, :])
        leg_ax.set_axis_off()
        y = 0.5
        x = 0.02
        leg_ax.plot([x, x + 0.05], [y, y], color="yellow", linestyle="--", linewidth=3)
        leg_ax.text(x + 0.055, y, "yellow dashed = ground truth", va="center", fontsize=11)
        x = 0.42
        leg_ax.plot([x, x + 0.05], [y, y], color="cyan", linestyle="-", linewidth=3)
        leg_ax.text(x + 0.055, y, "cyan = true positive", va="center", fontsize=11)
        x = 0.70
        leg_ax.plot([x, x + 0.05], [y, y], color="red", linestyle="-", linewidth=3)
        leg_ax.text(x + 0.055, y, "red = false positive", va="center", fontsize=11)

        fig.savefig(str(out_png_grid), dpi=dpi, bbox_inches="tight", facecolor="white")
        fig.savefig(str(out_pdf_grid), bbox_inches="tight", facecolor="white")
        plt.close(fig)

        grid_meta = {
            "review_root": str(Path(args.review_root).resolve()),
            "protocol": {
                "slice_size": 640,
                "overlap_ratio": overlap_ratio,
                "tta_scales": [640, 768, 960],
                "flip": True,
                "wbf_conf": conf_thr,
                "wbf_iou": wbf_iou,
                "min_conf": min_conf,
            },
            "weights": {spec.name: str(spec.weight_path.resolve()) for spec in models},
            "samples": meta_samples,
        }
        out_meta_grid.write_text(json.dumps(grid_meta, indent=2, ensure_ascii=False), encoding="utf-8")

        print(f"Saved: {out_png_grid}")
        print(f"Saved: {out_pdf_grid}")
        print(f"Saved: {out_meta_grid}")
        return

    if args.images:
        selected = args.images
        for p in selected:
            if not p.exists():
                raise SystemExit(f"Image does not exist: {p}")
        for img_path in selected:
            img = read_image(str(img_path))
            h, w = img.shape[:2]
            gt_path = labels_dir / (img_path.stem + ".txt")
            gts = _load_yolo_gts(gt_path, w, h)
            if len(gts) == 0:
                raise SystemExit(f"Selected image has no GT labels: {img_path.name} -> {gt_path}")

            model_outputs = {}
            for spec in models:
                _, dets = _infer_one_image(
                    img_path,
                    spec.detection_model,
                    overlap_ratio=overlap_ratio,
                    conf_thr=conf_thr,
                    min_conf=min_conf,
                    wbf_iou=wbf_iou,
                )
                model_outputs[spec.name] = dets

            roi = _make_square_roi(gts, img_w=w, img_h=h)
            print(f"Candidate image: {img_path.name}\troi={roi}")
            counts = _render_one_row_figure(img_path, roi, gts, model_outputs, out_prefix=f"{args.candidate_prefix}_{img_path.stem}")
            for k, v in counts.items():
                print(f"  {k}: TP={v['tp']} FP={v['fp']} FN={v['fn']}")
        return

    candidates = []
    if args.review_root is not None:
        for img_path in tqdm(image_paths, desc="Scanning reviewed images"):
            img = read_image(str(img_path))
            h, w = img.shape[:2]
            if _is_low_texture_white_background(img):
                continue
            gt_path = labels_dir / (img_path.stem + ".txt")
            gts = _load_yolo_gts(gt_path, w, h)
            if len(gts) == 0:
                continue

            payload = {"image": str(img_path), "id": img_path.stem}
            for spec in models:
                _, dets = _infer_one_image(
                    img_path,
                    spec.detection_model,
                    overlap_ratio=overlap_ratio,
                    conf_thr=conf_thr,
                    min_conf=min_conf,
                    wbf_iou=wbf_iou,
                )
                tp_flags, fp_flags, matched = _match_detections(dets, gts, iou_thr=0.5)
                fp = int(sum(fp_flags))
                fn = int(len(gts) - int(sum(matched)))
                payload[f"{spec.name}_fp"] = fp
                payload[f"{spec.name}_fn"] = fn
            candidates.append(
                {
                    "image": payload["image"],
                    "id": payload["id"],
                    "YOLOv11n_fp": int(payload.get("YOLOv11n_fp", 0)),
                    "YOLOv11n_fn": int(payload.get("YOLOv11n_fn", 0)),
                    "RT-DETR-L_fp": int(payload.get("RT-DETR-L_fp", 0)),
                    "RT-DETR-L_fn": int(payload.get("RT-DETR-L_fn", 0)),
                    "LWG-Det_fp": int(payload.get("LWG-Det_fp", 0)),
                    "LWG-Det_fn": int(payload.get("LWG-Det_fn", 0)),
                }
            )
    else:
        per_lwg = _read_per_image_counts(
            Path(r"c:\Users\admim\Desktop\Tpsyllid2\runs_lightweight\paper2_original_image_eval\lwsdet_b1_fg_lssm_p5_last\test\analysis\per_image_fp_fn.csv")
        )
        per_yolo = _read_per_image_counts(args.per_image_yolo11n)
        per_rtdetr = _read_per_image_counts(args.per_image_rtdetr_l)

        for img_path in image_paths:
            img_id = img_path.stem
            lwg = per_lwg.get(img_id)
            yv = per_yolo.get(img_id)
            rt = per_rtdetr.get(img_id)
            if lwg is None or yv is None or rt is None:
                continue
            if int(lwg.get("gt", 0)) <= 0:
                continue
            img = read_image(str(img_path))
            if _is_low_texture_white_background(img):
                continue
            candidates.append(
                {
                    "image": str(img_path),
                    "id": img_id,
                    "YOLOv11n_fp": int(yv["fp"]),
                    "YOLOv11n_fn": int(yv["fn"]),
                    "RT-DETR-L_fp": int(rt["fp"]),
                    "RT-DETR-L_fn": int(rt["fn"]),
                    "LWG-Det_fp": int(lwg["fp"]),
                    "LWG-Det_fn": int(lwg["fn"]),
                }
            )

    if len(candidates) < 2:
        raise SystemExit("Not enough candidates after filtering (need per-image CSVs + labeled non-white images).")

    def _score_background_fp(r):
        fp_y = float(r.get("YOLOv11n_fp", 0))
        fp_r = float(r.get("RT-DETR-L_fp", 0))
        fp_l = float(r.get("LWG-Det_fp", 0))
        return (fp_y + fp_r) - fp_l

    def _score_missing_fn(r):
        fn_y = float(r.get("YOLOv11n_fn", 0))
        fn_r = float(r.get("RT-DETR-L_fn", 0))
        fn_l = float(r.get("LWG-Det_fn", 0))
        return (fn_y + fn_r) - fn_l

    rows_sorted_fp = sorted(candidates, key=_score_background_fp, reverse=True)
    rows_sorted_fn = sorted(candidates, key=_score_missing_fn, reverse=True)

    if int(args.auto_candidates) > 0:
        if args.candidate_scene == "background_fp":
            ranked = rows_sorted_fp
        else:
            ranked = rows_sorted_fn

        picked = []
        seen = set()
        for r in ranked:
            if r["id"] in seen:
                continue
            picked.append(r)
            seen.add(r["id"])
            if len(picked) >= int(args.auto_candidates):
                break

        for r in picked:
            img_path = Path(r["image"])
            img = read_image(str(img_path))
            h, w = img.shape[:2]
            gt_path = labels_dir / (img_path.stem + ".txt")
            gts = _load_yolo_gts(gt_path, w, h)
            if len(gts) == 0:
                continue

            model_outputs = {}
            for spec in models:
                _, dets = _infer_one_image(
                    img_path,
                    spec.detection_model,
                    overlap_ratio=overlap_ratio,
                    conf_thr=conf_thr,
                    min_conf=min_conf,
                    wbf_iou=wbf_iou,
                )
                model_outputs[spec.name] = dets

            if args.candidate_scene == "background_fp":
                roi_boxes = [d["box"] for d in model_outputs["YOLOv11n"]] + [d["box"] for d in model_outputs["RT-DETR-L"]]
                if not roi_boxes:
                    roi_boxes = gts[:]
            else:
                roi_boxes = gts[:]

            roi = _make_square_roi(roi_boxes, img_w=w, img_h=h)
            score = float(_score_background_fp(r) if args.candidate_scene == "background_fp" else _score_missing_fn(r))
            print(
                f"Auto candidate: {img_path.name}\tscene={args.candidate_scene}\tscore={score:.3f}\t"
                f"FP(yolo,rtdetr,lwg)=({r['YOLOv11n_fp']},{r['RT-DETR-L_fp']},{r['LWG-Det_fp']})\t"
                f"FN(yolo,rtdetr,lwg)=({r['YOLOv11n_fn']},{r['RT-DETR-L_fn']},{r['LWG-Det_fn']})\t"
                f"roi={roi}"
            )
            counts = _render_one_row_figure(img_path, roi, gts, model_outputs, out_prefix=f"{args.candidate_prefix}_auto_{img_path.stem}")
            for k, v in counts.items():
                print(f"  {k}: TP={v['tp']} FP={v['fp']} FN={v['fn']}")
        return

    pick1 = rows_sorted_fp[0]
    pick2 = None
    for r in rows_sorted_fn:
        if r["image"] != pick1["image"]:
            pick2 = r
            break
    if pick2 is None:
        pick2 = rows_sorted_fn[0]

    selections = [
        {"scene": "background_fp", "row": pick1},
        {"scene": "small_or_occluded_fn", "row": pick2},
    ]

    panel_w = 1200
    panel_h = 1200
    thickness = 3

    fig_panels = []
    metadata = {
        "protocol": {
            "slice_size": 640,
            "overlap_ratio": overlap_ratio,
            "tta_scales": [640, 768, 960],
            "flip": True,
            "wbf_conf": conf_thr,
            "wbf_iou": wbf_iou,
            "min_conf": min_conf,
        },
        "weights": {spec.name: str(spec.weight_path.resolve()) for spec in models},
        "samples": [],
    }

    for sel in selections:
        img_path = Path(sel["row"]["image"])
        img = read_image(str(img_path))
        h, w = img.shape[:2]
        gt_path = labels_dir / (img_path.stem + ".txt")
        gts = _load_yolo_gts(gt_path, w, h)

        model_outputs = {}
        for spec in models:
            _, dets = _infer_one_image(
                img_path,
                spec.detection_model,
                overlap_ratio=overlap_ratio,
                conf_thr=conf_thr,
                min_conf=min_conf,
                wbf_iou=wbf_iou,
            )
            model_outputs[spec.name] = dets

        roi_boxes = []
        if sel["scene"] == "background_fp":
            for det in model_outputs["YOLOv11n"]:
                roi_boxes.append(det["box"])
            for det in model_outputs["RT-DETR-L"]:
                roi_boxes.append(det["box"])
            if not roi_boxes:
                roi_boxes = gts[:]
        else:
            roi_boxes = gts[:]

        roi = _make_square_roi(roi_boxes, img_w=w, img_h=h)

        full_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        full_panel, s, ox, oy = _resize_to_panel(full_bgr, panel_w, panel_h)
        for gt in gts:
            x1, y1, x2, y2 = gt
            _draw_dashed_rect(full_panel, x1 * s + ox, y1 * s + oy, x2 * s + ox, y2 * s + oy, (0, 255, 255), 2)
        rx1, ry1, rx2, ry2 = roi
        cv2.rectangle(
            full_panel,
            (int(round(rx1 * s + ox)), int(round(ry1 * s + oy))),
            (int(round(rx2 * s + ox)), int(round(ry2 * s + oy))),
            (255, 255, 255),
            2,
            lineType=cv2.LINE_AA,
        )

        crop_rgb = img[roi[1] : roi[3], roi[0] : roi[2], :]
        crop_bgr = cv2.cvtColor(crop_rgb, cv2.COLOR_RGB2BGR)
        crop_panel, cs, cox, coy = _resize_to_panel(crop_bgr, panel_w, panel_h)
        gts_roi = _crop_gts_to_roi(gts, roi)
        gts_roi_scaled = [[g[0] * cs + cox, g[1] * cs + coy, g[2] * cs + cox, g[3] * cs + coy] for g in gts_roi]

        row_panels = {"Input and GT": full_panel}
        console_counts = {}

        for spec in models:
            dets_roi = _crop_boxes_to_roi(model_outputs[spec.name], roi)
            dets_roi_scaled = [
                {"box": [d["box"][0] * cs + cox, d["box"][1] * cs + coy, d["box"][2] * cs + cox, d["box"][3] * cs + coy], "score": d["score"]}
                for d in dets_roi
            ]
            panel = crop_panel.copy()
            tp, fp, fn = _draw_predictions_roi(panel, dets_roi_scaled, gts_roi_scaled, thickness=thickness)
            row_panels[spec.name] = panel
            console_counts[spec.name] = {"tp": tp, "fp": fp, "fn": fn}

        fig_panels.append(row_panels)

        metadata["samples"].append(
            {
                "scene": sel["scene"],
                "image": str(img_path),
                "label": str(gt_path),
                "roi_xyxy": roi,
                "counts_in_roi": console_counts,
                "gt_full_xyxy": gts,
                "gt_roi_xyxy": gts_roi,
                "pred_full_xyxy": {k: model_outputs[k] for k in model_outputs.keys()},
                "pred_roi_xyxy": {k: _crop_boxes_to_roi(model_outputs[k], roi) for k in model_outputs.keys()},
            }
        )

        print(f"Selected image: {img_path.name}\tscene={sel['scene']}\troi={roi}")
        for k, v in console_counts.items():
            print(f"  {k}: TP={v['tp']} FP={v['fp']} FN={v['fn']}")

    titles = ["Input and GT", "YOLOv11n", "RT-DETR-L", "LWG-Det"]
    letters = list("abcdefgh")

    fig_w_in = 14.0
    fig_h_in = 8.5
    dpi = 300
    fig = plt.figure(figsize=(fig_w_in, fig_h_in), dpi=dpi)
    gs = fig.add_gridspec(3, 4, height_ratios=[1.0, 1.0, 0.12], wspace=0.02, hspace=0.06)

    idx = 0
    for r in range(2):
        for c in range(4):
            ax = fig.add_subplot(gs[r, c])
            ax.set_axis_off()
            key = titles[c]
            panel_bgr = fig_panels[r][key]
            panel_rgb = cv2.cvtColor(panel_bgr, cv2.COLOR_BGR2RGB)
            ax.imshow(panel_rgb)
            ax.set_title(titles[c], fontsize=11)
            ax.text(
                0.02,
                0.06,
                f"({letters[idx]})",
                transform=ax.transAxes,
                fontsize=11,
                ha="left",
                va="bottom",
                color="black",
                bbox=dict(facecolor="white", edgecolor="none", pad=1.5),
            )
            idx += 1

    leg_ax = fig.add_subplot(gs[2, :])
    leg_ax.set_axis_off()
    y = 0.5
    x = 0.02
    leg_ax.plot([x, x + 0.05], [y, y], color="yellow", linestyle="--", linewidth=3)
    leg_ax.text(x + 0.055, y, "yellow dashed = ground truth", va="center", fontsize=11)
    x = 0.42
    leg_ax.plot([x, x + 0.05], [y, y], color="cyan", linestyle="-", linewidth=3)
    leg_ax.text(x + 0.055, y, "cyan = true positive", va="center", fontsize=11)
    x = 0.70
    leg_ax.plot([x, x + 0.05], [y, y], color="red", linestyle="-", linewidth=3)
    leg_ax.text(x + 0.055, y, "red = false positive", va="center", fontsize=11)

    fig.savefig(str(out_png), dpi=dpi, bbox_inches="tight", facecolor="white")
    fig.savefig(str(out_pdf), bbox_inches="tight", facecolor="white")
    plt.close(fig)

    out_meta.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Saved: {out_png}")
    print(f"Saved: {out_pdf}")
    print(f"Saved: {out_meta}")


if __name__ == "__main__":
    main()
