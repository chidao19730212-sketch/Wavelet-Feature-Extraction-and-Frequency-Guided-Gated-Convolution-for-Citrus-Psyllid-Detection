import ast
import contextlib

import torch
import torch.nn as nn
import ultralytics.nn.modules
import ultralytics.nn.tasks as tasks
from ultralytics.nn.modules import (
    AIFI, A2C2f, ADown, AConv, Bottleneck, BottleneckCSP, C1, C2, C2f, C2fAttn, C2fCIB,
    C2fPSA, C2PSA, C3, C3Ghost, C3TR, C3k2, C3x, CBLinear, CBFuse, Classify, Concat, Conv,
    Conv2, ConvTranspose, Detect, DWConv, DWConvTranspose2d, ELAN1, Focus, GhostBottleneck,
    GhostConv, HGBlock, HGStem, ImagePoolingAttn, Index, LRPCHead, OBB, Pose, PSA, RepC3,
    RepConv, RepNCSPELAN4, RepVGGDW, ResNetLayer, RTDETRDecoder, SCDown, Segment, SPP,
    SPPELAN, SPPF, TorchVision, WorldDetect, YOLOEDetect, YOLOESegment, v10Detect,
)
from ultralytics.utils.ops import make_divisible

from .modules.lws_modules import (
    FG_LSSMBlock,
    LightC2f,
    LightSPPF,
    LightSSMBlock,
    LightWavelet,
    dwt_haar,
)


def patched_parse_model_lwsdet(d, ch, verbose=True):
    depth, width, max_channels = 1.0, 1.0, float("inf")
    scales = d.get("scales")
    scale = d.get("scale")
    if scales and scale:
        depth, width, max_channels = scales[scale]

    nc = d.get("nc")
    ch = [ch]
    layers, save, c2 = [], [], ch[-1]

    base_modules = {
        Classify, Conv, ConvTranspose, GhostConv, Bottleneck, GhostBottleneck,
        SPP, SPPF, C2fPSA, C2PSA, DWConv, Focus, BottleneckCSP, C1, C2, C2f,
        C3k2, RepNCSPELAN4, ELAN1, ADown, AConv, SPPELAN, C2fAttn, C3, C3TR,
        C3Ghost, torch.nn.ConvTranspose2d, DWConvTranspose2d, C3x, RepC3, PSA,
        SCDown, C2fCIB, A2C2f, LightWavelet, LightC2f, LightSPPF, FG_LSSMBlock,
    }
    repeat_modules = {
        BottleneckCSP, C1, C2, C2f, C3k2, C2fAttn, C3, C3TR, C3Ghost, C3x,
        RepC3, C2fPSA, C2fCIB, C2PSA, A2C2f, LightC2f,
    }

    for i, (f, n, m_name, args) in enumerate(d["backbone"] + d["head"]):
        if m_name in ("LightWavelet", "LightC2f", "LightSPPF", "LightSSMBlock", "FG_LSSMBlock"):
            m = globals()[m_name]
        elif m_name == "C2f":
            m = LightC2f
        else:
            m = getattr(torch.nn, m_name[3:]) if "nn." in m_name else globals().get(m_name)
            if m is None:
                m = getattr(tasks, m_name)

        for j, a in enumerate(args):
            if isinstance(a, str):
                if a == "nc":
                    args[j] = nc
                else:
                    with contextlib.suppress(ValueError):
                        args[j] = ast.literal_eval(a)

        n = n_ = max(round(n * depth), 1) if n > 1 else n

        if m in base_modules:
            c1, c2 = ch[f], args[0]
            if c2 != nc:
                c2 = make_divisible(min(c2, max_channels) * width, 8)
            args = [c1, c2, *args[1:]]
            if m in repeat_modules:
                args.insert(2, n)
                n = 1
        elif m is Concat:
            c2 = sum(ch[x] for x in f)
        elif m in {Detect}:
            args.append([ch[x] for x in f])
        else:
            c2 = ch[f]

        m_ = nn.Sequential(*(m(*args) for _ in range(n))) if n > 1 else m(*args)
        t = str(m)[8:-2].replace("__main__.", "")
        m_.i, m_.f, m_.type, m_.np = i, f, t, sum(x.numel() for x in m_.parameters())
        save.extend(x % i for x in ([f] if isinstance(f, int) else f) if x != -1)
        layers.append(m_)
        if i == 0:
            ch = []
        ch.append(c2)
    return nn.Sequential(*layers), sorted(save)


def register_lwsdet_modules():
    tasks.parse_model = patched_parse_model_lwsdet
    for cls in (LightWavelet, LightSSMBlock, FG_LSSMBlock, LightC2f, LightSPPF):
        setattr(ultralytics.nn.modules, cls.__name__, cls)
        setattr(ultralytics.nn.tasks, cls.__name__, cls)
    _ = dwt_haar
