import torch
import torch.nn as nn
from ultralytics.nn.modules import C2f as OriginalC2f, Conv, SPPF


def dwt_haar(x):
    x00 = x[:, :, 0::2, 0::2]
    x10 = x[:, :, 1::2, 0::2]
    x01 = x[:, :, 0::2, 1::2]
    x11 = x[:, :, 1::2, 1::2]
    ll = (x00 + x10 + x01 + x11) / 4.0
    lh = (x00 - x10 + x01 - x11) / 4.0
    hl = (x00 + x10 - x01 - x11) / 4.0
    hh = (x00 - x10 - x01 + x11) / 4.0
    return torch.cat([ll, lh, hl, hh], dim=1)


class LightWavelet(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.cv_ll = Conv(c1, c2, 1, 1)
        self.cv_high = Conv(c1 * 3, c2, 1, 1)
        self.fusion = Conv(c2 * 2, c2, 1, 1)

    def forward(self, x):
        dwt_feat = dwt_haar(x)
        c = dwt_feat.shape[1] // 4
        ll = dwt_feat[:, :c, :, :]
        high_freq = dwt_feat[:, c:, :, :]
        feat_ll = self.cv_ll(ll)
        feat_high = self.cv_high(high_freq)
        return self.fusion(torch.cat([feat_ll, feat_high], dim=1))


class LightSSMBlock(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.conv = nn.Conv2d(c, c, 3, padding=1, groups=c)
        self.proj = nn.Conv2d(c, c, 1)
        self.act = nn.SiLU()

    def forward(self, x):
        res = x
        x = self.conv(x)
        x = self.act(x)
        x = self.proj(x)
        return x + res


class FG_LSSMBlock(nn.Module):
    def __init__(self, c1, c2=None, reduction=4, beta_init=0.1):
        super().__init__()
        c = c1 if c2 is None else c2
        hidden = max(c // reduction, 16)
        self.avg_pool = nn.AvgPool2d(kernel_size=3, stride=1, padding=1)
        self.guidance = nn.Conv2d(1, 1, kernel_size=1, stride=1, padding=0, bias=True)

        self.reduce = Conv(c, hidden, 1, 1)
        self.dw = nn.Conv2d(hidden, hidden, kernel_size=3, stride=1, padding=1, groups=hidden, bias=False)
        self.pw = nn.Conv2d(hidden, hidden, kernel_size=1, stride=1, padding=0, bias=False)
        self.gate = nn.Sequential(
            nn.Conv2d(hidden, hidden, kernel_size=1, stride=1, padding=0, bias=True),
            nn.Sigmoid(),
        )
        self.bn = nn.BatchNorm2d(hidden)
        self.act = nn.SiLU()
        self.restore = nn.Conv2d(hidden, c, kernel_size=1, stride=1, padding=0, bias=False)
        self.beta = nn.Parameter(torch.tensor(float(beta_init)))

    def forward(self, x):
        high = x - self.avg_pool(x)
        attn = torch.sigmoid(self.guidance(high.mean(dim=1, keepdim=True)))

        y = self.reduce(x)
        y = y * attn
        seq = self.dw(y)
        seq = self.pw(seq)
        seq = self.bn(seq)
        seq = self.act(seq)
        seq = seq * self.gate(y)
        restored = self.restore(seq)
        return x + self.beta * restored


class LightC2f(OriginalC2f):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, is_mamba=False):
        super().__init__(c1, c2, n, shortcut, g, e)
        if is_mamba:
            self.m = nn.ModuleList(LightSSMBlock(self.c) for _ in range(n))


class LightSPPF(SPPF):
    def __init__(self, c1, c2, k=5):
        super().__init__(c1, c2, k)

